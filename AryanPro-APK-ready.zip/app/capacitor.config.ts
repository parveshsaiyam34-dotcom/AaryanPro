import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aryanpro.app',
  appName: 'AryanPro',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
