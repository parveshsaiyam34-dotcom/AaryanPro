import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "5mb" }));

  // API Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // AI Chat Route with fallback models and retry handling
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: "Missing or invalid 'messages' array." });
      }

      // Format messages into Gemini format
      const formattedContents = messages
        .filter((m: { role: string; text: string }) => m.text && m.text.trim())
        .map((m: { role: string; text: string }) => ({
          role: m.role === "assistant" || m.role === "model" ? "model" : "user",
          parts: [{ text: m.text || "" }],
        }));

      if (formattedContents.length === 0) {
        return res.status(400).json({ error: "No valid message text provided." });
      }

      const ai = getGenAI();
      const systemInstruction =
        "You are a helpful, friendly, and knowledgeable AI chatbot for an Android mobile application. " +
        "Provide clean, well-formatted, natural, and helpful answers. " +
        "Keep responses concise and easy to read on mobile screens. " +
        "Use markdown formatting like bolding, bullet points, and code blocks where appropriate.";

      // Models to try in sequence if high demand / 503 occurs
      const modelsToTry = [
        "gemini-3.6-flash",
        "gemini-flash-latest",
        "gemini-3.8-flash",
        "gemini-3.1-flash-lite",
      ];
      let lastError: any = null;
      let replyText: string | null = null;

      for (const model of modelsToTry) {
        try {
          const response = await ai.models.generateContent({
            model,
            contents: formattedContents,
            config: {
              systemInstruction,
            },
          });

          if (response && response.text) {
            replyText = response.text;
            break;
          }
        } catch (err: any) {
          lastError = err;
          console.warn(`Model ${model} failed with:`, err?.message || err);

          // Check if error is 503 / 429 / UNAVAILABLE / high demand
          const errMsg = typeof err?.message === "string" ? err.message : JSON.stringify(err);
          const isHighDemand =
            errMsg.includes("503") ||
            errMsg.includes("UNAVAILABLE") ||
            errMsg.includes("high demand") ||
            errMsg.includes("429") ||
            errMsg.includes("RESOURCE_EXHAUSTED");

          if (!isHighDemand) {
            // Non-capacity error (e.g. invalid API key or bad request) - break and report
            break;
          }

          // Small delay before trying fallback model
          await new Promise((resolve) => setTimeout(resolve, 600));
        }
      }

      if (replyText) {
        return res.json({ text: replyText });
      }

      // If all models failed
      let friendlyError = "The AI service is experiencing high demand. Please tap retry in a moment.";
      if (!process.env.GEMINI_API_KEY) {
        friendlyError = "GEMINI_API_KEY is not configured in the application environment.";
      } else if (lastError?.message) {
        try {
          const parsed = JSON.parse(lastError.message);
          if (parsed.error?.message) {
            friendlyError = parsed.error.message;
          }
        } catch {
          if (typeof lastError.message === "string" && !lastError.message.startsWith("{")) {
            friendlyError = lastError.message;
          }
        }
      }

      return res.status(503).json({ error: friendlyError });
    } catch (error: any) {
      console.error("Chat API top-level error:", error);
      const isMissingKey = !process.env.GEMINI_API_KEY;
      return res.status(500).json({
        error: isMissingKey
          ? "GEMINI_API_KEY is not configured in the application environment."
          : (error?.message || "Failed to communicate with the AI model."),
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
