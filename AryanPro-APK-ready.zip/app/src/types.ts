export type AppId =
  | 'copilot'
  | 'explorer'
  | 'settings'
  | 'notepad'
  | 'calculator'
  | 'browser';

export type AppTheme = 'light' | 'dark';

export type WallpaperId =
  | 'bloom-blue'
  | 'bloom-dark'
  | 'bloom-glow'
  | 'bloom-captured-motion'
  | 'bloom-flow'
  | 'sunrise'
  | 'aurora'
  | 'sunset'
  | 'spotlight'
  | 'cyber';

export interface WindowState {
  id: string;
  appId: AppId;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  x: number;
  y: number;
  width: number;
  height: number;
  minWidth: number;
  minHeight: number;
  customData?: any;
}

export interface DesktopIconItem {
  id: AppId | 'recycle-bin';
  name: string;
  iconName: string;
  appId?: AppId;
  badge?: string;
}

export type SettingsSectionId =
  | 'system'
  | 'bluetooth'
  | 'network'
  | 'personalization'
  | 'apps'
  | 'accounts'
  | 'time-language'
  | 'gaming'
  | 'accessibility'
  | 'privacy-security'
  | 'windows-update';

export interface SystemSettings {
  theme: AppTheme;
  wallpaper: WallpaperId;
  accentColor: string;
  taskbarAlignment: 'center' | 'left';
  volume: number;
  brightness: number;
  wifiEnabled: boolean;
  bluetoothEnabled: boolean;
  nightLight: boolean;
  transparencyEffects?: boolean;
  showAccentOnTaskbar?: boolean;
  showAccentOnTitleBars?: boolean;
  taskbarSearch?: 'box' | 'icon' | 'hide';
  taskbarWidgets?: boolean;
  taskbarCopilot?: boolean;
  taskbarBadges?: boolean;
  autoHideTaskbar?: boolean;
  gameMode?: boolean;
  powerMode?: 'balanced' | 'performance' | 'saver';
  textScale?: number;
  timeZone?: string;
  autoTime?: boolean;
}

export interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size?: string;
  date: string;
  extension?: string;
  content?: string;
  category?: string;
  parentId?: string | null;
  location?: string;
  itemCount?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  error?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}
