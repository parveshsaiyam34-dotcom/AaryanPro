import React, { useState, useRef, useEffect } from 'react';
import { Minus, Square, Copy, X } from 'lucide-react';
import { WindowState, AppTheme, SystemSettings } from '../../types';

interface WindowFrameProps {
  windowState: WindowState;
  theme: AppTheme;
  settings?: SystemSettings;
  isActive: boolean;
  onFocus: () => void;
  onClose: () => void;
  onMinimize: () => void;
  onToggleMaximize: () => void;
  onUpdatePosition: (x: number, y: number) => void;
  onUpdateSize: (width: number, height: number) => void;
  children: React.ReactNode;
  icon: React.ReactNode;
}

type ResizeDirection = 'e' | 's' | 'w' | 'n' | 'se' | 'sw' | 'ne' | 'nw';

export const WindowFrame: React.FC<WindowFrameProps> = ({
  windowState,
  theme,
  settings,
  isActive,
  onFocus,
  onClose,
  onMinimize,
  onToggleMaximize,
  onUpdatePosition,
  onUpdateSize,
  children,
  icon,
}) => {
  const isDark = theme === 'dark';
  const { isMinimized, isMaximized, x, y, width, height, minWidth, minHeight, zIndex } = windowState;

  // Responsive window bounds clamping
  const [screenSize, setScreenSize] = useState({
    w: typeof window !== 'undefined' ? window.innerWidth : 1024,
    h: typeof window !== 'undefined' ? window.innerHeight : 768,
  });

  useEffect(() => {
    const handleResize = () => {
      setScreenSize({
        w: window.innerWidth,
        h: window.innerHeight,
      });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isMobile = screenSize.w < 640;
  const effectiveWidth = isMobile ? Math.min(width, screenSize.w - 16) : width;
  const effectiveHeight = isMobile ? Math.min(height, screenSize.h - 64) : height;
  const effectiveX = isMobile ? Math.max(8, Math.min(screenSize.w - effectiveWidth - 8, x)) : x;
  const effectiveY = isMobile ? Math.max(8, Math.min(screenSize.h - effectiveHeight - 56, y)) : y;

  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [activeResizeDir, setActiveResizeDir] = useState<ResizeDirection | null>(null);

  const dragStartPos = useRef({ mouseX: 0, mouseY: 0, startX: 0, startY: 0 });
  const resizeStartPos = useRef({
    mouseX: 0,
    mouseY: 0,
    startX: 0,
    startY: 0,
    startW: 0,
    startH: 0,
    dir: null as ResizeDirection | null,
  });

  // Global Dragging Listeners
  useEffect(() => {
    if (!isDragging) return;

    const handlePointerMove = (e: PointerEvent) => {
      const deltaX = e.clientX - dragStartPos.current.mouseX;
      const deltaY = e.clientY - dragStartPos.current.mouseY;

      const screenW = window.innerWidth;
      const screenH = window.innerHeight;

      // Keep at least 80px visible horizontally, and top titlebar accessible
      const newX = Math.max(-width + 80, Math.min(screenW - 80, dragStartPos.current.startX + deltaX));
      const newY = Math.max(0, Math.min(screenH - 80, dragStartPos.current.startY + deltaY));

      onUpdatePosition(newX, newY);
    };

    const handlePointerUp = () => {
      setIsDragging(false);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [isDragging, width, onUpdatePosition]);

  // Global Resizing Listeners
  useEffect(() => {
    if (!isResizing || !activeResizeDir) return;

    const handlePointerMove = (e: PointerEvent) => {
      const { mouseX, mouseY, startX, startY, startW, startH, dir } = resizeStartPos.current;
      const deltaX = e.clientX - mouseX;
      const deltaY = e.clientY - mouseY;

      let newX = startX;
      let newY = startY;
      let newW = startW;
      let newH = startH;

      const screenW = window.innerWidth;
      const screenH = window.innerHeight - 48; // above taskbar

      if (dir === 'e' || dir === 'se' || dir === 'ne') {
        newW = Math.max(minWidth, Math.min(screenW - startX, startW + deltaX));
      }
      if (dir === 's' || dir === 'se' || dir === 'sw') {
        newH = Math.max(minHeight, Math.min(screenH - startY, startH + deltaY));
      }
      if (dir === 'w' || dir === 'sw' || dir === 'nw') {
        const potentialW = startW - deltaX;
        if (potentialW >= minWidth) {
          newW = potentialW;
          newX = startX + deltaX;
        } else {
          newW = minWidth;
          newX = startX + (startW - minWidth);
        }
      }
      if (dir === 'n' || dir === 'ne' || dir === 'nw') {
        const potentialH = startH - deltaY;
        if (potentialH >= minHeight) {
          newH = potentialH;
          newY = Math.max(0, startY + deltaY);
        } else {
          newH = minHeight;
          newY = startY + (startH - minHeight);
        }
      }

      if (newX !== startX || newY !== startY) {
        onUpdatePosition(newX, newY);
      }
      onUpdateSize(newW, newH);
    };

    const handlePointerUp = () => {
      setIsResizing(false);
      setActiveResizeDir(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [isResizing, activeResizeDir, minWidth, minHeight, onUpdatePosition, onUpdateSize]);

  // Header Pointer Down
  const handleHeaderPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('.window-control-btn')) return;
    if (isMaximized) return;

    onFocus();
    setIsDragging(true);
    dragStartPos.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: x,
      startY: y,
    };
  };

  // Resize Handle Pointer Down
  const handleResizeStart = (e: React.PointerEvent, dir: ResizeDirection) => {
    e.stopPropagation();
    if (isMaximized) return;

    onFocus();
    setIsResizing(true);
    setActiveResizeDir(dir);
    resizeStartPos.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: x,
      startY: y,
      startW: width,
      startH: height,
      dir,
    };
  };

  if (isMinimized) return null;

  const hasTransparency = settings?.transparencyEffects !== false;
  const showAccentTitle = settings?.showAccentOnTitleBars && isActive;
  const accentColor = settings?.accentColor || '#0078d4';

  return (
    <div
      onMouseDown={onFocus}
      style={{
        zIndex,
        borderColor: showAccentTitle ? accentColor : undefined,
        ...(isMaximized
          ? {
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: '48px',
              width: '100%',
              height: 'calc(100% - 48px)',
            }
          : {
              position: 'absolute',
              top: `${effectiveY}px`,
              left: `${effectiveX}px`,
              width: `${effectiveWidth}px`,
              height: `${effectiveHeight}px`,
            }),
      }}
      className={`flex flex-col shadow-2xl transition-[border-color,box-shadow] select-none ${
        hasTransparency ? 'backdrop-blur-2xl' : ''
      } ${
        isMaximized ? 'rounded-none border-0' : 'rounded-xl border'
      } ${
        isActive
          ? showAccentTitle
            ? 'ring-1 shadow-black/80'
            : isDark
            ? 'border-white/25 ring-1 ring-white/15 shadow-black/80'
            : 'border-blue-500/40 ring-1 ring-blue-500/20 shadow-slate-900/40'
          : isDark
          ? 'border-white/10 shadow-black/60 opacity-95'
          : 'border-slate-300 shadow-slate-400/30 opacity-95'
      } ${
        hasTransparency
          ? isDark
            ? 'bg-slate-900/90'
            : 'bg-white/90'
          : isDark
          ? 'bg-slate-900'
          : 'bg-white'
      }`}
    >
      {/* Title Bar (Draggable) */}
      <div
        onPointerDown={handleHeaderPointerDown}
        onDoubleClick={onToggleMaximize}
        style={{
          backgroundColor: showAccentTitle ? accentColor : undefined,
        }}
        className={`h-9 px-3 flex items-center justify-between border-b cursor-default select-none shrink-0 transition-colors ${
          showAccentTitle
            ? 'border-black/20 text-white'
            : isDark
            ? isActive
              ? 'bg-slate-900/80 border-slate-800/80 text-slate-100'
              : 'bg-slate-950/50 border-slate-850/60 text-slate-400'
            : isActive
            ? 'bg-slate-100/90 border-slate-200 text-slate-800'
            : 'bg-slate-200/60 border-slate-300/60 text-slate-500'
        }`}
      >
        {/* App Icon + Title */}
        <div className="flex items-center space-x-2 truncate pr-2 pointer-events-none">
          <div className="w-4 h-4 flex items-center justify-center shrink-0">
            {icon}
          </div>
          <span className="text-xs font-medium truncate">{windowState.title}</span>
        </div>

        {/* Windows 11 Classic Window Controls */}
        <div className="flex items-center space-x-0.5 -mr-1 shrink-0">
          {/* Minimize */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onMinimize();
            }}
            className={`window-control-btn w-9 h-7 flex items-center justify-center rounded-xs transition-colors cursor-pointer ${
              isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-200 text-slate-700'
            }`}
            title="Minimize"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>

          {/* Maximize / Restore */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleMaximize();
            }}
            className={`window-control-btn w-9 h-7 flex items-center justify-center rounded-xs transition-colors cursor-pointer ${
              isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-200 text-slate-700'
            }`}
            title={isMaximized ? 'Restore Down' : 'Maximize'}
          >
            {isMaximized ? <Copy className="w-3 h-3" /> : <Square className="w-3 h-3" />}
          </button>

          {/* Close */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="window-control-btn w-9 h-7 flex items-center justify-center rounded-xs transition-colors text-slate-400 hover:bg-rose-600 hover:text-white cursor-pointer"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Window Body */}
      <div
        className={`flex-1 overflow-hidden relative ${
          isDragging || isResizing ? 'pointer-events-none select-none' : ''
        }`}
      >
        {children}
      </div>

      {/* 8 Resizing Handles (Active when window is not maximized) */}
      {!isMaximized && (
        <>
          {/* Top Edge */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'n')}
            className="absolute -top-1.5 left-2 right-2 h-3 cursor-ns-resize z-20"
          />
          {/* Bottom Edge */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 's')}
            className="absolute -bottom-1.5 left-2 right-2 h-3 cursor-ns-resize z-20"
          />
          {/* Left Edge */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'w')}
            className="absolute top-2 bottom-2 -left-1.5 w-3 cursor-ew-resize z-20"
          />
          {/* Right Edge */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'e')}
            className="absolute top-2 bottom-2 -right-1.5 w-3 cursor-ew-resize z-20"
          />
          {/* Top-Left Corner */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'nw')}
            className="absolute -top-2 -left-2 w-4 h-4 cursor-nwse-resize z-30"
          />
          {/* Top-Right Corner */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'ne')}
            className="absolute -top-2 -right-2 w-4 h-4 cursor-nesw-resize z-30"
          />
          {/* Bottom-Left Corner */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'sw')}
            className="absolute -bottom-2 -left-2 w-4 h-4 cursor-nesw-resize z-30"
          />
          {/* Bottom-Right Corner */}
          <div
            onPointerDown={(e) => handleResizeStart(e, 'se')}
            className="absolute -bottom-2 -right-2 w-4 h-4 cursor-nwse-resize z-30"
          />
        </>
      )}

      {/* Global Drag/Resize overlay to prevent iframes / textareas from swallowing events */}
      {(isDragging || isResizing) && (
        <div className="fixed inset-0 z-50 pointer-events-auto bg-transparent cursor-grabbing" />
      )}
    </div>
  );
};
