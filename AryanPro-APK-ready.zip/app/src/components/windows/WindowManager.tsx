import React from 'react';
import { Sparkles, Folder, Settings, FileText, Calculator, Globe } from 'lucide-react';
import { WindowState, SystemSettings, AppId } from '../../types';
import { WindowFrame } from './WindowFrame';
import { CopilotApp } from '../apps/CopilotApp';
import { FileExplorerApp } from '../apps/FileExplorerApp';
import { SettingsApp } from '../apps/SettingsApp';
import { NotepadApp } from '../apps/NotepadApp';
import { CalculatorApp } from '../apps/CalculatorApp';
import { BrowserApp } from '../apps/BrowserApp';

interface WindowManagerProps {
  windows: WindowState[];
  activeWindowId: string | null;
  settings: SystemSettings;
  onFocusWindow: (id: string) => void;
  onCloseWindow: (id: string) => void;
  onMinimizeWindow: (id: string) => void;
  onToggleMaximizeWindow: (id: string) => void;
  onUpdatePosition: (id: string, x: number, y: number) => void;
  onUpdateSize: (id: string, width: number, height: number) => void;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  onOpenFileInNotepad: (fileName: string, content: string) => void;
}

export const WindowManager: React.FC<WindowManagerProps> = ({
  windows,
  activeWindowId,
  settings,
  onFocusWindow,
  onCloseWindow,
  onMinimizeWindow,
  onToggleMaximizeWindow,
  onUpdatePosition,
  onUpdateSize,
  onUpdateSettings,
  onOpenFileInNotepad,
}) => {
  const getAppIcon = (appId: AppId) => {
    switch (appId) {
      case 'copilot':
        return <Sparkles className="w-3.5 h-3.5 text-blue-500" />;
      case 'explorer':
        return <Folder className="w-3.5 h-3.5 text-amber-500 fill-amber-500/20" />;
      case 'settings':
        return <Settings className="w-3.5 h-3.5 text-slate-400" />;
      case 'notepad':
        return <FileText className="w-3.5 h-3.5 text-sky-500" />;
      case 'calculator':
        return <Calculator className="w-3.5 h-3.5 text-emerald-500" />;
      case 'browser':
        return <Globe className="w-3.5 h-3.5 text-blue-400" />;
    }
  };

  const renderAppContent = (win: WindowState) => {
    switch (win.appId) {
      case 'copilot':
        return <CopilotApp theme={settings.theme} />;
      case 'explorer':
        return (
          <FileExplorerApp
            theme={settings.theme}
            onOpenFileInNotepad={onOpenFileInNotepad}
            initialPath={win.customData?.folderName || win.customData?.initialPath}
          />
        );
      case 'settings':
        return (
          <SettingsApp
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            initialTab={win.customData?.tab}
          />
        );
      case 'notepad':
        return (
          <NotepadApp
            theme={settings.theme}
            initialFileName={win.customData?.fileName}
            initialContent={win.customData?.content}
          />
        );
      case 'calculator':
        return <CalculatorApp theme={settings.theme} />;
      case 'browser':
        return <BrowserApp theme={settings.theme} />;
      default:
        return <div className="p-4 text-xs">Unknown Application</div>;
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ bottom: '48px' }}>
      {windows
        .filter((w) => w.isOpen)
        .map((win) => {
          const isActive = activeWindowId === win.id;
          return (
            <div key={win.id} className="pointer-events-auto">
              <WindowFrame
                windowState={win}
                theme={settings.theme}
                settings={settings}
                isActive={isActive}
                icon={getAppIcon(win.appId)}
                onFocus={() => onFocusWindow(win.id)}
                onClose={() => onCloseWindow(win.id)}
                onMinimize={() => onMinimizeWindow(win.id)}
                onToggleMaximize={() => onToggleMaximizeWindow(win.id)}
                onUpdatePosition={(x, y) => onUpdatePosition(win.id, x, y)}
                onUpdateSize={(w, h) => onUpdateSize(win.id, w, h)}
              >
                {renderAppContent(win)}
              </WindowFrame>
            </div>
          );
        })}
    </div>
  );
};
