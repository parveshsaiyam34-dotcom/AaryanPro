import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Sparkles,
  Folder,
  Settings,
  FileText,
  Calculator,
  Globe,
  Power,
  User,
  RotateCcw,
  Moon,
  Lock,
  LogOut,
  ChevronRight,
  ChevronLeft,
  Clock,
  Terminal,
  Mail,
  Shield,
  Camera,
  Music,
  Image as ImageIcon,
  Check,
  Pin,
  ExternalLink,
} from 'lucide-react';
import { AppId, SystemSettings } from '../../types';

interface StartMenuProps {
  isOpen: boolean;
  settings: SystemSettings;
  onClose: () => void;
  onOpenApp: (appId: AppId, customData?: Record<string, any>) => void;
  onPowerAction?: (action: 'restart' | 'shutdown' | 'sleep' | 'lock') => void;
}

interface AppItem {
  id: string;
  name: string;
  appId: AppId;
  category?: string;
  icon: React.ReactNode;
  customData?: Record<string, any>;
}

export const StartMenu: React.FC<StartMenuProps> = ({
  isOpen,
  settings,
  onClose,
  onOpenApp,
  onPowerAction,
}) => {
  const isDark = settings.theme === 'dark';
  const hasTransparency = settings.transparencyEffects !== false;
  const accentColor = settings.accentColor || '#0078d4';

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'pinned' | 'all'>('pinned');
  const [showPowerMenu, setShowPowerMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setViewMode('pinned');
      setShowPowerMenu(false);
      setShowUserMenu(false);
      setSearchQuery('');
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const allAppsList: AppItem[] = [
    {
      id: 'camera',
      name: 'Camera',
      appId: 'browser',
      category: 'C',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center text-white shadow-xs">
          <Camera className="w-4 h-4 text-sky-400" />
        </div>
      ),
    },
    {
      id: 'calculator',
      name: 'Calculator',
      appId: 'calculator',
      category: 'C',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-b from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-xs">
          <Calculator className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'copilot',
      name: 'Copilot AI',
      appId: 'copilot',
      category: 'C',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-sky-400 via-indigo-500 to-fuchsia-500 flex items-center justify-center text-white shadow-xs">
          <Sparkles className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'edge',
      name: 'Microsoft Edge',
      appId: 'browser',
      category: 'E',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-xs">
          <Globe className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'explorer',
      name: 'File Explorer',
      appId: 'explorer',
      category: 'F',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-b from-amber-300 to-amber-500 flex items-center justify-center shadow-xs">
          <Folder className="w-4 h-4 text-amber-950 fill-amber-100/50" />
        </div>
      ),
    },
    {
      id: 'mail',
      name: 'Mail',
      appId: 'browser',
      category: 'M',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center text-white shadow-xs">
          <Mail className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'media-player',
      name: 'Media Player',
      appId: 'browser',
      category: 'M',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-b from-orange-500 to-amber-600 flex items-center justify-center text-white shadow-xs">
          <Music className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'notepad',
      name: 'Notepad',
      appId: 'notepad',
      category: 'N',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-b from-sky-400 to-blue-600 flex items-center justify-center text-white shadow-xs">
          <FileText className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'photos',
      name: 'Photos',
      appId: 'explorer',
      category: 'P',
      customData: { initialPath: 'Pictures' },
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-white shadow-xs">
          <ImageIcon className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'settings',
      name: 'Settings',
      appId: 'settings',
      category: 'S',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-gradient-to-b from-slate-400 to-slate-600 flex items-center justify-center text-white shadow-xs">
          <Settings className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'terminal',
      name: 'Terminal',
      appId: 'copilot',
      category: 'T',
      icon: (
        <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center text-emerald-400 shadow-xs">
          <Terminal className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'security',
      name: 'Windows Security',
      appId: 'settings',
      category: 'W',
      customData: { tab: 'privacy' },
      icon: (
        <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
          <Shield className="w-4 h-4" />
        </div>
      ),
    },
  ];

  const pinnedAppIds = ['copilot', 'edge', 'explorer', 'settings', 'notepad', 'calculator', 'terminal', 'mail'];
  const pinnedApps = allAppsList.filter((app) => pinnedAppIds.includes(app.id));

  const recommendedItems = [
    {
      title: 'Meeting-Notes.txt',
      subtitle: 'Desktop • 15m ago',
      icon: <FileText className="w-4 h-4 text-sky-500" />,
      action: () =>
        onOpenApp('notepad', {
          fileName: 'Meeting-Notes.txt',
          content: 'Windows 11 Desktop Pro Project Meeting Notes\n- All personalization settings updated live\n- Start Menu with Pinned, All Apps, and Power Options\n- Wallpaper engine responsive and smooth\n',
        }),
    },
    {
      title: 'Copilot: Research Summary',
      subtitle: 'Recently generated',
      icon: <Sparkles className="w-4 h-4 text-violet-500" />,
      action: () => onOpenApp('copilot'),
    },
    {
      title: 'Personalization Settings',
      subtitle: 'Recently modified',
      icon: <Settings className="w-4 h-4 text-pink-500" />,
      action: () => onOpenApp('settings', { tab: 'personalization' }),
    },
    {
      title: 'Documents Folder',
      subtitle: 'File Explorer • 1h ago',
      icon: <Folder className="w-4 h-4 text-amber-500 fill-amber-500/20" />,
      action: () => onOpenApp('explorer', { initialPath: 'Documents' }),
    },
  ];

  // Filtering
  const filteredApps = allAppsList.filter((a) =>
    a.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleLaunch = (app: AppItem) => {
    onOpenApp(app.appId, app.customData);
    onClose();
  };

  const handleKeyDownInput = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && filteredApps.length > 0) {
      handleLaunch(filteredApps[0]);
    }
  };

  return (
    <div
      onClick={(e) => {
        e.stopPropagation();
        setShowPowerMenu(false);
        setShowUserMenu(false);
      }}
      className={`fixed bottom-14 z-50 w-[95vw] max-w-[540px] rounded-2xl border shadow-2xl p-5 flex flex-col transition-all duration-200 select-none ${
        hasTransparency ? 'backdrop-blur-3xl' : ''
      } ${
        settings.taskbarAlignment === 'center'
          ? 'left-1/2 -translate-x-1/2'
          : 'left-2 sm:left-4'
      } ${
        isDark
          ? hasTransparency
            ? 'bg-slate-900/90 border-white/10 text-slate-100 shadow-black/80'
            : 'bg-slate-900 border-slate-800 text-slate-100'
          : hasTransparency
          ? 'bg-white/92 border-slate-200/80 text-slate-800 shadow-slate-400/40'
          : 'bg-white border-slate-200 text-slate-800'
      }`}
      style={{ maxHeight: '620px' }}
    >
      {/* Top Search Bar */}
      <div
        style={{
          boxShadow: searchQuery ? `0 0 0 2px ${accentColor}30` : undefined,
        }}
        className={`flex items-center px-4 py-2.5 rounded-full border mb-4 transition-all ${
          isDark
            ? 'bg-slate-950/70 border-slate-700/70 focus-within:border-transparent'
            : 'bg-slate-100/90 border-slate-200/90 focus-within:bg-white focus-within:border-transparent'
        }`}
      >
        <Search className="w-4 h-4 text-slate-400 mr-2.5 shrink-0" />
        <input
          ref={searchInputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={handleKeyDownInput}
          placeholder="Type here to search apps, settings, and files..."
          className="w-full bg-transparent border-0 focus:outline-hidden text-xs placeholder:text-slate-400"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="text-[10px] text-slate-400 hover:text-slate-200 px-1"
          >
            Clear
          </button>
        )}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto min-h-[360px] max-h-[420px] pr-1">
        {searchQuery ? (
          /* Search Results View */
          <div>
            <div className="flex items-center justify-between mb-2.5 px-1">
              <span className="text-xs font-semibold">Best match</span>
              <span className="text-[11px] text-slate-400">{filteredApps.length} found</span>
            </div>

            {filteredApps.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                No apps or settings found matching &quot;{searchQuery}&quot;
              </div>
            ) : (
              <div className="space-y-1">
                {filteredApps.map((app, idx) => (
                  <button
                    key={app.id}
                    type="button"
                    onClick={() => handleLaunch(app)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all cursor-pointer ${
                      idx === 0
                        ? isDark
                          ? 'bg-slate-800/80 border border-slate-700/60'
                          : 'bg-slate-100 border border-slate-200'
                        : isDark
                        ? 'hover:bg-slate-800/50'
                        : 'hover:bg-slate-100/80'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div>{app.icon}</div>
                      <div>
                        <div className="text-xs font-medium">{app.name}</div>
                        <div className="text-[10px] text-slate-400">Desktop app</div>
                      </div>
                    </div>
                    {idx === 0 && (
                      <span
                        style={{ color: accentColor }}
                        className="text-[11px] font-medium pr-2"
                      >
                        Press Enter ↵
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : viewMode === 'pinned' ? (
          /* Pinned & Recommended View */
          <>
            {/* Pinned Header */}
            <div className="flex items-center justify-between mb-3 px-1">
              <span className="text-xs font-semibold">Pinned</span>
              <button
                type="button"
                onClick={() => setViewMode('all')}
                className={`text-[11px] font-medium px-2 py-1 rounded-md flex items-center space-x-1 transition-colors cursor-pointer ${
                  isDark ? 'text-slate-300 hover:bg-slate-800' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>All apps</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            {/* Pinned Grid */}
            <div className="grid grid-cols-4 gap-2 mb-6">
              {pinnedApps.map((app) => (
                <button
                  key={app.id}
                  type="button"
                  onClick={() => handleLaunch(app)}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl transition-all cursor-pointer group ${
                    isDark ? 'hover:bg-slate-800/70' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="mb-2 group-hover:scale-105 transition-transform">{app.icon}</div>
                  <span className="text-[11px] font-medium truncate max-w-[84px] text-center">
                    {app.name}
                  </span>
                </button>
              ))}
            </div>

            {/* Recommended Section */}
            <div className="mb-2">
              <div className="flex items-center justify-between mb-2.5 px-1">
                <span className="text-xs font-semibold">Recommended</span>
                <span className="text-[10px] text-slate-400">Recent items</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {recommendedItems.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      item.action();
                      onClose();
                    }}
                    className={`flex items-center space-x-2.5 p-2 rounded-xl text-left transition-colors cursor-pointer ${
                      isDark ? 'hover:bg-slate-800/60' : 'hover:bg-slate-100'
                    }`}
                  >
                    <div className="shrink-0">{item.icon}</div>
                    <div className="truncate">
                      <div className="text-xs font-medium truncate">{item.title}</div>
                      <div className="text-[10px] text-slate-400 truncate">{item.subtitle}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </>
        ) : (
          /* All Apps A-Z List View */
          <div>
            <div className="flex items-center justify-between mb-3 px-1">
              <button
                type="button"
                onClick={() => setViewMode('pinned')}
                className={`text-[11px] font-medium px-2 py-1 rounded-md flex items-center space-x-1 transition-colors cursor-pointer ${
                  isDark ? 'text-slate-300 hover:bg-slate-800' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ChevronLeft className="w-3 h-3" />
                <span>Back to Pinned</span>
              </button>
              <span className="text-xs font-semibold">All apps (A-Z)</span>
            </div>

            <div className="space-y-1">
              {allAppsList
                .sort((a, b) => a.name.localeCompare(b.name))
                .map((app) => (
                  <button
                    key={app.id}
                    type="button"
                    onClick={() => handleLaunch(app)}
                    className={`w-full flex items-center space-x-3 p-2 rounded-xl text-left transition-colors cursor-pointer ${
                      isDark ? 'hover:bg-slate-800/60' : 'hover:bg-slate-100'
                    }`}
                  >
                    <div>{app.icon}</div>
                    <div className="flex-1">
                      <div className="text-xs font-medium">{app.name}</div>
                      <div className="text-[10px] text-slate-400">Windows 11 Application</div>
                    </div>
                  </button>
                ))}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Profile & Power Bar */}
      <div
        className={`pt-3 mt-2 border-t flex items-center justify-between px-1 relative ${
          isDark ? 'border-slate-800/90' : 'border-slate-200'
        }`}
      >
        {/* User Profile Button with Menu */}
        <div className="relative">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowUserMenu(!showUserMenu);
              setShowPowerMenu(false);
            }}
            className={`flex items-center space-x-2.5 p-1.5 rounded-xl transition-colors cursor-pointer ${
              showUserMenu
                ? isDark
                  ? 'bg-slate-800'
                  : 'bg-slate-100'
                : isDark
                ? 'hover:bg-slate-800/60'
                : 'hover:bg-slate-100'
            }`}
          >
            <div
              style={{ backgroundColor: accentColor }}
              className="w-7 h-7 rounded-full text-white flex items-center justify-center font-semibold text-xs shadow-xs"
            >
              W
            </div>
            <div className="text-left">
              <div className="text-xs font-medium leading-none">Windows User</div>
              <div className="text-[9px] text-slate-400 leading-none mt-1">Administrator</div>
            </div>
          </button>

          {/* User Profile Flyout Menu */}
          {showUserMenu && (
            <div
              onClick={(e) => e.stopPropagation()}
              className={`absolute bottom-12 left-0 w-60 rounded-xl border shadow-2xl p-2 text-xs backdrop-blur-2xl z-50 animate-in fade-in zoom-in-95 duration-150 ${
                isDark
                  ? 'bg-slate-900/95 border-slate-700 text-slate-200'
                  : 'bg-white/95 border-slate-200 text-slate-800'
              }`}
            >
              <div className="flex items-center space-x-3 p-2 mb-1 border-b border-slate-800/40">
                <div
                  style={{ backgroundColor: accentColor }}
                  className="w-8 h-8 rounded-full text-white flex items-center justify-center font-semibold text-sm"
                >
                  W
                </div>
                <div>
                  <div className="font-semibold text-xs">Windows User</div>
                  <div className="text-[10px] text-slate-400">user@windows.pro</div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setShowUserMenu(false);
                  onOpenApp('settings', { tab: 'accounts' });
                  onClose();
                }}
                className="w-full flex items-center space-x-2.5 px-2.5 py-2 rounded-lg hover:bg-blue-600 hover:text-white text-left transition-colors cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>Change account settings</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowUserMenu(false);
                  onPowerAction?.('lock');
                  onClose();
                }}
                className="w-full flex items-center space-x-2.5 px-2.5 py-2 rounded-lg hover:bg-blue-600 hover:text-white text-left transition-colors cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Lock screen</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowUserMenu(false);
                  onPowerAction?.('lock');
                  onClose();
                }}
                className="w-full flex items-center space-x-2.5 px-2.5 py-2 rounded-lg hover:bg-rose-600 hover:text-white text-left transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign out</span>
              </button>
            </div>
          )}
        </div>

        {/* Power Button with Menu */}
        <div className="relative">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowPowerMenu(!showPowerMenu);
              setShowUserMenu(false);
            }}
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              showPowerMenu
                ? isDark
                  ? 'bg-slate-800'
                  : 'bg-slate-200'
                : isDark
                ? 'hover:bg-slate-800 text-slate-300'
                : 'hover:bg-slate-200 text-slate-700'
            }`}
            title="Power"
          >
            <Power className="w-4 h-4" />
          </button>

          {/* Power Flyout */}
          {showPowerMenu && (
            <div
              onClick={(e) => e.stopPropagation()}
              className={`absolute bottom-12 right-0 w-44 rounded-xl border shadow-2xl p-1.5 text-xs backdrop-blur-2xl z-50 animate-in fade-in zoom-in-95 duration-150 ${
                isDark
                  ? 'bg-slate-900/95 border-slate-700 text-slate-200'
                  : 'bg-white/95 border-slate-200 text-slate-800'
              }`}
            >
              <button
                type="button"
                onClick={() => {
                  setShowPowerMenu(false);
                  onPowerAction?.('sleep');
                  onClose();
                }}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg hover:bg-blue-600 hover:text-white text-left transition-colors cursor-pointer"
              >
                <Moon className="w-3.5 h-3.5" />
                <div>
                  <div className="font-medium">Sleep</div>
                  <div className="text-[9px] opacity-75">Saves session in memory</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowPowerMenu(false);
                  onPowerAction?.('restart');
                  onClose();
                }}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg hover:bg-blue-600 hover:text-white text-left transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <div>
                  <div className="font-medium">Restart</div>
                  <div className="text-[9px] opacity-75">Reboots system safely</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowPowerMenu(false);
                  onPowerAction?.('shutdown');
                  onClose();
                }}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg hover:bg-rose-600 hover:text-white text-left transition-colors cursor-pointer"
              >
                <Power className="w-3.5 h-3.5" />
                <div>
                  <div className="font-medium">Shut down</div>
                  <div className="text-[9px] opacity-75">Closes all apps & turns off</div>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
