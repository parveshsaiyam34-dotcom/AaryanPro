import React, { useState } from 'react';
import { Search, Sparkles, Folder, Settings, FileText, Calculator, Globe, Clock, ArrowRight } from 'lucide-react';
import { AppId, SystemSettings } from '../../types';

interface SearchFlyoutProps {
  isOpen: boolean;
  settings: SystemSettings;
  onClose: () => void;
  onOpenApp: (appId: AppId) => void;
}

export const SearchFlyout: React.FC<SearchFlyoutProps> = ({
  isOpen,
  settings,
  onClose,
  onOpenApp,
}) => {
  const isDark = settings.theme === 'dark';
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const quickApps: { id: AppId; name: string; icon: any; color: string }[] = [
    { id: 'copilot', name: 'Copilot', icon: Sparkles, color: 'text-sky-400' },
    { id: 'explorer', name: 'File Explorer', icon: Folder, color: 'text-amber-400' },
    { id: 'browser', name: 'Edge Browser', icon: Globe, color: 'text-blue-500' },
    { id: 'notepad', name: 'Notepad', icon: FileText, color: 'text-sky-500' },
    { id: 'calculator', name: 'Calculator', icon: Calculator, color: 'text-emerald-400' },
    { id: 'settings', name: 'Settings', icon: Settings, color: 'text-slate-400' },
  ];

  const filteredApps = quickApps.filter((app) =>
    app.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className={`fixed bottom-14 z-50 w-[95vw] max-w-[500px] rounded-2xl border shadow-2xl backdrop-blur-3xl p-4 flex flex-col transition-all animate-in fade-in-50 zoom-in-95 duration-200 select-none ${
        settings.taskbarAlignment === 'center' ? 'left-1/2 -translate-x-1/2' : 'left-12'
      } ${
        isDark
          ? 'bg-slate-900/90 border-white/10 text-slate-100 shadow-black/80'
          : 'bg-white/90 border-slate-200/80 text-slate-800 shadow-slate-400/40'
      }`}
    >
      {/* Search Input Bar */}
      <div
        className={`flex items-center px-4 py-2.5 rounded-xl border mb-4 transition-colors ${
          isDark
            ? 'bg-slate-950/70 border-slate-700 focus-within:border-blue-500'
            : 'bg-slate-100 border-slate-200 focus-within:bg-white focus-within:border-blue-500'
        }`}
      >
        <Search className="w-4 h-4 text-slate-400 mr-2.5 shrink-0" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type here to search..."
          className="w-full bg-transparent border-0 focus:outline-hidden text-xs"
          autoFocus
        />
      </div>

      {/* Top apps */}
      <div className="space-y-1">
        <div className="text-[11px] font-semibold text-slate-400 px-2 py-1 uppercase tracking-wider">
          Top Apps
        </div>
        {filteredApps.map((app) => {
          const Icon = app.icon;
          return (
            <button
              key={app.id}
              type="button"
              onClick={() => {
                onOpenApp(app.id);
                onClose();
              }}
              className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-colors cursor-pointer ${
                isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`p-1.5 rounded-lg bg-slate-800/40 ${app.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium">{app.name}</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            </button>
          );
        })}
      </div>
    </div>
  );
};
