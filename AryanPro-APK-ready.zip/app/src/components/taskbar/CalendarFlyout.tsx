import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Bell, Trash2, Clock, Sparkles, Shield } from 'lucide-react';
import { SystemSettings } from '../../types';

interface CalendarFlyoutProps {
  isOpen: boolean;
  settings: SystemSettings;
  onClose: () => void;
}

export const CalendarFlyout: React.FC<CalendarFlyoutProps> = ({
  isOpen,
  settings,
}) => {
  const isDark = settings.theme === 'dark';
  const [liveDate, setLiveDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setLiveDate(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const [currentMonth, setCurrentMonth] = useState(liveDate.getMonth());
  const [currentYear, setCurrentYear] = useState(liveDate.getFullYear());
  const [notifications, setNotifications] = useState([
    {
      id: 'n1',
      title: 'Windows Security',
      desc: 'No actions needed. Virus & threat protection is active.',
      time: '15m ago',
      icon: <Shield className="w-3.5 h-3.5 text-blue-500" />,
    },
    {
      id: 'n2',
      title: 'Copilot AI Assistant',
      desc: 'Gemini Flash model is connected and responsive.',
      time: '1h ago',
      icon: <Sparkles className="w-3.5 h-3.5 text-purple-500" />,
    },
  ]);

  if (!isOpen) return null;

  // Month navigation
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  // Days in month calculation
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayIndex = new Date(currentYear, currentMonth, 1).getDay(); // 0 = Sun

  const daysArray = [];
  for (let i = 0; i < firstDayIndex; i++) {
    daysArray.push(null);
  }
  for (let i = 1; i <= daysInMonth; i++) {
    daysArray.push(i);
  }

  const isToday = (day: number) => {
    const now = new Date();
    return (
      day === now.getDate() &&
      currentMonth === now.getMonth() &&
      currentYear === now.getFullYear()
    );
  };

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className={`fixed bottom-14 right-3 z-50 w-[95vw] max-w-[360px] rounded-2xl border shadow-2xl backdrop-blur-3xl p-4 flex flex-col space-y-4 transition-all animate-in fade-in-50 zoom-in-95 duration-200 select-none ${
        isDark
          ? 'bg-slate-900/90 border-white/10 text-slate-100 shadow-black/80'
          : 'bg-white/90 border-slate-200/80 text-slate-800 shadow-slate-400/40'
      }`}
    >
      {/* Live Digital Clock & Date Header */}
      <div className="flex items-baseline justify-between px-1 pb-1 border-b border-slate-700/20 dark:border-slate-800">
        <div>
          <div className="text-2xl font-light tracking-tight font-mono">
            {liveDate.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true })}
          </div>
          <div className="text-xs text-blue-500 font-medium">
            {liveDate.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
          </div>
        </div>
        <div className="flex items-center space-x-1 text-slate-400 text-[11px]">
          <Clock className="w-3.5 h-3.5 text-blue-400" />
          <span>Real-time</span>
        </div>
      </div>

      {/* Notifications Header */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-1.5 font-semibold text-xs">
            <Bell className="w-3.5 h-3.5 text-blue-500" />
            <span>Notifications</span>
          </div>
          {notifications.length > 0 && (
            <button
              type="button"
              onClick={() => setNotifications([])}
              className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center space-x-1 cursor-pointer"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear all</span>
            </button>
          )}
        </div>

        {notifications.length === 0 ? (
          <div className="text-center py-2 text-[11px] text-slate-400">
            No new notifications
          </div>
        ) : (
          <div className="space-y-1.5 max-h-28 overflow-y-auto">
            {notifications.map((n) => (
              <div
                key={n.id}
                className={`p-2.5 rounded-xl border text-xs ${
                  isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center space-x-1.5 font-medium">
                    {n.icon}
                    <span>{n.title}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{n.time}</span>
                </div>
                <div className={`text-[11px] ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                  {n.desc}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className={`border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

      {/* Calendar Section */}
      <div>
        {/* Month Header with Controls */}
        <div className="flex items-center justify-between mb-3 px-1">
          <span className="font-semibold text-xs">
            {monthNames[currentMonth]} {currentYear}
          </span>
          <div className="flex items-center space-x-1">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1 rounded-md hover:bg-slate-700/30 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1 rounded-md hover:bg-slate-700/30 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Days of week */}
        <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-medium text-slate-400 mb-1">
          <span>Su</span>
          <span>Mo</span>
          <span>Tu</span>
          <span>We</span>
          <span>Th</span>
          <span>Fr</span>
          <span>Sa</span>
        </div>

        {/* Calendar Day Cells */}
        <div className="grid grid-cols-7 gap-1 text-center text-xs">
          {daysArray.map((day, idx) => {
            if (day === null) {
              return <div key={`empty-${idx}`} className="h-7 w-7" />;
            }
            const active = isToday(day);
            return (
              <div
                key={`day-${day}`}
                className={`h-7 w-7 mx-auto rounded-full flex items-center justify-center text-xs cursor-pointer transition-colors ${
                  active
                    ? 'bg-blue-600 text-white font-bold shadow-xs'
                    : isDark
                    ? 'hover:bg-slate-800 text-slate-200'
                    : 'hover:bg-slate-200 text-slate-800'
                }`}
              >
                {day}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
