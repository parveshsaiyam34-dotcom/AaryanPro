import React, { useState, useEffect } from 'react';
import {
  Search,
  Sparkles,
  Folder,
  Settings,
  FileText,
  Calculator,
  Globe,
  Wifi,
  Volume2,
  BatteryCharging,
  ChevronUp,
  Bell,
} from 'lucide-react';
import { AppId, SystemSettings, WindowState } from '../../types';

interface TaskbarProps {
  windows: WindowState[];
  activeWindowId: string | null;
  settings: SystemSettings;
  isStartMenuOpen: boolean;
  isSearchOpen: boolean;
  isQuickSettingsOpen: boolean;
  isCalendarOpen: boolean;
  onToggleStartMenu: () => void;
  onToggleSearch: () => void;
  onToggleQuickSettings: () => void;
  onToggleCalendar: () => void;
  onOpenApp: (appId: AppId) => void;
  onTaskbarAppClick: (appId: AppId) => void;
  onShowDesktop: () => void;
}

export const Taskbar: React.FC<TaskbarProps> = ({
  windows,
  activeWindowId,
  settings,
  isStartMenuOpen,
  isSearchOpen,
  isQuickSettingsOpen,
  isCalendarOpen,
  onToggleStartMenu,
  onToggleSearch,
  onToggleQuickSettings,
  onToggleCalendar,
  onOpenApp,
  onTaskbarAppClick,
  onShowDesktop,
}) => {
  const isDark = settings.theme === 'dark';

  // Live Clock updated every second
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
      );
      setDateStr(
        now.toLocaleDateString([], { month: 'numeric', day: 'numeric', year: 'numeric' })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const pinnedApps: { id: AppId; name: string; icon: React.ReactNode }[] = [
    {
      id: 'copilot',
      name: 'Copilot',
      icon: (
        <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-sky-400 via-indigo-500 to-fuchsia-500 flex items-center justify-center text-white shadow-xs">
          <Sparkles className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'explorer',
      name: 'File Explorer',
      icon: (
        <div className="w-7 h-7 rounded-lg bg-gradient-to-b from-amber-300 to-amber-500 flex items-center justify-center shadow-xs">
          <Folder className="w-4 h-4 text-amber-950 fill-amber-100/50" />
        </div>
      ),
    },
    {
      id: 'browser',
      name: 'Microsoft Edge',
      icon: (
        <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-xs">
          <Globe className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'notepad',
      name: 'Notepad',
      icon: (
        <div className="w-7 h-7 rounded-lg bg-gradient-to-b from-sky-400 to-blue-600 flex items-center justify-center text-white shadow-xs">
          <FileText className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'calculator',
      name: 'Calculator',
      icon: (
        <div className="w-7 h-7 rounded-lg bg-gradient-to-b from-emerald-400 to-teal-600 flex items-center justify-center text-white shadow-xs">
          <Calculator className="w-4 h-4" />
        </div>
      ),
    },
    {
      id: 'settings',
      name: 'Settings',
      icon: (
        <div className="w-7 h-7 rounded-lg bg-gradient-to-b from-slate-400 to-slate-600 flex items-center justify-center text-white shadow-xs">
          <Settings className="w-4 h-4" />
        </div>
      ),
    },
  ];

  const accentColor = settings.accentColor || '#0078d4';
  const showAccentBar = settings.showAccentOnTaskbar;

  return (
    <footer
      onClick={(e) => e.stopPropagation()}
      style={{
        borderTopColor: showAccentBar ? `${accentColor}50` : undefined,
        boxShadow: showAccentBar ? `0 -1px 8px ${accentColor}25` : undefined,
      }}
      className={`fixed bottom-0 left-0 right-0 h-12 z-40 flex items-center justify-between px-2 select-none border-t transition-colors ${
        settings.transparencyEffects !== false
          ? isDark
            ? 'backdrop-blur-2xl bg-slate-900/85 border-white/10 text-slate-200'
            : 'backdrop-blur-2xl bg-white/85 border-slate-200/80 text-slate-800'
          : isDark
          ? 'bg-slate-900 border-slate-800 text-slate-200'
          : 'bg-white border-slate-200 text-slate-800'
      }`}
    >
      {/* Left side empty space or Left-aligned cluster */}
      {settings.taskbarAlignment === 'center' && settings.taskbarWidgets !== false && (
        <div className="flex items-center space-x-2 w-32 hidden sm:flex shrink-0">
          {/* Weather Widget simulation on left */}
          <div
            onClick={(e) => {
              e.stopPropagation();
              onOpenApp('browser');
            }}
            className="flex items-center space-x-2 px-2.5 py-1 rounded-lg hover:bg-white/10 cursor-pointer text-xs transition-colors"
          >
            <span className="text-amber-400 font-semibold">72°F</span>
            <span className="text-[11px] text-slate-400 hidden md:inline">Sunny</span>
          </div>
        </div>
      )}

      {/* Main Apps Taskbar Cluster (Center or Left) */}
      <div
        className={`flex items-center space-x-1 ${
          settings.taskbarAlignment === 'center'
            ? 'sm:absolute sm:left-1/2 sm:-translate-x-1/2 flex-1 sm:flex-none justify-start sm:justify-center overflow-x-auto sm:overflow-visible no-scrollbar'
            : 'flex-1 justify-start ml-1 overflow-x-auto sm:overflow-visible no-scrollbar'
        }`}
      >
        {/* Windows 11 Start Button (Geometric 4-quadrant design) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleStartMenu();
          }}
          className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
            isStartMenuOpen
              ? 'bg-white/25 dark:bg-white/20 shadow-xs'
              : 'hover:bg-white/15 dark:hover:bg-white/10'
          }`}
          title="Start"
        >
          <div className="grid grid-cols-2 gap-0.5 w-4 h-4">
            <div className="bg-sky-400 rounded-xs" />
            <div className="bg-sky-500 rounded-xs" />
            <div className="bg-blue-600 rounded-xs" />
            <div className="bg-blue-500 rounded-xs" />
          </div>
        </button>

        {/* Windows 11 Search Button */}
        {settings.taskbarSearch !== 'hide' && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleSearch();
            }}
            className={`transition-all cursor-pointer flex items-center ${
              settings.taskbarSearch === 'icon'
                ? `w-10 h-10 justify-center rounded-lg ${
                    isSearchOpen
                      ? 'bg-white/25 dark:bg-white/20 shadow-xs'
                      : 'hover:bg-white/15 dark:hover:bg-white/10'
                  }`
                : `h-9 px-3 rounded-full space-x-2.5 border ${
                    isDark
                      ? 'bg-slate-800/80 border-slate-700/60 hover:bg-slate-700/80 text-slate-300'
                      : 'bg-slate-100/90 border-slate-200/80 hover:bg-slate-200/90 text-slate-700'
                  }`
            }`}
            title="Search"
          >
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            {settings.taskbarSearch !== 'icon' && (
              <span className="text-xs text-slate-400 hidden md:inline font-normal">Search</span>
            )}
          </button>
        )}

        {/* Pinned & Running Apps */}
        {pinnedApps
          .filter((app) => (app.id === 'copilot' ? settings.taskbarCopilot !== false : true))
          .map((app) => {
            const appWindows = windows.filter((w) => w.appId === app.id && w.isOpen);
            const isRunning = appWindows.length > 0;
            const isFocused = appWindows.some((w) => w.id === activeWindowId && !w.isMinimized);

            return (
              <button
                key={app.id}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onTaskbarAppClick(app.id);
                }}
                className={`relative w-10 h-10 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                  isFocused
                    ? 'bg-white/25 dark:bg-white/20 shadow-xs'
                    : 'hover:bg-white/15 dark:hover:bg-white/10'
                }`}
                title={app.name}
              >
                {app.icon}

                {/* Running Pill Indicator */}
                {isRunning && (
                  <div
                    style={{
                      backgroundColor: isFocused
                        ? settings.showAccentOnTaskbar !== false
                          ? settings.accentColor
                          : '#3b82f6'
                        : undefined,
                    }}
                    className={`absolute bottom-0.5 rounded-full transition-all ${
                      isFocused
                        ? 'w-4 h-1'
                        : 'w-1.5 h-1.5 bg-slate-400 dark:bg-slate-300'
                    }`}
                  />
                )}
              </button>
            );
          })}
      </div>

      {/* System Tray (Right Side) */}
      <div className="flex items-center space-x-1 shrink-0 ml-auto">
        {/* Hidden icons caret */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
          }}
          className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 transition-colors hidden sm:block cursor-pointer"
          title="Show hidden icons"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>

        {/* Quick Settings Group (Wi-Fi + Audio + Battery) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleQuickSettings();
          }}
          className={`flex items-center space-x-2 px-2 py-1.5 rounded-lg transition-all cursor-pointer ${
            isQuickSettingsOpen
              ? 'bg-white/25 dark:bg-white/20 ring-1 ring-white/20'
              : 'hover:bg-white/15 dark:hover:bg-white/10'
          }`}
          title="Quick settings"
        >
          <Wifi className="w-3.5 h-3.5" />
          <Volume2 className="w-3.5 h-3.5" />
          <BatteryCharging className="w-3.5 h-3.5 text-emerald-500" />
        </button>

        {/* Clock & Date Area */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleCalendar();
          }}
          className={`flex flex-col items-end px-2 py-1 rounded-lg text-right transition-all cursor-pointer ${
            isCalendarOpen
              ? 'bg-white/25 dark:bg-white/20 ring-1 ring-white/20'
              : 'hover:bg-white/15 dark:hover:bg-white/10'
          }`}
          title="Date and Time"
        >
          <span className="text-[11px] font-medium leading-none mb-0.5 font-mono">{timeStr}</span>
          <span className="text-[10px] text-slate-400 leading-none">{dateStr}</span>
        </button>

        {/* Notification Bell */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleCalendar();
          }}
          className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 transition-colors hidden sm:block cursor-pointer"
          title="Notifications"
        >
          <Bell className="w-3.5 h-3.5" />
        </button>

        {/* Show Desktop Sliver */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onShowDesktop();
          }}
          className="w-1.5 h-7 rounded-xs hover:bg-white/30 border-l border-slate-700/30 ml-1 transition-colors cursor-pointer"
          title="Show desktop"
        />
      </div>
    </footer>
  );
};
