import React from 'react';
import {
  Wifi,
  WifiOff,
  Bluetooth,
  Plane,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  BatteryCharging,
  Sliders,
  Settings as SettingsIcon,
} from 'lucide-react';
import { SystemSettings, AppId } from '../../types';

interface QuickSettingsFlyoutProps {
  isOpen: boolean;
  settings: SystemSettings;
  onClose: () => void;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  onOpenApp: (appId: AppId) => void;
}

export const QuickSettingsFlyout: React.FC<QuickSettingsFlyoutProps> = ({
  isOpen,
  settings,
  onClose,
  onUpdateSettings,
  onOpenApp,
}) => {
  const isDark = settings.theme === 'dark';

  if (!isOpen) return null;

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className={`fixed bottom-14 right-3 z-50 w-[95vw] max-w-[340px] rounded-2xl border shadow-2xl backdrop-blur-3xl p-4 flex flex-col space-y-4 transition-all animate-in fade-in-50 zoom-in-95 duration-200 select-none ${
        isDark
          ? 'bg-slate-900/90 border-white/10 text-slate-100 shadow-black/80'
          : 'bg-white/90 border-slate-200/80 text-slate-800 shadow-slate-400/40'
      }`}
    >
      {/* 2x3 Quick Action Toggles */}
      <div className="grid grid-cols-3 gap-2">
        {/* Wi-Fi */}
        <button
          type="button"
          onClick={() => onUpdateSettings({ wifiEnabled: !settings.wifiEnabled })}
          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
            settings.wifiEnabled
              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
              : isDark
              ? 'bg-slate-800/60 border-slate-700/60 text-slate-400'
              : 'bg-slate-100 border-slate-200 text-slate-600'
          }`}
        >
          {settings.wifiEnabled ? <Wifi className="w-4 h-4 mb-1" /> : <WifiOff className="w-4 h-4 mb-1" />}
          <span className="text-[10px] font-medium">Wi-Fi</span>
        </button>

        {/* Bluetooth */}
        <button
          type="button"
          onClick={() => onUpdateSettings({ bluetoothEnabled: !settings.bluetoothEnabled })}
          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
            settings.bluetoothEnabled
              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
              : isDark
              ? 'bg-slate-800/60 border-slate-700/60 text-slate-400'
              : 'bg-slate-100 border-slate-200 text-slate-600'
          }`}
        >
          <Bluetooth className="w-4 h-4 mb-1" />
          <span className="text-[10px] font-medium">Bluetooth</span>
        </button>

        {/* Theme Mode Toggle */}
        <button
          type="button"
          onClick={() => onUpdateSettings({ theme: isDark ? 'light' : 'dark' })}
          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
            isDark
              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
              : 'bg-slate-100 border-slate-200 text-slate-700'
          }`}
        >
          {isDark ? <Moon className="w-4 h-4 mb-1" /> : <Sun className="w-4 h-4 mb-1" />}
          <span className="text-[10px] font-medium">{isDark ? 'Dark' : 'Light'}</span>
        </button>

        {/* Night Light */}
        <button
          type="button"
          onClick={() => onUpdateSettings({ nightLight: !settings.nightLight })}
          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
            settings.nightLight
              ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
              : isDark
              ? 'bg-slate-800/60 border-slate-700/60 text-slate-400'
              : 'bg-slate-100 border-slate-200 text-slate-600'
          }`}
        >
          <Moon className="w-4 h-4 mb-1" />
          <span className="text-[10px] font-medium">Night Light</span>
        </button>

        {/* Airplane Mode */}
        <button
          type="button"
          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
            isDark
              ? 'bg-slate-800/60 border-slate-700/60 text-slate-400'
              : 'bg-slate-100 border-slate-200 text-slate-600'
          }`}
        >
          <Plane className="w-4 h-4 mb-1" />
          <span className="text-[10px] font-medium">Airplane</span>
        </button>

        {/* Settings button */}
        <button
          type="button"
          onClick={() => {
            onOpenApp('settings');
            onClose();
          }}
          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
            isDark
              ? 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:bg-slate-800'
              : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <SettingsIcon className="w-4 h-4 mb-1" />
          <span className="text-[10px] font-medium">Settings</span>
        </button>
      </div>

      {/* Sliders Area */}
      <div className="space-y-3 pt-1">
        {/* Brightness */}
        <div className="flex items-center space-x-3">
          <Sun className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="range"
            min="0"
            max="100"
            value={settings.brightness}
            onChange={(e) => onUpdateSettings({ brightness: parseInt(e.target.value) })}
            className="flex-1 accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer"
          />
          <span className="text-[11px] font-mono text-slate-400 w-8 text-right">
            {settings.brightness}%
          </span>
        </div>

        {/* Volume */}
        <div className="flex items-center space-x-3">
          {settings.volume === 0 ? (
            <VolumeX className="w-4 h-4 text-slate-400 shrink-0" />
          ) : (
            <Volume2 className="w-4 h-4 text-slate-400 shrink-0" />
          )}
          <input
            type="range"
            min="0"
            max="100"
            value={settings.volume}
            onChange={(e) => onUpdateSettings({ volume: parseInt(e.target.value) })}
            className="flex-1 accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer"
          />
          <span className="text-[11px] font-mono text-slate-400 w-8 text-right">
            {settings.volume}%
          </span>
        </div>
      </div>

      {/* Battery and Status footer */}
      <div
        className={`pt-2 border-t flex items-center justify-between text-xs text-slate-400 ${
          isDark ? 'border-slate-800' : 'border-slate-200'
        }`}
      >
        <div className="flex items-center space-x-2">
          <BatteryCharging className="w-4 h-4 text-emerald-500" />
          <span className="text-[11px] font-medium">96% • Fully charged</span>
        </div>

        <button
          type="button"
          onClick={() => {
            onOpenApp('settings');
            onClose();
          }}
          className="hover:text-slate-200 p-1 rounded"
        >
          <Sliders className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
