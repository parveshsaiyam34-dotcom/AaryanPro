import React, { useState, useRef } from 'react';
import {
  Folder,
  Sparkles,
  Settings as SettingsIcon,
  FileText,
  Calculator as CalculatorIcon,
  Globe,
  Trash2,
  RefreshCw,
  Sliders,
  Palette,
  Plus,
  FolderPlus,
  ExternalLink,
  Edit2,
} from 'lucide-react';
import { AppId, SystemSettings } from '../../types';

interface DesktopProps {
  settings: SystemSettings;
  onOpenApp: (appId: AppId, customData?: any) => void;
  onRefreshDesktop?: () => void;
}

export interface DesktopIconItem {
  id: string;
  appId?: AppId;
  name: string;
  type: 'app' | 'folder' | 'file';
  customData?: any;
  icon: React.ReactNode;
}

export const Desktop: React.FC<DesktopProps> = ({
  settings,
  onOpenApp,
  onRefreshDesktop,
}) => {
  const isDark = settings.theme === 'dark';
  const [selectedIconId, setSelectedIconId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Desktop items state (supports adding New Folder, New File, etc.)
  const [items, setItems] = useState<DesktopIconItem[]>([
    {
      id: 'recycle-bin',
      name: 'Recycle Bin',
      type: 'app',
      appId: 'explorer',
      customData: { folderName: 'desktop' },
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-slate-200 to-slate-400 dark:from-slate-700 dark:to-slate-900 flex items-center justify-center shadow-md">
          <Trash2 className="w-6 h-6 text-slate-700 dark:text-slate-200" />
        </div>
      ),
    },
    {
      id: 'explorer',
      appId: 'explorer',
      name: 'This PC',
      type: 'app',
      customData: { folderName: 'This PC' },
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-amber-300 to-amber-500 flex items-center justify-center shadow-md">
          <Folder className="w-6 h-6 text-amber-950 fill-amber-100/50" />
        </div>
      ),
    },
    {
      id: 'copilot',
      appId: 'copilot',
      name: 'Copilot',
      type: 'app',
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-400 via-indigo-500 to-fuchsia-500 flex items-center justify-center text-white shadow-md">
          <Sparkles className="w-6 h-6" />
        </div>
      ),
    },
    {
      id: 'browser',
      appId: 'browser',
      name: 'Microsoft Edge',
      type: 'app',
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-md">
          <Globe className="w-6 h-6" />
        </div>
      ),
    },
    {
      id: 'notepad',
      appId: 'notepad',
      name: 'Notepad',
      type: 'app',
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-sky-400 to-blue-600 flex items-center justify-center text-white shadow-md">
          <FileText className="w-6 h-6" />
        </div>
      ),
    },
    {
      id: 'calculator',
      appId: 'calculator',
      name: 'Calculator',
      type: 'app',
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-emerald-400 to-teal-600 flex items-center justify-center text-white shadow-md">
          <CalculatorIcon className="w-6 h-6" />
        </div>
      ),
    },
    {
      id: 'settings',
      appId: 'settings',
      name: 'Settings',
      type: 'app',
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-slate-400 to-slate-600 flex items-center justify-center text-white shadow-md">
          <SettingsIcon className="w-6 h-6" />
        </div>
      ),
    },
  ]);

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    visible: boolean;
    targetItem?: DesktopIconItem | null;
  }>({
    x: 0,
    y: 0,
    visible: false,
    targetItem: null,
  });

  // Track double clicks or quick double taps
  const lastClickRef = useRef<{ id: string; time: number }>({ id: '', time: 0 });

  const launchItem = (item: DesktopIconItem) => {
    if (item.appId) {
      onOpenApp(item.appId, item.customData);
    } else if (item.type === 'folder') {
      onOpenApp('explorer', { folderName: item.name });
    } else if (item.type === 'file') {
      onOpenApp('notepad', { fileName: item.name, content: item.customData?.content || '' });
    }
  };

  const handleIconClick = (e: React.MouseEvent, item: DesktopIconItem) => {
    e.stopPropagation();
    const now = Date.now();
    const wasAlreadySelected = selectedIconId === item.id;
    const isRapidClick = lastClickRef.current.id === item.id && now - lastClickRef.current.time < 500;

    setSelectedIconId(item.id);
    if (contextMenu.visible) {
      setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    }

    // If clicked a second time while selected or double-clicked, launch immediately
    if (wasAlreadySelected || isRapidClick) {
      launchItem(item);
    }

    lastClickRef.current = { id: item.id, time: now };
  };

  const handleIconDoubleClick = (e: React.MouseEvent, item: DesktopIconItem) => {
    e.stopPropagation();
    launchItem(item);
  };

  // Right Click on Desktop Background
  const handleDesktopContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    const x = Math.min(e.clientX, window.innerWidth - 230);
    const y = Math.min(e.clientY, window.innerHeight - 260);
    setContextMenu({ x, y, visible: true, targetItem: null });
  };

  // Right Click on Specific Icon
  const handleIconContextMenu = (e: React.MouseEvent, item: DesktopIconItem) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedIconId(item.id);
    const x = Math.min(e.clientX, window.innerWidth - 220);
    const y = Math.min(e.clientY, window.innerHeight - 200);
    setContextMenu({ x, y, visible: true, targetItem: item });
  };

  const handleBackgroundClick = () => {
    setSelectedIconId(null);
    if (contextMenu.visible) {
      setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    }
  };

  // Context Menu Actions
  const handleRefresh = () => {
    setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    setIsRefreshing(true);
    onRefreshDesktop?.();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 400);
  };

  const handleNewFolder = () => {
    setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    const folderCount = items.filter((it) => it.type === 'folder').length;
    const newFolderName = folderCount === 0 ? 'New folder' : `New folder (${folderCount + 1})`;

    const newFolderItem: DesktopIconItem = {
      id: `folder-${Date.now()}`,
      name: newFolderName,
      type: 'folder',
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-amber-300 to-amber-500 flex items-center justify-center shadow-md">
          <Folder className="w-6 h-6 text-amber-950 fill-amber-100/50" />
        </div>
      ),
    };

    setItems((prev) => [...prev, newFolderItem]);
    setSelectedIconId(newFolderItem.id);
  };

  const handleNewTextDocument = () => {
    setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    const docCount = items.filter((it) => it.type === 'file').length;
    const newDocName = docCount === 0 ? 'New Text Document.txt' : `New Text Document (${docCount + 1}).txt`;

    const newDocItem: DesktopIconItem = {
      id: `file-${Date.now()}`,
      name: newDocName,
      type: 'file',
      customData: { content: '' },
      icon: (
        <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-sky-400 to-blue-600 flex items-center justify-center text-white shadow-md">
          <FileText className="w-6 h-6" />
        </div>
      ),
    };

    setItems((prev) => [...prev, newDocItem]);
    setSelectedIconId(newDocItem.id);
  };

  const handleOpenDisplaySettings = () => {
    setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    onOpenApp('settings', { tab: 'system' });
  };

  const handleOpenPersonalize = () => {
    setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    onOpenApp('settings', { tab: 'personalization' });
  };

  const handleDeleteItem = (itemId: string) => {
    setContextMenu({ x: 0, y: 0, visible: false, targetItem: null });
    setItems((prev) => prev.filter((i) => i.id !== itemId));
    if (selectedIconId === itemId) {
      setSelectedIconId(null);
    }
  };

  const hasTransparency = settings.transparencyEffects !== false;
  const accentColor = settings.accentColor || '#0078d4';

  return (
    <div
      onContextMenu={handleDesktopContextMenu}
      onClick={handleBackgroundClick}
      className="absolute inset-0 overflow-hidden select-none"
      style={{ bottom: '48px' }}
    >
      {/* Desktop Grid of Icons */}
      <div
        className={`p-2.5 sm:p-3 flex flex-col flex-wrap items-start content-start gap-2 sm:gap-3 h-full max-w-sm transition-opacity duration-200 ${
          isRefreshing ? 'opacity-40 scale-[0.99]' : 'opacity-100 scale-100'
        }`}
      >
        {items.map((item) => {
          const isSelected = selectedIconId === item.id;
          return (
            <div
              key={item.id}
              onClick={(e) => handleIconClick(e, item)}
              onDoubleClick={(e) => handleIconDoubleClick(e, item)}
              onContextMenu={(e) => handleIconContextMenu(e, item)}
              style={{
                boxShadow: isSelected ? `0 0 0 1px ${accentColor}, 0 4px 12px rgba(0,0,0,0.3)` : undefined,
              }}
              className={`group w-20 sm:w-22 p-2 rounded-xl flex flex-col items-center text-center cursor-pointer transition-all duration-150 ${
                isSelected
                  ? 'bg-white/25 dark:bg-white/20 border border-white/40 backdrop-blur-md shadow-lg'
                  : 'hover:bg-white/15 dark:hover:bg-white/10 border border-transparent'
              }`}
              title={`${item.name} (Click or double-click to open)`}
            >
              <div className="mb-1.5 transition-transform group-hover:scale-105 group-active:scale-95">
                {item.icon}
              </div>
              <span className="text-[11px] font-medium text-white drop-shadow-[0_1.5px_2.5px_rgba(0,0,0,0.95)] tracking-tight leading-tight line-clamp-2 px-1">
                {item.name}
              </span>
            </div>
          );
        })}
      </div>

      {/* Windows 11 Desktop Context Menu */}
      {contextMenu.visible && (
        <div
          onClick={(e) => e.stopPropagation()}
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
          className={`absolute z-50 w-56 rounded-2xl p-1.5 border shadow-2xl text-xs transition-opacity animate-in fade-in-50 zoom-in-95 ${
            hasTransparency ? 'backdrop-blur-2xl' : ''
          } ${
            isDark
              ? hasTransparency
                ? 'bg-slate-900/90 border-white/15 text-slate-200 shadow-black/80'
                : 'bg-slate-900 border-slate-700 text-slate-200'
              : hasTransparency
              ? 'bg-white/95 border-slate-200/90 text-slate-800 shadow-slate-400/40'
              : 'bg-white border-slate-200 text-slate-800'
          }`}
        >
          {contextMenu.targetItem ? (
            /* Icon Context Menu */
            <>
              <button
                type="button"
                onClick={() => {
                  launchItem(contextMenu.targetItem!);
                  setContextMenu({ ...contextMenu, visible: false, targetItem: null });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <ExternalLink className="w-4 h-4 text-blue-500" />
                <span>Open</span>
              </button>

              {contextMenu.targetItem.id.startsWith('folder-') || contextMenu.targetItem.id.startsWith('file-') ? (
                <>
                  <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />
                  <button
                    type="button"
                    onClick={() => handleDeleteItem(contextMenu.targetItem!.id)}
                    className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                </>
              ) : null}
            </>
          ) : (
            /* Desktop Background Context Menu (Refresh, New Folder, Display settings, etc.) */
            <>
              {/* Refresh */}
              <button
                type="button"
                onClick={handleRefresh}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <RefreshCw className="w-4 h-4 text-blue-500" />
                <span>Refresh</span>
              </button>

              <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

              {/* New Folder */}
              <button
                type="button"
                onClick={handleNewFolder}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <FolderPlus className="w-4 h-4 text-amber-500" />
                <span>New Folder</span>
              </button>

              {/* New Text Document */}
              <button
                type="button"
                onClick={handleNewTextDocument}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Plus className="w-4 h-4 text-emerald-500" />
                <span>New Text Document</span>
              </button>

              <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

              {/* Display Settings */}
              <button
                type="button"
                onClick={handleOpenDisplaySettings}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Sliders className="w-4 h-4 text-sky-500" />
                <span>Display settings</span>
              </button>

              {/* Personalize */}
              <button
                type="button"
                onClick={handleOpenPersonalize}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Palette className="w-4 h-4 text-pink-500" />
                <span>Personalize</span>
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};
