import React from 'react';
import { WallpaperId } from '../../types';

interface WallpaperBackgroundProps {
  wallpaper: WallpaperId;
}

export const WallpaperBackground: React.FC<WallpaperBackgroundProps> = ({ wallpaper }) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden select-none -z-10 transition-all duration-700 ease-out">
      {/* 1. Classic Windows 11 Light Bloom */}
      {wallpaper === 'bloom-blue' && (
        <div className="absolute inset-0 bg-[#0d1626] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_35%,rgba(37,99,235,0.45),transparent_65%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_65%,rgba(56,189,248,0.35),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_55%,rgba(99,102,241,0.35),transparent_55%)]" />
          <svg
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-[1280px] h-[80vh] opacity-85"
            viewBox="0 0 1000 600"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M140 490C280 410 340 240 450 210C560 180 630 310 730 270C830 230 860 130 910 110C930 270 830 460 690 510C550 550 310 540 140 490Z"
              fill="url(#bloomGrad1)"
              filter="blur(28px)"
            />
            <path
              d="M240 430C320 310 410 170 510 150C610 130 670 250 760 210C850 170 830 370 730 430C630 490 390 490 240 430Z"
              fill="url(#bloomGrad2)"
              filter="blur(18px)"
            />
            <path
              d="M360 350C430 230 530 130 600 120C670 110 730 210 710 320C690 430 530 460 410 430C350 410 320 390 360 350Z"
              fill="url(#bloomGrad3)"
              filter="blur(12px)"
            />
            <path
              d="M440 290C490 200 560 140 620 150C670 160 700 240 680 320C660 390 540 420 460 390C410 370 410 340 440 290Z"
              fill="url(#bloomGrad4)"
              filter="blur(6px)"
            />
            <defs>
              <linearGradient id="bloomGrad1" x1="180" y1="180" x2="820" y2="520" gradientUnits="userSpaceOnUse">
                <stop stopColor="#0284c7" stopOpacity="0.85" />
                <stop offset="0.45" stopColor="#3b82f6" stopOpacity="0.8" />
                <stop offset="1" stopColor="#6366f1" stopOpacity="0.9" />
              </linearGradient>
              <linearGradient id="bloomGrad2" x1="280" y1="140" x2="720" y2="440" gradientUnits="userSpaceOnUse">
                <stop stopColor="#38bdf8" stopOpacity="0.9" />
                <stop offset="0.5" stopColor="#60a5fa" stopOpacity="0.9" />
                <stop offset="1" stopColor="#818cf8" stopOpacity="0.75" />
              </linearGradient>
              <linearGradient id="bloomGrad3" x1="380" y1="110" x2="660" y2="390" gradientUnits="userSpaceOnUse">
                <stop stopColor="#bae6fd" stopOpacity="0.95" />
                <stop offset="0.6" stopColor="#93c5fd" stopOpacity="0.9" />
                <stop offset="1" stopColor="#c7d2fe" stopOpacity="0.8" />
              </linearGradient>
              <linearGradient id="bloomGrad4" x1="420" y1="140" x2="680" y2="380" gradientUnits="userSpaceOnUse">
                <stop stopColor="#ffffff" stopOpacity="0.9" />
                <stop offset="0.7" stopColor="#bfdbfe" stopOpacity="0.8" />
                <stop offset="1" stopColor="#93c5fd" stopOpacity="0.6" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 2. Windows 11 Dark Bloom */}
      {wallpaper === 'bloom-dark' && (
        <div className="absolute inset-0 bg-[#06080f] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(30,58,138,0.5),transparent_65%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_65%,rgba(88,28,135,0.35),transparent_55%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_45%,rgba(14,165,233,0.3),transparent_50%)]" />
          <svg
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-[1280px] h-[80vh] opacity-75"
            viewBox="0 0 1000 600"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M140 480C280 400 350 250 460 210C570 170 630 310 740 270C840 230 870 130 920 110C940 270 840 460 700 510C560 550 320 540 140 480Z"
              fill="url(#darkBloom1)"
              filter="blur(32px)"
            />
            <path
              d="M270 400C350 280 450 160 550 140C640 120 700 250 770 210C830 170 810 370 720 420C620 480 420 460 270 400Z"
              fill="url(#darkBloom2)"
              filter="blur(20px)"
            />
            <path
              d="M380 340C440 230 530 140 600 130C660 120 720 220 700 320C680 410 530 440 430 410C370 390 350 370 380 340Z"
              fill="url(#darkBloom3)"
              filter="blur(12px)"
            />
            <defs>
              <linearGradient id="darkBloom1" x1="140" y1="180" x2="860" y2="490" gradientUnits="userSpaceOnUse">
                <stop stopColor="#1e3a8a" stopOpacity="0.85" />
                <stop offset="0.5" stopColor="#4338ca" stopOpacity="0.8" />
                <stop offset="1" stopColor="#6b21a8" stopOpacity="0.9" />
              </linearGradient>
              <linearGradient id="darkBloom2" x1="240" y1="140" x2="720" y2="420" gradientUnits="userSpaceOnUse">
                <stop stopColor="#2563eb" stopOpacity="0.8" />
                <stop offset="0.6" stopColor="#7c3aed" stopOpacity="0.8" />
                <stop offset="1" stopColor="#38bdf8" stopOpacity="0.6" />
              </linearGradient>
              <linearGradient id="darkBloom3" x1="360" y1="120" x2="680" y2="380" gradientUnits="userSpaceOnUse">
                <stop stopColor="#818cf8" stopOpacity="0.9" />
                <stop offset="0.6" stopColor="#a855f7" stopOpacity="0.85" />
                <stop offset="1" stopColor="#38bdf8" stopOpacity="0.7" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 3. Windows 11 Glow */}
      {wallpaper === 'bloom-glow' && (
        <div className="absolute inset-0 bg-[#080d1a] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(124,58,237,0.3),transparent_60%)]" />
          {/* Luminous Glowing Spheres & Halos */}
          <div className="absolute top-[25%] left-[30%] w-72 h-72 rounded-full bg-violet-600/30 blur-[60px]" />
          <div className="absolute top-[40%] right-[25%] w-80 h-80 rounded-full bg-emerald-500/25 blur-[70px]" />
          <div className="absolute bottom-[20%] left-[45%] w-96 h-96 rounded-full bg-amber-500/20 blur-[80px]" />
          <svg
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[85vw] max-w-[1100px] h-[75vh]"
            viewBox="0 0 1000 600"
            fill="none"
          >
            {/* Concentric luminous rings */}
            <circle cx="500" cy="300" r="220" stroke="url(#glowRing1)" strokeWidth="40" opacity="0.35" filter="blur(25px)" />
            <circle cx="480" cy="280" r="140" stroke="url(#glowRing2)" strokeWidth="30" opacity="0.5" filter="blur(15px)" />
            <circle cx="520" cy="320" r="70" fill="url(#glowCenter)" filter="blur(8px)" opacity="0.85" />
            <defs>
              <linearGradient id="glowRing1" x1="200" y1="100" x2="800" y2="500">
                <stop stopColor="#8b5cf6" />
                <stop offset="0.5" stopColor="#10b981" />
                <stop offset="1" stopColor="#f59e0b" />
              </linearGradient>
              <linearGradient id="glowRing2" x1="300" y1="150" x2="700" y2="450">
                <stop stopColor="#a78bfa" />
                <stop offset="0.6" stopColor="#34d399" />
                <stop offset="1" stopColor="#fbbf24" />
              </linearGradient>
              <radialGradient id="glowCenter" cx="50%" cy="50%" r="50%">
                <stop stopColor="#ffffff" stopOpacity="0.9" />
                <stop offset="0.4" stopColor="#c4b5fd" stopOpacity="0.7" />
                <stop offset="1" stopColor="#6366f1" stopOpacity="0" />
              </radialGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 4. Captured Motion */}
      {wallpaper === 'bloom-captured-motion' && (
        <div className="absolute inset-0 bg-[#16071e] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(219,39,119,0.35),transparent_65%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(147,51,234,0.35),transparent_55%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_60%,rgba(239,68,68,0.3),transparent_50%)]" />
          <svg
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-[1200px] h-[80vh] opacity-80"
            viewBox="0 0 1000 600"
            fill="none"
          >
            <path
              d="M120 480C240 280 400 160 520 180C640 200 660 380 780 320C900 260 940 160 880 360C820 540 620 560 480 500C340 440 200 580 120 480Z"
              fill="url(#motionGrad1)"
              filter="blur(26px)"
            />
            <path
              d="M260 420C340 260 460 170 560 190C660 210 680 340 760 300C840 260 840 380 760 440C680 500 480 480 360 460C290 440 240 460 260 420Z"
              fill="url(#motionGrad2)"
              filter="blur(16px)"
            />
            <defs>
              <linearGradient id="motionGrad1" x1="100" y1="120" x2="900" y2="540">
                <stop stopColor="#e11d48" />
                <stop offset="0.3" stopColor="#db2777" />
                <stop offset="0.7" stopColor="#9333ea" />
                <stop offset="1" stopColor="#4f46e5" />
              </linearGradient>
              <linearGradient id="motionGrad2" x1="200" y1="180" x2="800" y2="460">
                <stop stopColor="#f43f5e" />
                <stop offset="0.5" stopColor="#ec4899" />
                <stop offset="1" stopColor="#a855f7" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 5. Windows 11 Flow */}
      {wallpaper === 'bloom-flow' && (
        <div className="absolute inset-0 bg-[#021324] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(6,182,212,0.35),transparent_60%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_70%,rgba(37,99,235,0.4),transparent_55%)]" />
          <svg
            className="absolute inset-0 w-full h-full opacity-70"
            viewBox="0 0 1440 900"
            preserveAspectRatio="none"
            fill="none"
          >
            <path
              d="M-100 650C250 500 450 780 750 620C1050 460 1200 600 1550 480V950H-100V650Z"
              fill="url(#flow1)"
              filter="blur(25px)"
            />
            <path
              d="M-100 480C280 320 520 620 850 450C1180 280 1320 480 1550 350V950H-100V480Z"
              fill="url(#flow2)"
              filter="blur(16px)"
            />
            <path
              d="M-100 340C320 200 600 450 960 300C1250 180 1380 320 1550 240V950H-100V340Z"
              fill="url(#flow3)"
              filter="blur(8px)"
            />
            <defs>
              <linearGradient id="flow1" x1="0" y1="500" x2="1440" y2="800" gradientUnits="userSpaceOnUse">
                <stop stopColor="#0369a1" />
                <stop offset="0.5" stopColor="#1d4ed8" />
                <stop offset="1" stopColor="#4338ca" />
              </linearGradient>
              <linearGradient id="flow2" x1="0" y1="350" x2="1440" y2="650" gradientUnits="userSpaceOnUse">
                <stop stopColor="#06b6d4" />
                <stop offset="0.5" stopColor="#2563eb" />
                <stop offset="1" stopColor="#3b82f6" />
              </linearGradient>
              <linearGradient id="flow3" x1="0" y1="200" x2="1440" y2="500" gradientUnits="userSpaceOnUse">
                <stop stopColor="#67e8f9" stopOpacity="0.8" />
                <stop offset="0.6" stopColor="#60a5fa" stopOpacity="0.7" />
                <stop offset="1" stopColor="#818cf8" stopOpacity="0.6" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 6. Sunrise Horizon */}
      {wallpaper === 'sunrise' && (
        <div className="absolute inset-0 bg-[#160c1d] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_75%,rgba(245,158,11,0.5),transparent_65%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_60%,rgba(244,63,94,0.4),transparent_60%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(99,102,241,0.25),transparent_55%)]" />
          {/* Radiant Sun Orb */}
          <div className="absolute bottom-[28%] left-1/2 -translate-x-1/2 w-48 h-48 rounded-full bg-gradient-to-t from-amber-300 to-rose-400 blur-[20px] opacity-80" />
          <div className="absolute bottom-[30%] left-1/2 -translate-x-1/2 w-32 h-32 rounded-full bg-amber-100 blur-[6px] opacity-90 shadow-[0_0_80px_rgba(251,191,36,0.8)]" />
          {/* Horizon Silhouette */}
          <svg className="absolute bottom-0 inset-x-0 w-full h-44 opacity-80" viewBox="0 0 1440 250" preserveAspectRatio="none" fill="none">
            <path d="M0 160L320 90L640 140L960 70L1280 120L1440 95V250H0V160Z" fill="#0f0714" />
            <path d="M0 190L260 140L580 180L880 125L1180 165L1440 150V250H0V190Z" fill="#08030b" />
          </svg>
        </div>
      )}

      {/* 7. Aurora Borealis */}
      {wallpaper === 'aurora' && (
        <div className="absolute inset-0 bg-[#020b14] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(16,185,129,0.35),transparent_60%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(20,184,166,0.3),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_40%,rgba(6,182,212,0.3),transparent_55%)]" />
          {/* Star specks */}
          <div className="absolute top-[12%] left-[18%] w-1 h-1 bg-white/80 rounded-full blur-[0.5px]" />
          <div className="absolute top-[22%] left-[35%] w-1.5 h-1.5 bg-emerald-200/90 rounded-full blur-[1px]" />
          <div className="absolute top-[18%] left-[62%] w-1 h-1 bg-white/80 rounded-full blur-[0.5px]" />
          <div className="absolute top-[28%] left-[82%] w-1.5 h-1.5 bg-teal-200/90 rounded-full blur-[1px]" />
          <div className="absolute top-[8%] left-[48%] w-1 h-1 bg-white/70 rounded-full blur-[0.5px]" />
          <div className="absolute top-[35%] left-[12%] w-1 h-1 bg-white/60 rounded-full blur-[0.5px]" />
          {/* Aurora Ribbons */}
          <svg className="absolute top-0 inset-x-0 w-full h-[70vh] opacity-75" viewBox="0 0 1200 500" fill="none" preserveAspectRatio="none">
            <path
              d="M-50 200C180 80 380 280 620 140C860 0 1020 220 1250 110L1250 350C1000 450 820 260 580 380C340 500 160 300 -50 420Z"
              fill="url(#auroraGrad1)"
              filter="blur(30px)"
            />
            <path
              d="M-50 140C200 40 420 220 680 90C920 -30 1060 160 1250 80L1250 280C1040 360 880 200 640 300C400 400 180 220 -50 320Z"
              fill="url(#auroraGrad2)"
              filter="blur(18px)"
            />
            <defs>
              <linearGradient id="auroraGrad1" x1="0" y1="50" x2="1200" y2="400" gradientUnits="userSpaceOnUse">
                <stop stopColor="#059669" stopOpacity="0.9" />
                <stop offset="0.5" stopColor="#0d9488" stopOpacity="0.85" />
                <stop offset="1" stopColor="#0284c7" stopOpacity="0.8" />
              </linearGradient>
              <linearGradient id="auroraGrad2" x1="0" y1="0" x2="1200" y2="300" gradientUnits="userSpaceOnUse">
                <stop stopColor="#34d399" stopOpacity="0.95" />
                <stop offset="0.5" stopColor="#2dd4bf" stopOpacity="0.9" />
                <stop offset="1" stopColor="#38bdf8" stopOpacity="0.8" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 8. Sunset Twilight */}
      {wallpaper === 'sunset' && (
        <div className="absolute inset-0 bg-[#140b24] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_70%,rgba(244,63,94,0.45),transparent_60%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_45%,rgba(217,70,239,0.35),transparent_55%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_65%,rgba(245,158,11,0.35),transparent_50%)]" />
          <svg className="absolute bottom-0 inset-x-0 w-full h-[50vh] opacity-70" viewBox="0 0 1200 400" preserveAspectRatio="none" fill="none">
            <path
              d="M0 320C300 240 500 360 800 280C1050 210 1150 290 1200 260V400H0V320Z"
              fill="url(#sunsetG1)"
              filter="blur(20px)"
            />
            <defs>
              <linearGradient id="sunsetG1" x1="0" y1="200" x2="1200" y2="400" gradientUnits="userSpaceOnUse">
                <stop stopColor="#f43f5e" stopOpacity="0.8" />
                <stop offset="0.5" stopColor="#a855f7" stopOpacity="0.7" />
                <stop offset="1" stopColor="#4338ca" stopOpacity="0.8" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* 9. Windows Spotlight (Landscape Nature) */}
      {wallpaper === 'spotlight' && (
        <div className="absolute inset-0 bg-[#081824] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_30%,rgba(56,189,248,0.35),transparent_65%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_65%,rgba(16,185,129,0.25),transparent_55%)]" />
          {/* Atmospheric mountains */}
          <svg className="absolute bottom-0 inset-x-0 w-full h-[65vh] opacity-85" viewBox="0 0 1440 600" preserveAspectRatio="none" fill="none">
            {/* Distant mountains */}
            <path d="M0 450L240 280L520 400L780 230L1060 380L1320 260L1440 320V600H0V450Z" fill="#132c3f" opacity="0.6" />
            {/* Midground peaks */}
            <path d="M0 490L340 360L620 460L890 320L1160 440L1440 350V600H0V490Z" fill="#0f2231" opacity="0.8" />
            {/* Foreground coastline */}
            <path d="M0 540L420 460L780 520L1120 450L1440 490V600H0V540Z" fill="#07131b" />
          </svg>
          {/* Reflection glow */}
          <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-sky-950/80 to-transparent" />
        </div>
      )}

      {/* 10. Minimal Carbon */}
      {wallpaper === 'cyber' && (
        <div className="absolute inset-0 bg-[#0c0d10] transition-opacity duration-700">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.18),transparent_65%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.06),transparent_50%)]" />
          {/* Carbon Grid */}
          <div
            className="absolute inset-0 opacity-[0.045]"
            style={{
              backgroundImage:
                'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
              backgroundSize: '36px 36px',
            }}
          />
        </div>
      )}
    </div>
  );
};
