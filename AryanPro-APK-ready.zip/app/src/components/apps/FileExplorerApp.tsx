import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Folder,
  FileText,
  FileCode,
  Image,
  HardDrive,
  Monitor as DesktopIcon,
  Download,
  FolderOpen,
  ChevronRight,
  Search,
  Plus,
  Trash2,
  RefreshCw,
  LayoutGrid,
  List,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  SlidersHorizontal,
  ChevronDown,
  Edit2,
  Copy,
  Scissors,
  Clipboard,
  Info,
  Check,
  X,
  Sparkles,
  Grid3X3,
  Star,
  Laptop,
} from 'lucide-react';
import { AppTheme, FileItem } from '../../types';
import {
  DEFAULT_FILE_SYSTEM,
  SYSTEM_DRIVES,
  KNOWN_FOLDERS,
  FolderMeta,
} from './explorer/fileSystemData';
import { FilePropertiesModal } from './explorer/FilePropertiesModal';
import { ImageViewerModal } from './explorer/ImageViewerModal';

interface FileExplorerAppProps {
  theme: AppTheme;
  onOpenFileInNotepad?: (fileName: string, content: string) => void;
  initialPath?: string;
}

type ViewMode = 'details' | 'grid' | 'large';
type SortField = 'name' | 'date' | 'type' | 'size';
type SortDirection = 'asc' | 'desc';

const STORAGE_KEY = 'win11_file_explorer_fs_v2';

export const FileExplorerApp: React.FC<FileExplorerAppProps> = ({
  theme,
  onOpenFileInNotepad,
  initialPath,
}) => {
  const isDark = theme === 'dark';

  // Filesystem State (with LocalStorage persistence)
  const [files, setFiles] = useState<FileItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return DEFAULT_FILE_SYSTEM;
  });

  // Save to LocalStorage whenever files change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(files));
    } catch {
      // ignore
    }
  }, [files]);

  // Current Directory & Navigation History
  const [currentFolderId, setCurrentFolderId] = useState<string>('documents');
  const [history, setHistory] = useState<string[]>(['documents']);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Address Bar Edit Mode
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [addressInputText, setAddressInputText] = useState('');
  const [copiedPathToast, setCopiedPathToast] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');

  // View & Sort
  const [viewMode, setViewMode] = useState<ViewMode>('details');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [showNewMenu, setShowNewMenu] = useState(false);
  const [showViewMenu, setShowViewMenu] = useState(false);

  // Selection
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const lastSelectedIdRef = useRef<string | null>(null);

  // Inline Rename State
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const renameInputRef = useRef<HTMLInputElement | null>(null);

  // Clipboard (Cut / Copy / Paste)
  const [clipboard, setClipboard] = useState<{ id: string; action: 'copy' | 'cut' } | null>(null);

  // Modals
  const [propertiesItem, setPropertiesItem] = useState<FileItem | null>(null);
  const [viewingImageItem, setViewingImageItem] = useState<FileItem | null>(null);

  // Notification Toast (e.g. Undo delete)
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deletedUndoItem, setDeletedUndoItem] = useState<FileItem[] | null>(null);

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    targetItem?: FileItem | null;
  }>({
    visible: false,
    x: 0,
    y: 0,
    targetItem: null,
  });

  const [isRefreshing, setIsRefreshing] = useState(false);

  // Handle Initial Path prop if passed from Desktop/Start Menu
  useEffect(() => {
    if (!initialPath) return;
    const lower = initialPath.toLowerCase();
    if (lower === 'this pc' || lower === 'thispc') {
      navigateTo('thispc');
    } else if (lower.includes('recycle') || lower.includes('trash')) {
      navigateTo('desktop');
    } else if (lower.includes('document')) {
      navigateTo('documents');
    } else if (lower.includes('download')) {
      navigateTo('downloads');
    } else if (lower.includes('picture')) {
      navigateTo('pictures');
    } else if (lower.includes('desktop')) {
      navigateTo('desktop');
    } else if (lower.includes('c:')) {
      navigateTo('drive_c');
    } else {
      // Find matching folder name
      const matching = files.find(
        (f) => f.type === 'folder' && f.name.toLowerCase() === lower
      );
      if (matching) {
        navigateTo(matching.id);
      }
    }
  }, [initialPath]);

  // Navigate to Folder ID & update history
  const navigateTo = (folderId: string) => {
    if (folderId === currentFolderId) return;

    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(folderId);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setCurrentFolderId(folderId);
    setSelectedIds([]);
    setSearchQuery('');
    setIsEditingAddress(false);
  };

  // Back Navigation
  const handleGoBack = () => {
    if (historyIndex > 0) {
      const targetIdx = historyIndex - 1;
      setHistoryIndex(targetIdx);
      setCurrentFolderId(history[targetIdx]);
      setSelectedIds([]);
      setSearchQuery('');
    }
  };

  // Forward Navigation
  const handleGoForward = () => {
    if (historyIndex < history.length - 1) {
      const targetIdx = historyIndex + 1;
      setHistoryIndex(targetIdx);
      setCurrentFolderId(history[targetIdx]);
      setSelectedIds([]);
      setSearchQuery('');
    }
  };

  // Up Navigation (Parent Directory)
  const handleGoUp = () => {
    if (currentFolderId === 'thispc') return;

    // Check known folders
    const known = KNOWN_FOLDERS[currentFolderId];
    if (known) {
      navigateTo(known.parentId || 'thispc');
      return;
    }

    // Check custom folders in files array
    const currentFolderItem = files.find((f) => f.id === currentFolderId);
    if (currentFolderItem) {
      navigateTo(currentFolderItem.parentId || 'thispc');
    } else {
      navigateTo('thispc');
    }
  };

  // Refresh
  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 400);
  };

  // Determine current folder display meta
  const currentFolderMeta: { name: string; fullPath: string; parentId: string | null } = useMemo(() => {
    if (KNOWN_FOLDERS[currentFolderId]) {
      return {
        name: KNOWN_FOLDERS[currentFolderId].name,
        fullPath: KNOWN_FOLDERS[currentFolderId].path,
        parentId: KNOWN_FOLDERS[currentFolderId].parentId,
      };
    }
    const found = files.find((f) => f.id === currentFolderId);
    if (found) {
      return {
        name: found.name,
        fullPath: found.location || `This PC > ... > ${found.name}`,
        parentId: found.parentId || 'thispc',
      };
    }
    return {
      name: 'Folder',
      fullPath: 'This PC',
      parentId: null,
    };
  }, [currentFolderId, files]);

  // Compute Breadcrumb Segments for interactive clicking
  const breadcrumbs = useMemo(() => {
    const list: { id: string; name: string }[] = [];

    let currId: string | null = currentFolderId;
    const visited = new Set<string>();

    while (currId && !visited.has(currId)) {
      visited.add(currId);
      if (currId === 'thispc') {
        list.unshift({ id: 'thispc', name: 'This PC' });
        break;
      }
      if (KNOWN_FOLDERS[currId]) {
        list.unshift({ id: currId, name: KNOWN_FOLDERS[currId].name });
        currId = KNOWN_FOLDERS[currId].parentId;
      } else {
        const item = files.find((f) => f.id === currId);
        if (item) {
          list.unshift({ id: item.id, name: item.name });
          currId = item.parentId || 'thispc';
        } else {
          list.unshift({ id: 'thispc', name: 'This PC' });
          break;
        }
      }
    }

    if (list.length === 0 || list[0].id !== 'thispc') {
      list.unshift({ id: 'thispc', name: 'This PC' });
    }

    return list;
  }, [currentFolderId, files]);

  // Items contained in current directory
  const currentItems = useMemo(() => {
    // If we're searching, search through all items or current folder's descendants
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return files.filter(
        (f) =>
          f.name.toLowerCase().includes(q) ||
          f.extension?.toLowerCase().includes(q) ||
          f.content?.toLowerCase().includes(q)
      );
    }

    // Otherwise, items whose parentId matches currentFolderId
    return files.filter((f) => f.parentId === currentFolderId);
  }, [files, currentFolderId, searchQuery]);

  // Sorted items
  const sortedItems = useMemo(() => {
    const items = [...currentItems];

    items.sort((a, b) => {
      // Folders always first
      if (a.type !== b.type) {
        return a.type === 'folder' ? -1 : 1;
      }

      let comp = 0;
      if (sortField === 'name') {
        comp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
      } else if (sortField === 'date') {
        comp = new Date(a.date).getTime() - new Date(b.date).getTime();
      } else if (sortField === 'type') {
        const extA = a.extension || (a.type === 'folder' ? 'folder' : '');
        const extB = b.extension || (b.type === 'folder' ? 'folder' : '');
        comp = extA.localeCompare(extB);
      } else if (sortField === 'size') {
        const getSizeBytes = (sizeStr?: string) => {
          if (!sizeStr) return 0;
          const [val, unit] = sizeStr.split(' ');
          const n = parseFloat(val) || 0;
          if (unit === 'GB') return n * 1024 * 1024 * 1024;
          if (unit === 'MB') return n * 1024 * 1024;
          if (unit === 'KB') return n * 1024;
          return n;
        };
        comp = getSizeBytes(a.size) - getSizeBytes(b.size);
      }

      return sortDirection === 'asc' ? comp : -comp;
    });

    return items;
  }, [currentItems, sortField, sortDirection]);

  // Selection Helpers
  const handleItemClick = (e: React.MouseEvent, item: FileItem) => {
    e.stopPropagation();
    if (renamingId === item.id) return;

    if (e.ctrlKey || e.metaKey) {
      // Toggle selection
      setSelectedIds((prev) =>
        prev.includes(item.id) ? prev.filter((id) => id !== item.id) : [...prev, item.id]
      );
    } else if (e.shiftKey && lastSelectedIdRef.current) {
      // Range selection
      const lastIndex = sortedItems.findIndex((i) => i.id === lastSelectedIdRef.current);
      const currIndex = sortedItems.findIndex((i) => i.id === item.id);
      if (lastIndex !== -1 && currIndex !== -1) {
        const start = Math.min(lastIndex, currIndex);
        const end = Math.max(lastIndex, currIndex);
        const rangeIds = sortedItems.slice(start, end + 1).map((i) => i.id);
        setSelectedIds(rangeIds);
      } else {
        setSelectedIds([item.id]);
      }
    } else {
      // Single selection
      setSelectedIds([item.id]);
    }
    lastSelectedIdRef.current = item.id;
  };

  // Double Click on Item
  const handleItemDoubleClick = (item: FileItem) => {
    if (renamingId === item.id) return;

    if (item.type === 'folder') {
      navigateTo(item.id);
    } else if (item.extension === 'txt' || item.extension === 'log' || item.extension === 'md') {
      if (onOpenFileInNotepad) {
        onOpenFileInNotepad(item.name, item.content || '');
      }
    } else if (item.extension === 'png' || item.extension === 'jpg') {
      setViewingImageItem(item);
    } else {
      // Show properties as default action
      setPropertiesItem(item);
    }
  };

  // Create New Folder
  const handleCreateNewFolder = () => {
    setShowNewMenu(false);
    const existingNames = files.filter((f) => f.parentId === currentFolderId).map((f) => f.name);
    let newName = 'New folder';
    let counter = 2;
    while (existingNames.includes(newName)) {
      newName = `New folder (${counter})`;
      counter++;
    }

    const newFolder: FileItem = {
      id: `folder_${Date.now()}`,
      name: newName,
      type: 'folder',
      date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      parentId: currentFolderId,
      location: `${currentFolderMeta.fullPath} > ${newName}`,
    };

    setFiles((prev) => [newFolder, ...prev]);
    setSelectedIds([newFolder.id]);

    // Automatically trigger inline rename
    setTimeout(() => {
      setRenamingId(newFolder.id);
      setRenameValue(newFolder.name);
    }, 50);
  };

  // Create New Text Document
  const handleCreateNewTextFile = () => {
    setShowNewMenu(false);
    const existingNames = files.filter((f) => f.parentId === currentFolderId).map((f) => f.name);
    let newName = 'New Text Document.txt';
    let counter = 2;
    while (existingNames.includes(newName)) {
      newName = `New Text Document (${counter}).txt`;
      counter++;
    }

    const newFile: FileItem = {
      id: `file_${Date.now()}`,
      name: newName,
      type: 'file',
      size: '1 KB',
      date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      extension: 'txt',
      parentId: currentFolderId,
      location: `${currentFolderMeta.fullPath} > ${newName}`,
      content: 'New document created in Windows 11 File Explorer.',
    };

    setFiles((prev) => [newFile, ...prev]);
    setSelectedIds([newFile.id]);

    // Automatically trigger inline rename
    setTimeout(() => {
      setRenamingId(newFile.id);
      setRenameValue(newFile.name);
    }, 50);
  };

  // Trigger Inline Rename
  const handleStartRename = (item: FileItem) => {
    setRenamingId(item.id);
    setRenameValue(item.name);
    setTimeout(() => {
      if (renameInputRef.current) {
        renameInputRef.current.focus();
        // Select filename without extension if file
        const dotIndex = item.name.lastIndexOf('.');
        if (dotIndex > 0 && item.type === 'file') {
          renameInputRef.current.setSelectionRange(0, dotIndex);
        } else {
          renameInputRef.current.select();
        }
      }
    }, 50);
  };

  // Commit Inline Rename
  const handleCommitRename = () => {
    if (!renamingId) return;

    const trimmed = renameValue.trim();
    if (!trimmed) {
      setRenamingId(null);
      return;
    }

    // Check illegal characters
    const illegalChars = /[\\/:*?"<>|]/;
    if (illegalChars.test(trimmed)) {
      alert('A file name cannot contain any of the following characters: \\ / : * ? " < > |');
      return;
    }

    setFiles((prev) =>
      prev.map((f) => {
        if (f.id === renamingId) {
          const ext = f.type === 'file' && trimmed.includes('.') ? trimmed.split('.').pop() : f.extension;
          return {
            ...f,
            name: trimmed,
            extension: ext,
            date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
        }
        return f;
      })
    );

    setRenamingId(null);
  };

  // Delete Selected Items
  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;

    const itemsToDelete = files.filter((f) => selectedIds.includes(f.id));
    setDeletedUndoItem(itemsToDelete);

    // Recursively collect all descendant IDs if folder
    const allIdsToDelete = new Set<string>(selectedIds);
    const findDescendants = (parentId: string) => {
      files.filter((f) => f.parentId === parentId).forEach((child) => {
        allIdsToDelete.add(child.id);
        if (child.type === 'folder') {
          findDescendants(child.id);
        }
      });
    };
    selectedIds.forEach((id) => findDescendants(id));

    setFiles((prev) => prev.filter((f) => !allIdsToDelete.has(f.id)));
    setSelectedIds([]);

    const count = itemsToDelete.length;
    setToastMessage(`Deleted ${count} item${count > 1 ? 's' : ''}`);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Undo Delete
  const handleUndoDelete = () => {
    if (!deletedUndoItem || deletedUndoItem.length === 0) return;
    setFiles((prev) => [...deletedUndoItem, ...prev]);
    setDeletedUndoItem(null);
    setToastMessage('Items restored');
    setTimeout(() => {
      setToastMessage(null), 2000;
    }, 2000);
  };

  // Copy / Cut Action
  const handleClipboardAction = (action: 'copy' | 'cut') => {
    if (selectedIds.length === 0) return;
    setClipboard({ id: selectedIds[0], action });
    setToastMessage(`${action === 'copy' ? 'Copied' : 'Cut'} to clipboard`);
    setTimeout(() => setToastMessage(null), 2000);
  };

  // Paste Action
  const handlePasteAction = () => {
    if (!clipboard) return;
    const sourceItem = files.find((f) => f.id === clipboard.id);
    if (!sourceItem) return;

    if (clipboard.action === 'cut') {
      setFiles((prev) =>
        prev.map((f) => (f.id === sourceItem.id ? { ...f, parentId: currentFolderId } : f))
      );
      setClipboard(null);
    } else {
      // Duplicate
      const copyName = `Copy of ${sourceItem.name}`;
      const duplicate: FileItem = {
        ...sourceItem,
        id: `${sourceItem.id}_copy_${Date.now()}`,
        name: copyName,
        parentId: currentFolderId,
        date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setFiles((prev) => [duplicate, ...prev]);
      setSelectedIds([duplicate.id]);
    }
  };

  // Select All (Ctrl+A)
  const handleSelectAll = () => {
    setSelectedIds(sortedItems.map((i) => i.id));
  };

  // Address Bar Direct Input Submit
  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditingAddress(false);
    const target = addressInputText.trim().toLowerCase();

    if (!target) return;

    if (target === 'this pc' || target === 'thispc') {
      navigateTo('thispc');
    } else if (target === 'c:' || target === 'c:\\' || target.includes('local disk (c:)')) {
      navigateTo('drive_c');
    } else if (target === 'd:' || target === 'd:\\' || target.includes('local disk (d:)')) {
      navigateTo('drive_d');
    } else if (target === 'documents' || target === 'my documents') {
      navigateTo('documents');
    } else if (target === 'downloads') {
      navigateTo('downloads');
    } else if (target === 'pictures') {
      navigateTo('pictures');
    } else if (target === 'desktop') {
      navigateTo('desktop');
    } else {
      // Find matching folder
      const found = files.find(
        (f) => f.type === 'folder' && f.name.toLowerCase() === target
      );
      if (found) {
        navigateTo(found.id);
      } else {
        setToastMessage(`Cannot find '${addressInputText}'`);
        setTimeout(() => setToastMessage(null), 2500);
      }
    }
  };

  // Copy Address Path
  const handleCopyPath = () => {
    try {
      navigator.clipboard.writeText(currentFolderMeta.fullPath);
      setCopiedPathToast(true);
      setTimeout(() => setCopiedPathToast(false), 2000);
    } catch {
      // fallback
    }
  };

  // Right-Click Context Menu on Canvas
  const handleCanvasContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const x = Math.min(e.clientX, window.innerWidth - 220);
    const y = Math.min(e.clientY, window.innerHeight - 260);
    setContextMenu({
      visible: true,
      x,
      y,
      targetItem: null,
    });
  };

  // Right-Click Context Menu on Item
  const handleItemContextMenu = (e: React.MouseEvent, item: FileItem) => {
    e.preventDefault();
    e.stopPropagation();
    if (!selectedIds.includes(item.id)) {
      setSelectedIds([item.id]);
    }
    const x = Math.min(e.clientX, window.innerWidth - 220);
    const y = Math.min(e.clientY, window.innerHeight - 260);
    setContextMenu({
      visible: true,
      x,
      y,
      targetItem: item,
    });
  };

  // Close menus when clicking outside
  const handleBackgroundClick = () => {
    setSelectedIds([]);
    setShowSortMenu(false);
    setShowNewMenu(false);
    setShowViewMenu(false);
    if (contextMenu.visible) {
      setContextMenu({ visible: false, x: 0, y: 0, targetItem: null });
    }
    if (isEditingAddress) {
      setIsEditingAddress(false);
    }
    if (renamingId) {
      handleCommitRename();
    }
  };

  // Render Icon according to file/folder type
  const renderItemIcon = (item: FileItem, sizeClass = 'w-5 h-5') => {
    if (item.type === 'folder') {
      return <Folder className={`${sizeClass} text-amber-500 fill-amber-500/30 shrink-0`} />;
    }
    if (item.extension === 'png' || item.extension === 'jpg') {
      return <Image className={`${sizeClass} text-purple-500 shrink-0`} />;
    }
    if (item.extension === 'ts' || item.extension === 'js') {
      return <FileCode className={`${sizeClass} text-emerald-500 shrink-0`} />;
    }
    if (item.extension === 'bak') {
      return <HardDrive className={`${sizeClass} text-blue-500 shrink-0`} />;
    }
    return <FileText className={`${sizeClass} text-blue-500 shrink-0`} />;
  };

  // Total selected size calculation
  const selectedSummary = useMemo(() => {
    if (selectedIds.length === 0) return '';
    if (selectedIds.length === 1) {
      const single = files.find((f) => f.id === selectedIds[0]);
      if (single) {
        return `1 item selected ${single.size ? `(${single.size})` : ''}`;
      }
    }
    return `${selectedIds.length} items selected`;
  }, [selectedIds, files]);

  return (
    <div
      onClick={handleBackgroundClick}
      onContextMenu={handleCanvasContextMenu}
      className={`h-full w-full flex flex-col select-none text-xs transition-colors relative ${
        isDark ? 'bg-slate-900 text-slate-100' : 'bg-slate-50 text-slate-800'
      }`}
    >
      {/* 1. Windows 11 Tabs & Window Header */}
      <div
        className={`h-9 px-3 border-b flex items-center justify-between shrink-0 ${
          isDark ? 'bg-slate-950/90 border-slate-800/80' : 'bg-slate-100/90 border-slate-200'
        }`}
      >
        <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar">
          {/* Active Tab */}
          <div
            className={`flex items-center space-x-2 px-3 py-1 rounded-t-lg border-t border-x text-xs font-medium ${
              isDark
                ? 'bg-slate-900 border-slate-700 text-slate-100 shadow-xs'
                : 'bg-white border-slate-200 text-slate-800 shadow-xs'
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span className="truncate max-w-[140px]">{currentFolderMeta.name}</span>
          </div>

          {/* Plus button to simulate new tab */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              navigateTo('thispc');
            }}
            className="p-1 rounded-md hover:bg-white/10 text-slate-400 transition-colors cursor-pointer"
            title="Open This PC"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center space-x-2 text-[11px] text-slate-400 hidden sm:flex">
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          <span>Windows 11 File Manager</span>
        </div>
      </div>

      {/* 2. Ribbon Command Bar (New, Cut, Copy, Paste, Rename, Delete, Sort, View) */}
      <div
        onClick={(e) => e.stopPropagation()}
        className={`px-3 py-1.5 border-b flex items-center justify-between transition-colors shrink-0 ${
          isDark ? 'bg-slate-950/60 border-slate-800/90 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
        }`}
      >
        {/* Left Action Buttons */}
        <div className="flex items-center space-x-1 relative">
          {/* New Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowNewMenu(!showNewMenu);
                setShowSortMenu(false);
                setShowViewMenu(false);
              }}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                showNewMenu
                  ? isDark
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-200 text-slate-900'
                  : isDark
                  ? 'hover:bg-slate-800 text-slate-200'
                  : 'hover:bg-slate-100 text-slate-800'
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-blue-500" />
              <span className="font-medium">New</span>
              <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
            </button>

            {/* New Menu Popup */}
            {showNewMenu && (
              <div
                className={`absolute top-full left-0 mt-1 w-44 rounded-xl border p-1 shadow-2xl z-50 animate-in fade-in-50 zoom-in-95 backdrop-blur-xl ${
                  isDark ? 'bg-slate-900/95 border-slate-700 text-slate-200' : 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-300'
                }`}
              >
                <button
                  type="button"
                  onClick={handleCreateNewFolder}
                  className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
                    isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                  }`}
                >
                  <Folder className="w-4 h-4 text-amber-500" />
                  <span className="font-medium">Folder</span>
                </button>
                <button
                  type="button"
                  onClick={handleCreateNewTextFile}
                  className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
                    isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                  }`}
                >
                  <FileText className="w-4 h-4 text-blue-500" />
                  <span>Text Document (.txt)</span>
                </button>
              </div>
            )}
          </div>

          <div className="h-4 w-[1px] bg-slate-700/40 mx-1" />

          {/* Cut Button */}
          <button
            type="button"
            onClick={() => handleClipboardAction('cut')}
            disabled={selectedIds.length === 0}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              selectedIds.length > 0
                ? isDark
                  ? 'hover:bg-slate-800 text-slate-200'
                  : 'hover:bg-slate-100 text-slate-800'
                : 'text-slate-500 opacity-40 cursor-not-allowed'
            }`}
            title="Cut (Ctrl+X)"
          >
            <Scissors className="w-3.5 h-3.5" />
          </button>

          {/* Copy Button */}
          <button
            type="button"
            onClick={() => handleClipboardAction('copy')}
            disabled={selectedIds.length === 0}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              selectedIds.length > 0
                ? isDark
                  ? 'hover:bg-slate-800 text-slate-200'
                  : 'hover:bg-slate-100 text-slate-800'
                : 'text-slate-500 opacity-40 cursor-not-allowed'
            }`}
            title="Copy (Ctrl+C)"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>

          {/* Paste Button */}
          <button
            type="button"
            onClick={handlePasteAction}
            disabled={!clipboard}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              clipboard
                ? isDark
                  ? 'hover:bg-slate-800 text-blue-400'
                  : 'hover:bg-slate-100 text-blue-600'
                : 'text-slate-500 opacity-40 cursor-not-allowed'
            }`}
            title="Paste (Ctrl+V)"
          >
            <Clipboard className="w-3.5 h-3.5" />
          </button>

          {/* Rename Button */}
          <button
            type="button"
            onClick={() => {
              if (selectedIds.length === 1) {
                const target = files.find((f) => f.id === selectedIds[0]);
                if (target) handleStartRename(target);
              }
            }}
            disabled={selectedIds.length !== 1}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              selectedIds.length === 1
                ? isDark
                  ? 'hover:bg-slate-800 text-slate-200'
                  : 'hover:bg-slate-100 text-slate-800'
                : 'text-slate-500 opacity-40 cursor-not-allowed'
            }`}
            title="Rename (F2)"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>

          {/* Delete Button */}
          <button
            type="button"
            onClick={handleDeleteSelected}
            disabled={selectedIds.length === 0}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              selectedIds.length > 0
                ? isDark
                  ? 'hover:bg-rose-950/50 text-rose-400'
                  : 'hover:bg-rose-50 text-rose-600'
                : 'text-slate-500 opacity-40 cursor-not-allowed'
            }`}
            title="Delete (Del)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-[1px] bg-slate-700/40 mx-1" />

          {/* Refresh Button */}
          <button
            type="button"
            onClick={handleRefresh}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-700'
            }`}
            title="Refresh (F5)"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>

        {/* Right View & Sort Controls */}
        <div className="flex items-center space-x-1.5 relative">
          {/* Sort Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowSortMenu(!showSortMenu);
                setShowNewMenu(false);
                setShowViewMenu(false);
              }}
              className={`flex items-center space-x-1 px-2 py-1 rounded-md transition-colors cursor-pointer ${
                showSortMenu
                  ? isDark
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-200 text-slate-900'
                  : isDark
                  ? 'hover:bg-slate-800 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
              title="Sort options"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sort</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showSortMenu && (
              <div
                className={`absolute top-full right-0 mt-1 w-44 rounded-xl border p-1 shadow-2xl z-50 animate-in fade-in-50 zoom-in-95 backdrop-blur-xl ${
                  isDark ? 'bg-slate-900/95 border-slate-700 text-slate-200' : 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-300'
                }`}
              >
                <div className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase">Sort by</div>
                {(['name', 'date', 'type', 'size'] as SortField[]).map((field) => (
                  <button
                    key={field}
                    type="button"
                    onClick={() => {
                      if (sortField === field) {
                        setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
                      } else {
                        setSortField(field);
                        setSortDirection('asc');
                      }
                      setShowSortMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left capitalize cursor-pointer ${
                      sortField === field
                        ? isDark
                          ? 'bg-blue-600/20 text-blue-400 font-medium'
                          : 'bg-blue-50 text-blue-700 font-medium'
                        : isDark
                        ? 'hover:bg-slate-800'
                        : 'hover:bg-slate-100'
                    }`}
                  >
                    <span>{field === 'date' ? 'Date modified' : field}</span>
                    {sortField === field && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}

                <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

                <button
                  type="button"
                  onClick={() => {
                    setSortDirection('asc');
                    setShowSortMenu(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left cursor-pointer ${
                    sortDirection === 'asc'
                      ? isDark
                        ? 'bg-blue-600/20 text-blue-400 font-medium'
                        : 'bg-blue-50 text-blue-700 font-medium'
                      : isDark
                      ? 'hover:bg-slate-800'
                      : 'hover:bg-slate-100'
                  }`}
                >
                  <span>Ascending</span>
                  {sortDirection === 'asc' && <Check className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSortDirection('desc');
                    setShowSortMenu(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left cursor-pointer ${
                    sortDirection === 'desc'
                      ? isDark
                        ? 'bg-blue-600/20 text-blue-400 font-medium'
                        : 'bg-blue-50 text-blue-700 font-medium'
                      : isDark
                      ? 'hover:bg-slate-800'
                      : 'hover:bg-slate-100'
                  }`}
                >
                  <span>Descending</span>
                  {sortDirection === 'desc' && <Check className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>

          {/* View Mode Toggle */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowViewMenu(!showViewMenu);
                setShowNewMenu(false);
                setShowSortMenu(false);
              }}
              className={`flex items-center space-x-1 px-2 py-1 rounded-md transition-colors cursor-pointer ${
                showViewMenu
                  ? isDark
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-200 text-slate-900'
                  : isDark
                  ? 'hover:bg-slate-800 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
              title="View options"
            >
              {viewMode === 'details' ? (
                <List className="w-3.5 h-3.5" />
              ) : viewMode === 'large' ? (
                <Grid3X3 className="w-3.5 h-3.5" />
              ) : (
                <LayoutGrid className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">View</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showViewMenu && (
              <div
                className={`absolute top-full right-0 mt-1 w-40 rounded-xl border p-1 shadow-2xl z-50 animate-in fade-in-50 zoom-in-95 backdrop-blur-xl ${
                  isDark ? 'bg-slate-900/95 border-slate-700 text-slate-200' : 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-300'
                }`}
              >
                <button
                  type="button"
                  onClick={() => {
                    setViewMode('details');
                    setShowViewMenu(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left cursor-pointer ${
                    viewMode === 'details'
                      ? isDark
                        ? 'bg-blue-600/20 text-blue-400 font-medium'
                        : 'bg-blue-50 text-blue-700 font-medium'
                      : isDark
                      ? 'hover:bg-slate-800'
                      : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <List className="w-3.5 h-3.5" />
                    <span>Details</span>
                  </div>
                  {viewMode === 'details' && <Check className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setViewMode('grid');
                    setShowViewMenu(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left cursor-pointer ${
                    viewMode === 'grid'
                      ? isDark
                        ? 'bg-blue-600/20 text-blue-400 font-medium'
                        : 'bg-blue-50 text-blue-700 font-medium'
                      : isDark
                      ? 'hover:bg-slate-800'
                      : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span>Medium icons</span>
                  </div>
                  {viewMode === 'grid' && <Check className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setViewMode('large');
                    setShowViewMenu(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left cursor-pointer ${
                    viewMode === 'large'
                      ? isDark
                        ? 'bg-blue-600/20 text-blue-400 font-medium'
                        : 'bg-blue-50 text-blue-700 font-medium'
                      : isDark
                      ? 'hover:bg-slate-800'
                      : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Grid3X3 className="w-3.5 h-3.5" />
                    <span>Large icons</span>
                  </div>
                  {viewMode === 'large' && <Check className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. Address & Navigation Bar with Breadcrumbs & Search */}
      <div
        onClick={(e) => e.stopPropagation()}
        className={`px-3 py-1.5 border-b flex items-center space-x-2 shrink-0 ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-100/70 border-slate-200'
        }`}
      >
        {/* Back, Forward, Up History Buttons */}
        <div className="flex items-center space-x-0.5 text-slate-400 shrink-0">
          <button
            type="button"
            onClick={handleGoBack}
            disabled={historyIndex === 0}
            className="p-1 rounded-md hover:text-slate-200 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="Back (Alt+Left Arrow)"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleGoForward}
            disabled={historyIndex >= history.length - 1}
            className="p-1 rounded-md hover:text-slate-200 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="Forward (Alt+Right Arrow)"
          >
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleGoUp}
            disabled={currentFolderId === 'thispc'}
            className="p-1 rounded-md hover:text-slate-200 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="Up to parent folder (Alt+Up Arrow)"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

        {/* Address Breadcrumb Bar */}
        <div
          className={`flex-1 flex items-center px-2 py-0.5 rounded-lg border text-xs min-w-0 transition-colors ${
            isDark ? 'bg-slate-950/70 border-slate-700/80 text-slate-200' : 'bg-white border-slate-300 text-slate-700'
          }`}
        >
          <FolderOpen className="w-4 h-4 text-amber-500 mr-2 shrink-0" />

          {isEditingAddress ? (
            /* Editable Path Input */
            <form onSubmit={handleAddressSubmit} className="flex-1 flex items-center">
              <input
                type="text"
                autoFocus
                value={addressInputText}
                onChange={(e) => setAddressInputText(e.target.value)}
                onBlur={() => setIsEditingAddress(false)}
                className="w-full bg-transparent border-0 focus:outline-hidden text-xs font-mono"
              />
            </form>
          ) : (
            /* Interactive Breadcrumbs Trail */
            <div
              onClick={() => {
                setAddressInputText(currentFolderMeta.fullPath);
                setIsEditingAddress(true);
              }}
              className="flex-1 flex items-center overflow-x-auto no-scrollbar py-0.5 cursor-text"
              title="Click to edit path"
            >
              {breadcrumbs.map((crumb, idx) => {
                const isLast = idx === breadcrumbs.length - 1;
                return (
                  <React.Fragment key={`${crumb.id}-${idx}`}>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigateTo(crumb.id);
                      }}
                      className={`px-1.5 py-0.5 rounded-md hover:bg-white/15 truncate font-medium transition-colors cursor-pointer ${
                        isLast ? 'text-slate-100 dark:text-slate-100 font-semibold' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {crumb.name}
                    </button>
                    {!isLast && <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0 mx-0.5" />}
                  </React.Fragment>
                );
              })}
            </div>
          )}

          {/* Copy path shortcut */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleCopyPath();
            }}
            className="p-1 rounded-md hover:bg-white/10 text-slate-400 hover:text-slate-200 ml-1 transition-colors cursor-pointer shrink-0"
            title="Copy path"
          >
            {copiedPathToast ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Live Search Input */}
        <div
          className={`w-36 sm:w-56 flex items-center px-2.5 py-1 rounded-lg border transition-colors shrink-0 ${
            isDark ? 'bg-slate-950/70 border-slate-700/80 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
          }`}
        >
          <Search className="w-3.5 h-3.5 text-slate-400 mr-1.5 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${currentFolderMeta.name}`}
            className="w-full bg-transparent border-0 focus:outline-hidden text-xs"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="p-0.5 hover:text-slate-200 text-slate-400 cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* 4. Main Body: Sidebar Navigation Pane + Directory Viewport */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar (Quick Access, Desktop, Documents, Downloads, Pictures, This PC) */}
        <div
          onClick={(e) => e.stopPropagation()}
          className={`w-44 sm:w-52 border-r p-2 space-y-1 overflow-y-auto shrink-0 select-none ${
            isDark ? 'bg-slate-950/50 border-slate-800' : 'bg-slate-100/50 border-slate-200'
          }`}
        >
          {/* Quick Access Section */}
          <div className="px-2 py-1 flex items-center justify-between text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            <span className="flex items-center space-x-1.5">
              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span>Quick access</span>
            </span>
          </div>

          {/* Desktop */}
          <button
            type="button"
            onClick={() => navigateTo('desktop')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'desktop'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <DesktopIcon className="w-4 h-4 text-sky-500 shrink-0" />
            <span className="truncate">Desktop</span>
          </button>

          {/* Documents */}
          <button
            type="button"
            onClick={() => navigateTo('documents')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'documents'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <FileText className="w-4 h-4 text-blue-500 shrink-0" />
            <span className="truncate">Documents</span>
          </button>

          {/* Downloads */}
          <button
            type="button"
            onClick={() => navigateTo('downloads')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'downloads'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <Download className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="truncate">Downloads</span>
          </button>

          {/* Pictures */}
          <button
            type="button"
            onClick={() => navigateTo('pictures')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'pictures'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <Image className="w-4 h-4 text-purple-500 shrink-0" />
            <span className="truncate">Pictures</span>
          </button>

          <div className={`my-2 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

          {/* This PC Section */}
          <div className="px-2 py-1 flex items-center justify-between text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            <span className="flex items-center space-x-1.5">
              <Laptop className="w-3 h-3 text-blue-400" />
              <span>This PC</span>
            </span>
          </div>

          {/* This PC Root */}
          <button
            type="button"
            onClick={() => navigateTo('thispc')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'thispc'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <Laptop className="w-4 h-4 text-blue-500 shrink-0" />
            <span className="truncate font-medium">This PC</span>
          </button>

          {/* Local Disk (C:) */}
          <button
            type="button"
            onClick={() => navigateTo('drive_c')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'drive_c'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <HardDrive className="w-4 h-4 text-blue-400 shrink-0" />
            <div className="flex-1 truncate">
              <div className="truncate">Local Disk (C:)</div>
              <div className="w-full bg-slate-700/40 rounded-full h-1 mt-1">
                <div className="bg-blue-500 h-1 rounded-full w-[38%]" />
              </div>
            </div>
          </button>

          {/* Local Disk (D:) */}
          <button
            type="button"
            onClick={() => navigateTo('drive_d')}
            className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer ${
              currentFolderId === 'drive_d'
                ? isDark ? 'bg-blue-600/25 text-blue-400 font-semibold ring-1 ring-blue-500/30' : 'bg-blue-100 text-blue-900 font-semibold ring-1 ring-blue-300'
                : isDark ? 'hover:bg-slate-800/70 text-slate-300' : 'hover:bg-slate-200/70 text-slate-700'
            }`}
          >
            <HardDrive className="w-4 h-4 text-emerald-400 shrink-0" />
            <div className="flex-1 truncate">
              <div className="truncate">Local Disk (D:)</div>
              <div className="w-full bg-slate-700/40 rounded-full h-1 mt-1">
                <div className="bg-emerald-500 h-1 rounded-full w-[25%]" />
              </div>
            </div>
          </button>
        </div>

        {/* Directory Viewport (Folders & Files Grid/Details) */}
        <div
          className={`flex-1 overflow-y-auto p-3 transition-opacity ${
            isRefreshing ? 'opacity-40' : 'opacity-100'
          }`}
        >
          {/* SPECIAL VIEW: "This PC" Overview */}
          {currentFolderId === 'thispc' && !searchQuery ? (
            <div className="space-y-6">
              {/* Folders Section */}
              <div>
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
                  Folders (4)
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { id: 'desktop', name: 'Desktop', icon: <DesktopIcon className="w-8 h-8 text-sky-500" /> },
                    { id: 'documents', name: 'Documents', icon: <FileText className="w-8 h-8 text-blue-500" /> },
                    { id: 'downloads', name: 'Downloads', icon: <Download className="w-8 h-8 text-emerald-500" /> },
                    { id: 'pictures', name: 'Pictures', icon: <Image className="w-8 h-8 text-purple-500" /> },
                  ].map((folder) => (
                    <div
                      key={folder.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        navigateTo(folder.id);
                      }}
                      className={`p-3 rounded-xl border flex items-center space-x-3 cursor-pointer transition-all ${
                        isDark
                          ? 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600'
                          : 'bg-white border-slate-200 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      {folder.icon}
                      <span className="font-medium text-xs truncate">{folder.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Devices and Drives Section */}
              <div>
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
                  Devices and drives (2)
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {SYSTEM_DRIVES.map((drive) => (
                    <div
                      key={drive.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        navigateTo(drive.id);
                      }}
                      className={`p-3 rounded-xl border flex items-center space-x-3.5 cursor-pointer transition-all ${
                        isDark
                          ? 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600'
                          : 'bg-white border-slate-200 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-500 shrink-0">
                        <HardDrive className="w-7 h-7" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-xs truncate">{drive.name}</div>
                        <div className="w-full bg-slate-700/30 rounded-full h-1.5 my-1.5 overflow-hidden">
                          <div
                            style={{ width: `${(drive.usedSpaceGB / drive.totalSpaceGB) * 100}%` }}
                            className="bg-blue-500 h-full rounded-full"
                          />
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {drive.freeSpaceGB} GB free of {drive.totalSpaceGB} GB
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : sortedItems.length === 0 ? (
            /* Empty Directory State */
            <div className="flex flex-col items-center justify-center h-56 text-slate-400 text-center">
              <FolderOpen className="w-12 h-12 mb-2 stroke-1 opacity-40 text-amber-500" />
              <p className="font-medium text-xs">
                {searchQuery ? `No matches for "${searchQuery}"` : 'This folder is empty'}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                {searchQuery ? 'Check your spelling or try another folder' : 'Click "New" or right-click to add a file or folder'}
              </p>
            </div>
          ) : viewMode === 'details' ? (
            /* DETAILS VIEW */
            <div className="w-full">
              {/* Table Headers */}
              <div
                className={`grid grid-cols-12 pb-1.5 border-b font-medium text-[11px] ${
                  isDark ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'
                }`}
              >
                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    setSortField('name');
                    setSortDirection((d) => (sortField === 'name' && d === 'asc' ? 'desc' : 'asc'));
                  }}
                  className="col-span-6 flex items-center space-x-1 cursor-pointer hover:text-slate-200"
                >
                  <span>Name</span>
                  {sortField === 'name' && (
                    <span className="text-blue-500">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                  )}
                </div>

                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    setSortField('date');
                    setSortDirection((d) => (sortField === 'date' && d === 'asc' ? 'desc' : 'asc'));
                  }}
                  className="col-span-3 flex items-center space-x-1 cursor-pointer hover:text-slate-200"
                >
                  <span>Date modified</span>
                  {sortField === 'date' && (
                    <span className="text-blue-500">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                  )}
                </div>

                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    setSortField('type');
                    setSortDirection((d) => (sortField === 'type' && d === 'asc' ? 'desc' : 'asc'));
                  }}
                  className="col-span-2 flex items-center space-x-1 cursor-pointer hover:text-slate-200"
                >
                  <span>Type</span>
                  {sortField === 'type' && (
                    <span className="text-blue-500">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                  )}
                </div>

                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    setSortField('size');
                    setSortDirection((d) => (sortField === 'size' && d === 'asc' ? 'desc' : 'asc'));
                  }}
                  className="col-span-1 text-right flex items-center justify-end space-x-1 cursor-pointer hover:text-slate-200"
                >
                  <span>Size</span>
                  {sortField === 'size' && (
                    <span className="text-blue-500">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                  )}
                </div>
              </div>

              {/* Items Rows */}
              <div className="mt-1 space-y-0.5">
                {sortedItems.map((item) => {
                  const isSelected = selectedIds.includes(item.id);
                  const isRenaming = renamingId === item.id;

                  return (
                    <div
                      key={item.id}
                      onClick={(e) => handleItemClick(e, item)}
                      onDoubleClick={() => handleItemDoubleClick(item)}
                      onContextMenu={(e) => handleItemContextMenu(e, item)}
                      className={`grid grid-cols-12 items-center px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors ${
                        isSelected
                          ? isDark
                            ? 'bg-blue-600/25 text-white border border-blue-500/40 ring-1 ring-blue-500/20'
                            : 'bg-blue-100 text-blue-900 border border-blue-300 ring-1 ring-blue-300/40'
                          : isDark
                          ? 'hover:bg-slate-800/60 text-slate-200'
                          : 'hover:bg-slate-100 text-slate-800'
                      }`}
                    >
                      {/* Name + Icon */}
                      <div className="col-span-6 flex items-center space-x-2.5 truncate pr-2">
                        {renderItemIcon(item)}

                        {isRenaming ? (
                          <input
                            ref={renameInputRef}
                            type="text"
                            value={renameValue}
                            onChange={(e) => setRenameValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleCommitRename();
                              if (e.key === 'Escape') setRenamingId(null);
                            }}
                            onBlur={handleCommitRename}
                            onClick={(e) => e.stopPropagation()}
                            className="bg-white dark:bg-slate-950 border border-blue-500 rounded px-1.5 py-0.5 text-xs text-slate-900 dark:text-white focus:outline-hidden w-full"
                          />
                        ) : (
                          <span className="truncate font-medium">{item.name}</span>
                        )}
                      </div>

                      {/* Date */}
                      <div className="col-span-3 text-slate-400 truncate text-[11px]">
                        {item.date}
                      </div>

                      {/* Type */}
                      <div className="col-span-2 text-slate-400 truncate text-[11px] capitalize">
                        {item.type === 'folder' ? 'File folder' : `${item.extension?.toUpperCase() || 'File'}`}
                      </div>

                      {/* Size */}
                      <div className="col-span-1 text-right text-slate-400 truncate text-[11px]">
                        {item.size || (item.type === 'folder' ? '--' : '0 KB')}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : viewMode === 'grid' ? (
            /* MEDIUM GRID VIEW */
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {sortedItems.map((item) => {
                const isSelected = selectedIds.includes(item.id);
                const isRenaming = renamingId === item.id;

                return (
                  <div
                    key={item.id}
                    onClick={(e) => handleItemClick(e, item)}
                    onDoubleClick={() => handleItemDoubleClick(item)}
                    onContextMenu={(e) => handleItemContextMenu(e, item)}
                    className={`flex flex-col items-center p-2.5 rounded-xl cursor-pointer text-center transition-all ${
                      isSelected
                        ? isDark
                          ? 'bg-blue-600/25 border border-blue-500/50 ring-1 ring-blue-500/20'
                          : 'bg-blue-100 border border-blue-300 ring-1 ring-blue-300/40'
                        : isDark
                        ? 'hover:bg-slate-800/70 border border-transparent'
                        : 'hover:bg-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="mb-2 transition-transform hover:scale-105">
                      {renderItemIcon(item, 'w-10 h-10')}
                    </div>

                    {isRenaming ? (
                      <input
                        ref={renameInputRef}
                        type="text"
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleCommitRename();
                          if (e.key === 'Escape') setRenamingId(null);
                        }}
                        onBlur={handleCommitRename}
                        onClick={(e) => e.stopPropagation()}
                        className="bg-white dark:bg-slate-950 border border-blue-500 rounded px-1 text-[11px] text-center w-full focus:outline-hidden"
                      />
                    ) : (
                      <span className="text-[11px] font-medium line-clamp-2 break-all px-1">
                        {item.name}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            /* LARGE ICONS VIEW */
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {sortedItems.map((item) => {
                const isSelected = selectedIds.includes(item.id);
                const isRenaming = renamingId === item.id;

                return (
                  <div
                    key={item.id}
                    onClick={(e) => handleItemClick(e, item)}
                    onDoubleClick={() => handleItemDoubleClick(item)}
                    onContextMenu={(e) => handleItemContextMenu(e, item)}
                    className={`flex flex-col items-center p-4 rounded-2xl cursor-pointer text-center transition-all ${
                      isSelected
                        ? isDark
                          ? 'bg-blue-600/25 border border-blue-500/50 ring-1 ring-blue-500/20'
                          : 'bg-blue-100 border border-blue-300 ring-1 ring-blue-300/40'
                        : isDark
                        ? 'hover:bg-slate-800/70 border border-transparent'
                        : 'hover:bg-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="mb-3 transition-transform hover:scale-105">
                      {renderItemIcon(item, 'w-16 h-16')}
                    </div>

                    {isRenaming ? (
                      <input
                        ref={renameInputRef}
                        type="text"
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleCommitRename();
                          if (e.key === 'Escape') setRenamingId(null);
                        }}
                        onBlur={handleCommitRename}
                        onClick={(e) => e.stopPropagation()}
                        className="bg-white dark:bg-slate-950 border border-blue-500 rounded px-1.5 py-0.5 text-xs text-center w-full focus:outline-hidden"
                      />
                    ) : (
                      <>
                        <span className="text-xs font-medium line-clamp-2 break-all mb-0.5">
                          {item.name}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {item.size || (item.type === 'folder' ? 'Folder' : '')}
                        </span>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* 5. Status Bar */}
      <div
        className={`px-3 py-1 border-t text-[10px] flex items-center justify-between shrink-0 ${
          isDark ? 'bg-slate-950/70 border-slate-800 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-500'
        }`}
      >
        <div className="flex items-center space-x-3">
          <span>
            {currentFolderId === 'thispc'
              ? `${SYSTEM_DRIVES.length} drives, 4 folders`
              : `${sortedItems.length} item${sortedItems.length === 1 ? '' : 's'}`}
          </span>
          {selectedSummary && (
            <>
              <span>•</span>
              <span className="text-blue-500 font-medium">{selectedSummary}</span>
            </>
          )}
        </div>

        <div className="flex items-center space-x-2">
          {clipboard && (
            <span className="text-amber-500 font-medium">
              1 item ready to {clipboard.action}
            </span>
          )}
        </div>
      </div>

      {/* 6. Windows 11 Acrylic Context Menu */}
      {contextMenu.visible && (
        <div
          onClick={(e) => e.stopPropagation()}
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
          className={`fixed z-50 w-52 rounded-2xl p-1.5 border shadow-2xl backdrop-blur-2xl text-xs transition-opacity animate-in fade-in-50 zoom-in-95 ${
            isDark
              ? 'bg-slate-900/95 border-white/15 text-slate-200 shadow-black/80'
              : 'bg-white/95 border-slate-200/90 text-slate-800 shadow-slate-400/40'
          }`}
        >
          {contextMenu.targetItem ? (
            /* Item Right-Click Menu */
            <>
              <button
                type="button"
                onClick={() => {
                  handleItemDoubleClick(contextMenu.targetItem!);
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left font-medium transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <FolderOpen className="w-4 h-4 text-blue-500" />
                <span>Open</span>
              </button>

              {contextMenu.targetItem.type === 'file' && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenFileInNotepad?.(contextMenu.targetItem!.name, contextMenu.targetItem!.content || '');
                    setContextMenu({ ...contextMenu, visible: false });
                  }}
                  className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                    isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                  }`}
                >
                  <FileText className="w-4 h-4 text-sky-500" />
                  <span>Open in Notepad</span>
                </button>
              )}

              <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

              <button
                type="button"
                onClick={() => {
                  handleClipboardAction('cut');
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Scissors className="w-4 h-4" />
                <span>Cut</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleClipboardAction('copy');
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Copy className="w-4 h-4" />
                <span>Copy</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleStartRename(contextMenu.targetItem!);
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Edit2 className="w-4 h-4" />
                <span>Rename</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleDeleteSelected();
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className="w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>

              <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

              <button
                type="button"
                onClick={() => {
                  setPropertiesItem(contextMenu.targetItem!);
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Info className="w-4 h-4 text-slate-400" />
                <span>Properties</span>
              </button>
            </>
          ) : (
            /* Canvas Empty Space Right-Click Menu */
            <>
              {/* New > Folder */}
              <button
                type="button"
                onClick={() => {
                  handleCreateNewFolder();
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Folder className="w-4 h-4 text-amber-500" />
                <span>New folder</span>
              </button>

              {/* New > Text Document */}
              <button
                type="button"
                onClick={() => {
                  handleCreateNewTextFile();
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <FileText className="w-4 h-4 text-blue-500" />
                <span>New text document</span>
              </button>

              <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />

              {/* Paste */}
              <button
                type="button"
                disabled={!clipboard}
                onClick={() => {
                  handlePasteAction();
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  clipboard
                    ? isDark
                      ? 'hover:bg-slate-800 text-slate-200'
                      : 'hover:bg-slate-100 text-slate-800'
                    : 'text-slate-500 opacity-40 cursor-not-allowed'
                }`}
              >
                <Clipboard className="w-4 h-4" />
                <span>Paste</span>
              </button>

              {/* Select All */}
              <button
                type="button"
                onClick={() => {
                  handleSelectAll();
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>Select all</span>
              </button>

              {/* Refresh */}
              <button
                type="button"
                onClick={() => {
                  handleRefresh();
                  setContextMenu({ ...contextMenu, visible: false });
                }}
                className={`w-full flex items-center space-x-2.5 px-3 py-1.5 rounded-xl text-left transition-colors cursor-pointer ${
                  isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                }`}
              >
                <RefreshCw className="w-4 h-4" />
                <span>Refresh</span>
              </button>
            </>
          )}
        </div>
      )}

      {/* 7. Undo Deletion Toast */}
      {toastMessage && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-slate-900/90 dark:bg-slate-800/95 border border-white/20 text-white shadow-2xl backdrop-blur-xl flex items-center space-x-3 text-xs animate-in fade-in slide-in-from-bottom-2">
          <span>{toastMessage}</span>
          {deletedUndoItem && (
            <button
              type="button"
              onClick={handleUndoDelete}
              className="px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium cursor-pointer transition-colors"
            >
              Undo
            </button>
          )}
        </div>
      )}

      {/* 8. Properties Modal */}
      {propertiesItem && (
        <FilePropertiesModal
          item={propertiesItem}
          theme={theme}
          onClose={() => setPropertiesItem(null)}
        />
      )}

      {/* 9. Photos Image Viewer Modal */}
      {viewingImageItem && (
        <ImageViewerModal
          item={viewingImageItem}
          theme={theme}
          onClose={() => setViewingImageItem(null)}
        />
      )}
    </div>
  );
};
