import React, { useState, useEffect } from 'react';
import { SystemSettings, SettingsSectionId } from '../../types';
import { SettingsSidebar } from './settings/SettingsSidebar';
import { SettingsHeader } from './settings/SettingsHeader';
import { PersonalizationSection } from './settings/PersonalizationSection';
import { SystemSection } from './settings/SystemSection';
import { BluetoothSection } from './settings/BluetoothSection';
import { NetworkSection } from './settings/NetworkSection';
import { AppsSection } from './settings/AppsSection';
import { AccountsSection } from './settings/AccountsSection';
import { TimeLanguageSection } from './settings/TimeLanguageSection';
import { GamingSection } from './settings/GamingSection';
import { AccessibilitySection } from './settings/AccessibilitySection';
import { PrivacySecuritySection } from './settings/PrivacySecuritySection';

interface SettingsAppProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  initialTab?: string;
}

export const SettingsApp: React.FC<SettingsAppProps> = ({
  settings,
  onUpdateSettings,
  initialTab,
}) => {
  const isDark = settings.theme === 'dark';

  // Normalize initialTab to valid SettingsSectionId
  const getInitialSection = (tab?: string): SettingsSectionId => {
    if (!tab) return 'personalization';
    if (tab === 'time') return 'time-language';
    if (tab === 'privacy') return 'privacy-security';
    const validSections: SettingsSectionId[] = [
      'system',
      'bluetooth',
      'network',
      'personalization',
      'apps',
      'accounts',
      'time-language',
      'gaming',
      'accessibility',
      'privacy-security',
    ];
    return validSections.includes(tab as SettingsSectionId)
      ? (tab as SettingsSectionId)
      : 'personalization';
  };

  const [activeSection, setActiveSection] = useState<SettingsSectionId>(
    getInitialSection(initialTab)
  );
  const [history, setHistory] = useState<SettingsSectionId[]>([getInitialSection(initialTab)]);

  useEffect(() => {
    if (initialTab) {
      const sec = getInitialSection(initialTab);
      setActiveSection(sec);
      setHistory((prev) => (prev[prev.length - 1] === sec ? prev : [...prev, sec]));
    }
  }, [initialTab]);

  const handleSelectSection = (sectionId: SettingsSectionId) => {
    setActiveSection(sectionId);
    setHistory((prev) => [...prev, sectionId]);
  };

  const handleBack = () => {
    if (history.length > 1) {
      const newHistory = history.slice(0, -1);
      setHistory(newHistory);
      setActiveSection(newHistory[newHistory.length - 1]);
    }
  };

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'personalization':
        return (
          <PersonalizationSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'system':
        return (
          <SystemSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'bluetooth':
        return (
          <BluetoothSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'network':
        return (
          <NetworkSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'apps':
        return (
          <AppsSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'accounts':
        return (
          <AccountsSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'time-language':
        return (
          <TimeLanguageSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'gaming':
        return (
          <GamingSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'accessibility':
        return (
          <AccessibilitySection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      case 'privacy-security':
        return (
          <PrivacySecuritySection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
      default:
        return (
          <PersonalizationSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            isDark={isDark}
          />
        );
    }
  };

  return (
    <div
      className={`h-full w-full flex select-none text-xs transition-colors overflow-hidden ${
        isDark ? 'bg-slate-900 text-slate-100' : 'bg-slate-50 text-slate-800'
      }`}
    >
      {/* Sidebar Navigation */}
      <SettingsSidebar
        activeSection={activeSection}
        onSelectSection={handleSelectSection}
        isDark={isDark}
        accentColor={settings.accentColor}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header with Breadcrumb & Search */}
        <SettingsHeader
          activeSection={activeSection}
          canGoBack={history.length > 1}
          onBack={handleBack}
          onSelectSection={handleSelectSection}
          isDark={isDark}
          accentColor={settings.accentColor}
        />

        {/* Scrollable Section Content */}
        <div
          className={`flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar ${
            isDark ? 'bg-slate-950/40' : 'bg-slate-100/30'
          }`}
        >
          {renderSectionContent()}
        </div>
      </div>
    </div>
  );
};
