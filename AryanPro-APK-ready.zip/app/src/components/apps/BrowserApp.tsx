import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Lock,
  Star,
  Search,
  Plus,
  X,
  ExternalLink,
  Globe,
  Newspaper,
  CloudSun,
  TrendingUp,
  Bookmark,
} from 'lucide-react';
import { AppTheme } from '../../types';

interface BrowserAppProps {
  theme: AppTheme;
}

interface TabItem {
  id: string;
  title: string;
  url: string;
}

export const BrowserApp: React.FC<BrowserAppProps> = ({ theme }) => {
  const isDark = theme === 'dark';

  const [tabs, setTabs] = useState<TabItem[]>([
    { id: 'tab-1', title: 'New Tab', url: 'https://bing.com' },
  ]);
  const [activeTabId, setActiveTabId] = useState('tab-1');
  const [urlInput, setUrlInput] = useState('https://bing.com');
  const [isLoading, setIsLoading] = useState(false);
  const [pageType, setPageType] = useState<'home' | 'search' | 'wiki' | 'aistudio'>('home');
  const [searchQuery, setSearchQuery] = useState('');

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const handleNavigate = (url: string) => {
    let cleanUrl = url.trim();
    if (!cleanUrl) return;

    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      if (cleanUrl.includes('.')) {
        cleanUrl = 'https://' + cleanUrl;
      } else {
        // Query search
        setSearchQuery(cleanUrl);
        setPageType('search');
        setUrlInput(`https://bing.com/search?q=${encodeURIComponent(cleanUrl)}`);
        return;
      }
    }

    setUrlInput(cleanUrl);
    setIsLoading(true);

    if (cleanUrl.includes('wikipedia')) {
      setPageType('wiki');
    } else if (cleanUrl.includes('ai.studio') || cleanUrl.includes('aistudio')) {
      setPageType('aistudio');
    } else if (cleanUrl.includes('bing.com/search') || cleanUrl.includes('google.com/search')) {
      setPageType('search');
    } else {
      setPageType('home');
    }

    // Update tab title
    setTabs(
      tabs.map((t) =>
        t.id === activeTabId
          ? {
              ...t,
              url: cleanUrl,
              title: cleanUrl.replace('https://', '').replace('http://', '').split('/')[0] || 'Web',
            }
          : t
      )
    );

    setTimeout(() => setIsLoading(false), 300);
  };

  const handleAddTab = () => {
    const newId = `tab-${Date.now()}`;
    const newTab: TabItem = {
      id: newId,
      title: 'New Tab',
      url: 'https://bing.com',
    };
    setTabs([...tabs, newTab]);
    setActiveTabId(newId);
    setUrlInput('https://bing.com');
    setPageType('home');
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    const nextTabs = tabs.filter((t) => t.id !== id);
    setTabs(nextTabs);
    if (activeTabId === id) {
      setActiveTabId(nextTabs[0].id);
      setUrlInput(nextTabs[0].url);
    }
  };

  return (
    <div
      className={`h-full w-full flex flex-col select-none text-xs transition-colors ${
        isDark ? 'bg-slate-900 text-slate-100' : 'bg-slate-100 text-slate-800'
      }`}
    >
      {/* Top Tab Bar */}
      <div
        className={`flex items-center px-2 pt-1 border-b space-x-1 shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-200 border-slate-300'
        }`}
      >
        <div className="flex items-center space-x-1 overflow-x-auto max-w-[calc(100%-40px)]">
          {tabs.map((t) => {
            const isActive = t.id === activeTabId;
            return (
              <div
                key={t.id}
                onClick={() => {
                  setActiveTabId(t.id);
                  setUrlInput(t.url);
                }}
                className={`group flex items-center space-x-2 px-3 py-1.5 rounded-t-lg max-w-[180px] min-w-[120px] cursor-pointer transition-all ${
                  isActive
                    ? isDark
                      ? 'bg-slate-900 text-slate-100 font-medium shadow-xs'
                      : 'bg-white text-slate-900 font-medium shadow-xs'
                    : isDark
                    ? 'hover:bg-slate-900/60 text-slate-400'
                    : 'hover:bg-slate-100/70 text-slate-600'
                }`}
              >
                <Globe className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span className="truncate text-xs flex-1">{t.title}</span>
                {tabs.length > 1 && (
                  <button
                    type="button"
                    onClick={(e) => handleCloseTab(t.id, e)}
                    className="opacity-0 group-hover:opacity-100 hover:bg-slate-500/20 p-0.5 rounded transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={handleAddTab}
          className="p-1 rounded-md hover:bg-slate-700/20 text-slate-400 hover:text-slate-200"
          title="New Tab"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* URL & Controls Bar */}
      <div
        className={`px-3 py-1.5 border-b flex items-center space-x-2 shrink-0 ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center space-x-1 text-slate-400">
          <button
            type="button"
            onClick={() => {
              setPageType('home');
              setUrlInput('https://bing.com');
            }}
            className="p-1 rounded hover:bg-slate-700/20 hover:text-slate-200"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
          <button type="button" className="p-1 rounded hover:bg-slate-700/20 hover:text-slate-200" disabled>
            <ArrowRight className="w-3.5 h-3.5 opacity-40" />
          </button>
          <button
            type="button"
            onClick={() => handleNavigate(urlInput)}
            className="p-1 rounded hover:bg-slate-700/20 hover:text-slate-200"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <button
            type="button"
            onClick={() => {
              setUrlInput('https://bing.com');
              setPageType('home');
            }}
            className="p-1 rounded hover:bg-slate-700/20 hover:text-slate-200"
          >
            <Home className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Address Input */}
        <div
          className={`flex-1 flex items-center px-3 py-1 rounded-full border ${
            isDark
              ? 'bg-slate-950/70 border-slate-700 text-slate-200 focus-within:border-blue-500'
              : 'bg-slate-100 border-slate-200 text-slate-800 focus-within:bg-white focus-within:border-blue-500'
          }`}
        >
          <Lock className="w-3 h-3 text-emerald-500 mr-2 shrink-0" />
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleNavigate(urlInput);
            }}
            placeholder="Search the web or enter URL"
            className="w-full bg-transparent border-0 focus:outline-hidden text-xs"
          />
          <button
            type="button"
            onClick={() => handleNavigate(urlInput)}
            className="p-0.5 text-slate-400 hover:text-blue-500 cursor-pointer"
          >
            <Search className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Bookmarks Bar */}
      <div
        className={`px-3 py-1 border-b flex items-center space-x-2 overflow-x-auto text-[11px] shrink-0 ${
          isDark ? 'bg-slate-900/60 border-slate-800 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
        }`}
      >
        <button
          type="button"
          onClick={() => handleNavigate('https://bing.com')}
          className="flex items-center space-x-1 px-2 py-0.5 rounded hover:bg-slate-700/20 cursor-pointer"
        >
          <Globe className="w-3 h-3 text-blue-500" />
          <span>Bing</span>
        </button>
        <button
          type="button"
          onClick={() => handleNavigate('https://ai.studio')}
          className="flex items-center space-x-1 px-2 py-0.5 rounded hover:bg-slate-700/20 cursor-pointer"
        >
          <Star className="w-3 h-3 text-amber-500" />
          <span>Google AI Studio</span>
        </button>
        <button
          type="button"
          onClick={() => handleNavigate('https://en.wikipedia.org')}
          className="flex items-center space-x-1 px-2 py-0.5 rounded hover:bg-slate-700/20 cursor-pointer"
        >
          <Newspaper className="w-3 h-3 text-emerald-500" />
          <span>Wikipedia</span>
        </button>
      </div>

      {/* Webpage Content */}
      <div
        className={`flex-1 overflow-y-auto ${
          isDark ? 'bg-slate-950 text-slate-100' : 'bg-white text-slate-900'
        }`}
      >
        {/* HOMEPAGE VIEW */}
        {pageType === 'home' && (
          <div className="max-w-3xl mx-auto py-8 px-4 space-y-6">
            <div className="text-center space-y-2">
              <div className="text-3xl font-light tracking-tight">Microsoft Edge</div>
              <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                Explore the web, daily news, and weather
              </p>
            </div>

            {/* Big Search Box */}
            <div className="max-w-lg mx-auto">
              <div
                className={`flex items-center px-4 py-2.5 rounded-2xl border shadow-sm ${
                  isDark
                    ? 'bg-slate-900 border-slate-700'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <Search className="w-4 h-4 text-slate-400 mr-2.5 shrink-0" />
                <input
                  type="text"
                  placeholder="Search the web with Copilot"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleNavigate(e.currentTarget.value);
                  }}
                  className="w-full bg-transparent border-0 focus:outline-hidden text-xs sm:text-sm"
                />
              </div>
            </div>

            {/* Quick Cards: Weather & News */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4">
              <div
                className={`p-3.5 rounded-2xl border ${
                  isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-xs">Weather</span>
                  <CloudSun className="w-4 h-4 text-amber-500" />
                </div>
                <div className="text-xl font-bold">72°F</div>
                <div className="text-[11px] text-slate-400">Sunny • Seattle, WA</div>
              </div>

              <div
                className={`p-3.5 rounded-2xl border ${
                  isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-xs">Markets</span>
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                </div>
                <div className="text-xl font-bold text-emerald-500">+1.42%</div>
                <div className="text-[11px] text-slate-400">NASDAQ 19,450.20</div>
              </div>

              <div
                className={`p-3.5 rounded-2xl border ${
                  isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-xs">AI Updates</span>
                  <ExternalLink className="w-4 h-4 text-blue-500" />
                </div>
                <div className="text-xs font-semibold line-clamp-1">Gemini 2.5 Flash</div>
                <div className="text-[11px] text-slate-400">Integrated directly into Copilot</div>
              </div>
            </div>
          </div>
        )}

        {/* SEARCH RESULTS VIEW */}
        {pageType === 'search' && (
          <div className="max-w-2xl mx-auto py-6 px-4 space-y-4">
            <div className="text-xs text-slate-400">
              Showing search results for <strong className="text-blue-500">"{searchQuery}"</strong>
            </div>

            <div className="space-y-4 pt-2">
              <div
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="text-xs text-blue-500 hover:underline font-semibold cursor-pointer">
                  {searchQuery} - Official Documentation & Information
                </div>
                <div className="text-[11px] text-emerald-500 mb-1">https://example.org/{encodeURIComponent(searchQuery)}</div>
                <p className={`text-xs ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                  Comprehensive guide, specs, and details regarding {searchQuery} running in Windows 11 desktop.
                </p>
              </div>

              <div
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="text-xs text-blue-500 hover:underline font-semibold cursor-pointer">
                  Everything you need to know about {searchQuery}
                </div>
                <div className="text-[11px] text-emerald-500 mb-1">https://tech-news.com/article/{encodeURIComponent(searchQuery)}</div>
                <p className={`text-xs ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                  Recent breakthroughs, tutorials, benchmarks, and community discussions about {searchQuery}.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* WIKIPEDIA VIEW */}
        {pageType === 'wiki' && (
          <div className="max-w-2xl mx-auto py-6 px-4 space-y-4">
            <div className="border-b pb-2">
              <h1 className="text-xl font-serif font-bold">Wikipedia: The Free Encyclopedia</h1>
              <span className="text-[11px] text-slate-400">From Wikipedia, the free encyclopedia</span>
            </div>
            <p className="text-xs leading-relaxed">
              Windows 11 is a major release of the Windows NT operating system developed by Microsoft. Announced on June 24, 2021, and released on October 5, 2021, Windows 11 focuses on modern design, centered taskbar, rounded window corners, and mica acrylic translucent surfaces.
            </p>
            <div
              className={`p-3 rounded-lg border text-xs ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <h3 className="font-semibold mb-1">Key Features</h3>
              <ul className="list-disc pl-4 space-y-1 text-slate-400">
                <li>Centered taskbar with Start flyout</li>
                <li>Mica and Acrylic material design</li>
                <li>Direct integration with AI Copilot</li>
                <li>Multi-window multitasking and snap layouts</li>
              </ul>
            </div>
          </div>
        )}

        {/* AI STUDIO VIEW */}
        {pageType === 'aistudio' && (
          <div className="max-w-2xl mx-auto py-6 px-4 space-y-4">
            <div className="border-b pb-2">
              <h1 className="text-xl font-semibold text-blue-500">Google AI Studio</h1>
              <span className="text-[11px] text-slate-400">Prototyping and building with Gemini Models</span>
            </div>
            <p className="text-xs leading-relaxed">
              Google AI Studio is the fastest way to build with Gemini. Design, prototype, and build generative AI applications with multimodal reasoning, long context windows, and low latency streaming.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
