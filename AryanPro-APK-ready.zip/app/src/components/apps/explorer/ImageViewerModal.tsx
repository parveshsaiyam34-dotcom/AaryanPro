import React, { useState } from 'react';
import { X, ZoomIn, ZoomOut, RotateCw, Image as ImageIcon } from 'lucide-react';
import { FileItem, AppTheme } from '../../../types';

interface ImageViewerModalProps {
  item: FileItem | null;
  theme: AppTheme;
  onClose: () => void;
}

export const ImageViewerModal: React.FC<ImageViewerModalProps> = ({
  item,
  theme,
  onClose,
}) => {
  if (!item) return null;
  const isDark = theme === 'dark';

  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  // Fallback visual preview generated dynamically if no external URL
  const getGradientForImage = () => {
    if (item.name.toLowerCase().includes('dark')) {
      return 'from-slate-900 via-indigo-950 to-blue-900';
    }
    if (item.name.toLowerCase().includes('sunset')) {
      return 'from-amber-500 via-rose-500 to-indigo-800';
    }
    if (item.name.toLowerCase().includes('sky') || item.name.toLowerCase().includes('aurora')) {
      return 'from-emerald-500 via-teal-600 to-cyan-900';
    }
    return 'from-blue-600 via-indigo-500 to-sky-400';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 select-none animate-in fade-in-50 duration-200">
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-2xl h-[480px] rounded-2xl border shadow-2xl overflow-hidden flex flex-col transition-all ${
          isDark ? 'bg-slate-950 border-white/10 text-slate-100 shadow-black' : 'bg-slate-900 border-slate-700 text-white shadow-2xl'
        }`}
      >
        {/* Title Bar / Controls */}
        <div className="h-10 px-4 flex items-center justify-between border-b border-white/10 bg-black/30">
          <div className="flex items-center space-x-2 text-xs truncate">
            <ImageIcon className="w-4 h-4 text-purple-400" />
            <span className="font-medium truncate">{item.name}</span>
            <span className="text-slate-400 text-[11px] hidden sm:inline">({item.size || '2.4 MB'})</span>
          </div>

          <div className="flex items-center space-x-1">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 transition-colors cursor-pointer"
              title="Zoom out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-[11px] font-mono w-10 text-center text-slate-300">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(2.5, z + 0.25))}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 transition-colors cursor-pointer"
              title="Zoom in"
            >
              <ZoomIn className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setRotation((r) => (r + 90) % 360)}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 transition-colors cursor-pointer"
              title="Rotate 90°"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <div className="w-[1px] h-4 bg-white/20 mx-1" />

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-rose-600 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Viewport Canvas */}
        <div className="flex-1 flex items-center justify-center overflow-hidden p-6 bg-slate-950 relative">
          <div
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              transition: 'transform 0.2s cubic-bezier(0.2, 0.8, 0.2, 1)',
            }}
            className={`w-96 h-64 rounded-xl bg-gradient-to-tr ${getGradientForImage()} shadow-2xl flex flex-col items-center justify-center p-6 text-center text-white border border-white/20 select-none`}
          >
            <ImageIcon className="w-16 h-16 text-white/80 mb-3 drop-shadow-md" />
            <h3 className="font-semibold text-sm drop-shadow-md">{item.name}</h3>
            <p className="text-xs text-white/80 mt-1 drop-shadow-xs">Windows 11 High Definition Wallpaper</p>
            <div className="mt-4 px-2.5 py-1 rounded-full bg-black/30 backdrop-blur-md text-[10px] font-mono border border-white/20">
              3840 × 2160 • {item.size || '3.1 MB'}
            </div>
          </div>
        </div>

        {/* Status Bar */}
        <div className="h-7 px-4 flex items-center justify-between text-[10px] text-slate-400 border-t border-white/10 bg-black/40">
          <span>Photos - Windows 11</span>
          <span>Double-click or press Esc to exit</span>
        </div>
      </div>
    </div>
  );
};
