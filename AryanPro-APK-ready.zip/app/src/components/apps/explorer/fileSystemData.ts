import { FileItem } from '../../../types';

export interface DriveItem {
  id: string;
  name: string;
  letter: string;
  totalSpaceGB: number;
  freeSpaceGB: number;
  usedSpaceGB: number;
  type: 'local' | 'network' | 'usb';
}

export const SYSTEM_DRIVES: DriveItem[] = [
  {
    id: 'drive_c',
    name: 'Local Disk (C:)',
    letter: 'C:',
    totalSpaceGB: 256,
    freeSpaceGB: 158,
    usedSpaceGB: 98,
    type: 'local',
  },
  {
    id: 'drive_d',
    name: 'Local Disk (D:)',
    letter: 'D:',
    totalSpaceGB: 512,
    freeSpaceGB: 384,
    usedSpaceGB: 128,
    type: 'local',
  },
];

export const DEFAULT_FILE_SYSTEM: FileItem[] = [
  // Special Standard Folders
  {
    id: 'desktop',
    name: 'Desktop',
    type: 'folder',
    date: '9/3/2026 12:00 PM',
    category: 'desktop',
    parentId: 'thispc',
    location: 'C:\\Users\\Admin\\Desktop',
  },
  {
    id: 'documents',
    name: 'Documents',
    type: 'folder',
    date: '9/3/2026 11:30 AM',
    category: 'documents',
    parentId: 'thispc',
    location: 'C:\\Users\\Admin\\Documents',
  },
  {
    id: 'downloads',
    name: 'Downloads',
    type: 'folder',
    date: '9/2/2026 08:20 AM',
    category: 'downloads',
    parentId: 'thispc',
    location: 'C:\\Users\\Admin\\Downloads',
  },
  {
    id: 'pictures',
    name: 'Pictures',
    type: 'folder',
    date: '9/2/2026 05:00 PM',
    category: 'pictures',
    parentId: 'thispc',
    location: 'C:\\Users\\Admin\\Pictures',
  },

  // Files & Folders in Desktop
  {
    id: 'dt_1',
    name: 'Welcome-Readme.txt',
    type: 'file',
    size: '2 KB',
    date: '9/3/2026 12:00 PM',
    extension: 'txt',
    category: 'desktop',
    parentId: 'desktop',
    location: 'C:\\Users\\Admin\\Desktop',
    content: `Windows 11 Pro Desktop Environment
===================================
Welcome to your fully upgraded Windows 11 desktop experience!

Key Features:
- Fully functional File Explorer with Quick Access, This PC, and drives
- Double-click navigation into any folder
- Create, rename, and delete files & folders
- Breadcrumb address bar with direct path navigation
- Back, Forward, Up, and Refresh navigation buttons
- Real-time search with instant filtering
- Details, Medium Grid, and Large Icon view modes
- Sort by Name, Date, Type, or Size
- Multi-item selection and rich right-click context menus
- AI Copilot with Gemini integration
- Notepad, Calculator, Microsoft Edge, and Settings`,
  },
  {
    id: 'dt_2',
    name: 'Quick-Notes.txt',
    type: 'file',
    size: '1 KB',
    date: '9/3/2026 10:15 AM',
    extension: 'txt',
    category: 'desktop',
    parentId: 'desktop',
    location: 'C:\\Users\\Admin\\Desktop',
    content: `Quick Reminders:
- Review quarterly UI specifications
- Check container health on port 3000
- Test File Explorer file operations: create, rename, delete
- Try dark & light theme switching in Settings`,
  },
  {
    id: 'dt_3',
    name: 'Project Alpha',
    type: 'folder',
    date: '9/2/2026 03:00 PM',
    category: 'desktop',
    parentId: 'desktop',
    location: 'C:\\Users\\Admin\\Desktop\\Project Alpha',
  },
  {
    id: 'dt_3_1',
    name: 'alpha-specs.txt',
    type: 'file',
    size: '4 KB',
    date: '9/2/2026 03:20 PM',
    extension: 'txt',
    category: 'desktop',
    parentId: 'dt_3',
    location: 'C:\\Users\\Admin\\Desktop\\Project Alpha',
    content: `Project Alpha Technical Specifications:
- High performance responsive layout
- Acrylic glassmorphic UI matching Fluent design language
- Resizable windows with 8-way drag bounds
- Local storage persistent file system`,
  },

  // Files & Subfolders in Documents
  {
    id: 'doc_sub_work',
    name: 'Work',
    type: 'folder',
    date: '9/3/2026 11:20 AM',
    category: 'documents',
    parentId: 'documents',
    location: 'C:\\Users\\Admin\\Documents\\Work',
  },
  {
    id: 'doc_sub_personal',
    name: 'Personal',
    type: 'folder',
    date: '9/1/2026 04:00 PM',
    category: 'documents',
    parentId: 'documents',
    location: 'C:\\Users\\Admin\\Documents\\Personal',
  },
  {
    id: 'doc_1',
    name: 'Meeting-Notes.txt',
    type: 'file',
    size: '4 KB',
    date: '9/3/2026 11:30 AM',
    extension: 'txt',
    category: 'documents',
    parentId: 'documents',
    location: 'C:\\Users\\Admin\\Documents',
    content: `Meeting with Product & Engineering:
Topic: Windows 11 System Enhancements

Discussion Items:
1. File Explorer sidebar navigation: Quick Access, Desktop, Documents, Downloads, Pictures, and This PC.
2. File management capabilities: create new folders & text documents, rename inline, delete with undo.
3. Address bar breadcrumbs with direct clicking to parent directories.
4. Details and Grid view modes with sorting headers.
5. Integration with Notepad for instant editing of .txt files.`,
  },
  {
    id: 'doc_2',
    name: 'Quarterly-Report.docx',
    type: 'file',
    size: '124 KB',
    date: '9/2/2026 03:15 PM',
    extension: 'docx',
    category: 'documents',
    parentId: 'documents',
    location: 'C:\\Users\\Admin\\Documents',
  },
  {
    id: 'doc_3',
    name: 'Budget-Q3.xlsx',
    type: 'file',
    size: '58 KB',
    date: '9/2/2026 02:40 PM',
    extension: 'xlsx',
    category: 'documents',
    parentId: 'documents',
  },
  {
    id: 'doc_4',
    name: 'Client-Proposal.docx',
    type: 'file',
    size: '88 KB',
    date: '9/1/2026 09:10 AM',
    extension: 'docx',
    category: 'documents',
    parentId: 'doc_sub_work',
    location: 'C:\\Users\\Admin\\Documents\\Work',
  },
  {
    id: 'doc_5',
    name: 'Project-Roadmap-2026.txt',
    type: 'file',
    size: '3 KB',
    date: '9/1/2026 10:00 AM',
    extension: 'txt',
    category: 'documents',
    parentId: 'doc_sub_work',
    location: 'C:\\Users\\Admin\\Documents\\Work',
    content: `2026 Product Roadmap
====================
Q1: Core Window Management & Desktop Shell
Q2: Multi-Window Taskbar & Live Clock / Flyouts
Q3: Complete Windows 11 File Explorer Upgrade
Q4: Gemini AI Copilot Integration & Productivity Tools`,
  },
  {
    id: 'doc_6',
    name: 'Shopping-List.txt',
    type: 'file',
    size: '1 KB',
    date: '8/30/2026 06:15 PM',
    extension: 'txt',
    category: 'documents',
    parentId: 'doc_sub_personal',
    location: 'C:\\Users\\Admin\\Documents\\Personal',
    content: `- Mechanical keyboard (low profile)
- 4K IPS monitor with USB-C display port
- Ergonomic mouse
- Desk cable management tray`,
  },

  // Files & Subfolders in Downloads
  {
    id: 'dl_1',
    name: 'VSCodeSetup-x64.exe',
    type: 'file',
    size: '88.4 MB',
    date: '9/1/2026 08:20 AM',
    extension: 'exe',
    category: 'downloads',
    parentId: 'downloads',
    location: 'C:\\Users\\Admin\\Downloads',
  },
  {
    id: 'dl_2',
    name: 'windows-11-wallpaper.png',
    type: 'file',
    size: '2.4 MB',
    date: '8/30/2026 02:40 PM',
    extension: 'png',
    category: 'downloads',
    parentId: 'downloads',
    location: 'C:\\Users\\Admin\\Downloads',
  },
  {
    id: 'dl_3',
    name: 'invoice_september.pdf',
    type: 'file',
    size: '340 KB',
    date: '9/2/2026 11:05 AM',
    extension: 'pdf',
    category: 'downloads',
    parentId: 'downloads',
    location: 'C:\\Users\\Admin\\Downloads',
  },
  {
    id: 'dl_4',
    name: 'system-logs.log',
    type: 'file',
    size: '14 KB',
    date: '9/3/2026 08:00 AM',
    extension: 'log',
    category: 'downloads',
    parentId: 'downloads',
    location: 'C:\\Users\\Admin\\Downloads',
    content: `[2026-09-03 08:00:01] System boot initialized.
[2026-09-03 08:00:02] Desktop window manager loaded.
[2026-09-03 08:00:03] Taskbar service running on Port 3000.
[2026-09-03 08:00:04] AI Copilot service connected to Gemini API.
[2026-09-03 08:00:05] File system storage initialized successfully.`,
  },

  // Files & Subfolders in Pictures
  {
    id: 'pic_sub_wallpapers',
    name: 'Wallpapers',
    type: 'folder',
    date: '9/2/2026 04:50 PM',
    category: 'pictures',
    parentId: 'pictures',
    location: 'C:\\Users\\Admin\\Pictures\\Wallpapers',
  },
  {
    id: 'pic_sub_screenshots',
    name: 'Screenshots',
    type: 'folder',
    date: '9/1/2026 01:20 PM',
    category: 'pictures',
    parentId: 'pictures',
    location: 'C:\\Users\\Admin\\Pictures\\Screenshots',
  },
  {
    id: 'pic_1',
    name: 'Bloom-Wallpaper-HD.png',
    type: 'file',
    size: '3.1 MB',
    date: '9/2/2026 05:00 PM',
    extension: 'png',
    category: 'pictures',
    parentId: 'pictures',
    location: 'C:\\Users\\Admin\\Pictures',
  },
  {
    id: 'pic_2',
    name: 'Sunset-Skyline.jpg',
    type: 'file',
    size: '1.8 MB',
    date: '8/25/2026 07:12 PM',
    extension: 'jpg',
    category: 'pictures',
    parentId: 'pictures',
    location: 'C:\\Users\\Admin\\Pictures',
  },
  {
    id: 'pic_3',
    name: 'Bloom-Dark-Theme.png',
    type: 'file',
    size: '2.8 MB',
    date: '9/2/2026 04:55 PM',
    extension: 'png',
    category: 'pictures',
    parentId: 'pic_sub_wallpapers',
    location: 'C:\\Users\\Admin\\Pictures\\Wallpapers',
  },
  {
    id: 'pic_4',
    name: 'Desktop-Preview.png',
    type: 'file',
    size: '950 KB',
    date: '9/1/2026 01:25 PM',
    extension: 'png',
    category: 'pictures',
    parentId: 'pic_sub_screenshots',
    location: 'C:\\Users\\Admin\\Pictures\\Screenshots',
  },

  // C: Drive Root Folders
  {
    id: 'c_windows',
    name: 'Windows',
    type: 'folder',
    date: '9/1/2026 10:24 AM',
    category: 'drive',
    parentId: 'drive_c',
    location: 'C:\\Windows',
  },
  {
    id: 'c_program_files',
    name: 'Program Files',
    type: 'folder',
    date: '9/1/2026 10:24 AM',
    category: 'drive',
    parentId: 'drive_c',
    location: 'C:\\Program Files',
  },
  {
    id: 'c_users',
    name: 'Users',
    type: 'folder',
    date: '9/2/2026 04:12 PM',
    category: 'drive',
    parentId: 'drive_c',
    location: 'C:\\Users',
  },
  {
    id: 'c_win_sys32',
    name: 'System32',
    type: 'folder',
    date: '9/1/2026 10:24 AM',
    category: 'drive',
    parentId: 'c_windows',
    location: 'C:\\Windows\\System32',
  },
  {
    id: 'c_win_fonts',
    name: 'Fonts',
    type: 'folder',
    date: '9/1/2026 10:24 AM',
    category: 'drive',
    parentId: 'c_windows',
    location: 'C:\\Windows\\Fonts',
  },
  {
    id: 'c_user_admin',
    name: 'Admin',
    type: 'folder',
    date: '9/2/2026 04:12 PM',
    category: 'drive',
    parentId: 'c_users',
    location: 'C:\\Users\\Admin',
  },
  {
    id: 'c_user_public',
    name: 'Public',
    type: 'folder',
    date: '9/2/2026 04:12 PM',
    category: 'drive',
    parentId: 'c_users',
    location: 'C:\\Users\\Public',
  },

  // D: Drive Root Folders
  {
    id: 'd_backups',
    name: 'Backups',
    type: 'folder',
    date: '8/28/2026 09:30 AM',
    category: 'drive',
    parentId: 'drive_d',
    location: 'D:\\Backups',
  },
  {
    id: 'd_projects',
    name: 'Development',
    type: 'folder',
    date: '9/2/2026 11:00 AM',
    category: 'drive',
    parentId: 'drive_d',
    location: 'D:\\Development',
  },
  {
    id: 'd_backup_file',
    name: 'System-Image-2026.bak',
    type: 'file',
    size: '12.4 GB',
    date: '8/28/2026 10:00 AM',
    extension: 'bak',
    category: 'drive',
    parentId: 'd_backups',
    location: 'D:\\Backups',
  },
  {
    id: 'd_dev_readme',
    name: 'Dev-Setup.txt',
    type: 'file',
    size: '2 KB',
    date: '9/2/2026 11:15 AM',
    extension: 'txt',
    category: 'drive',
    parentId: 'd_projects',
    location: 'D:\\Development',
    content: `Local Development Environment
==============================
Node.js: v20 LTS
Frontend: React 18 + Vite + Tailwind CSS
Icons: Lucide React
AI Service: Google GenAI SDK (Gemini Flash)`,
  },
];

// Map of folder identifiers to friendly names and breadcrumb paths
export interface FolderMeta {
  id: string;
  name: string;
  path: string;
  parentId: string | null;
  iconType: 'quickaccess' | 'thispc' | 'drive' | 'folder' | 'desktop' | 'documents' | 'downloads' | 'pictures' | 'trash';
}

export const KNOWN_FOLDERS: Record<string, FolderMeta> = {
  thispc: {
    id: 'thispc',
    name: 'This PC',
    path: 'This PC',
    parentId: null,
    iconType: 'thispc',
  },
  desktop: {
    id: 'desktop',
    name: 'Desktop',
    path: 'This PC > Desktop',
    parentId: 'thispc',
    iconType: 'desktop',
  },
  documents: {
    id: 'documents',
    name: 'Documents',
    path: 'This PC > Documents',
    parentId: 'thispc',
    iconType: 'documents',
  },
  downloads: {
    id: 'downloads',
    name: 'Downloads',
    path: 'This PC > Downloads',
    parentId: 'thispc',
    iconType: 'downloads',
  },
  pictures: {
    id: 'pictures',
    name: 'Pictures',
    path: 'This PC > Pictures',
    parentId: 'thispc',
    iconType: 'pictures',
  },
  drive_c: {
    id: 'drive_c',
    name: 'Local Disk (C:)',
    path: 'This PC > Local Disk (C:)',
    parentId: 'thispc',
    iconType: 'drive',
  },
  drive_d: {
    id: 'drive_d',
    name: 'Local Disk (D:)',
    path: 'This PC > Local Disk (D:)',
    parentId: 'thispc',
    iconType: 'drive',
  },
};
