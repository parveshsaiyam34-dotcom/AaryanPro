import React from 'react';
import { X, Folder, FileText, Image, FileCode, HardDrive } from 'lucide-react';
import { FileItem, AppTheme } from '../../../types';

interface FilePropertiesModalProps {
  item: FileItem | null;
  theme: AppTheme;
  onClose: () => void;
}

export const FilePropertiesModal: React.FC<FilePropertiesModalProps> = ({
  item,
  theme,
  onClose,
}) => {
  if (!item) return null;
  const isDark = theme === 'dark';

  const getIcon = () => {
    if (item.type === 'folder') {
      return <Folder className="w-10 h-10 text-amber-500 fill-amber-500/20" />;
    }
    if (item.extension === 'png' || item.extension === 'jpg') {
      return <Image className="w-10 h-10 text-purple-500" />;
    }
    if (item.extension === 'ts' || item.extension === 'js') {
      return <FileCode className="w-10 h-10 text-emerald-500" />;
    }
    if (item.extension === 'bak') {
      return <HardDrive className="w-10 h-10 text-blue-500" />;
    }
    return <FileText className="w-10 h-10 text-blue-500" />;
  };

  const getTypeName = () => {
    if (item.type === 'folder') return 'File folder';
    if (item.extension === 'txt') return 'Text Document (.txt)';
    if (item.extension === 'png') return 'PNG Image (.png)';
    if (item.extension === 'jpg') return 'JPEG Image (.jpg)';
    if (item.extension === 'docx') return 'Microsoft Word Document (.docx)';
    if (item.extension === 'xlsx') return 'Microsoft Excel Worksheet (.xlsx)';
    if (item.extension === 'pdf') return 'PDF Document (.pdf)';
    if (item.extension === 'exe') return 'Application (.exe)';
    if (item.extension === 'log') return 'Log File (.log)';
    if (item.extension === 'bak') return 'Backup File (.bak)';
    return `${item.extension?.toUpperCase() || 'Binary'} File`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 select-none">
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-sm rounded-xl border shadow-2xl overflow-hidden flex flex-col transition-all text-xs ${
          isDark ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
        }`}
      >
        {/* Title Bar */}
        <div
          className={`h-9 px-3 flex items-center justify-between border-b ${
            isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
          }`}
        >
          <span className="font-medium truncate">{item.name} Properties</span>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-sm hover:bg-rose-500 hover:text-white transition-colors cursor-pointer text-slate-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-4">
          {/* Header Info */}
          <div className="flex items-center space-x-3 pb-3 border-b border-slate-700/30">
            <div className="p-2 rounded-lg bg-slate-500/10 shrink-0">
              {getIcon()}
            </div>
            <div className="flex-1 truncate">
              <div className="font-semibold text-sm truncate">{item.name}</div>
              <div className="text-slate-400 text-[11px]">{getTypeName()}</div>
            </div>
          </div>

          {/* Details Table */}
          <div className="space-y-2 text-[11px]">
            <div className="grid grid-cols-3 gap-2">
              <span className="text-slate-400">Type:</span>
              <span className="col-span-2 font-medium">{getTypeName()}</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <span className="text-slate-400">Location:</span>
              <span className="col-span-2 font-mono text-[10px] break-all text-slate-300">
                {item.location || 'C:\\Users\\Admin'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <span className="text-slate-400">Size:</span>
              <span className="col-span-2 font-medium">{item.size || '0 KB'}</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <span className="text-slate-400">Modified:</span>
              <span className="col-span-2 font-medium">{item.date}</span>
            </div>

            {item.type === 'file' && (
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Opens with:</span>
                <span className="col-span-2 font-medium text-blue-400">
                  {item.extension === 'txt' || item.extension === 'log' ? 'Notepad' : 'Default Application'}
                </span>
              </div>
            )}
          </div>

          {/* Attributes */}
          <div className="pt-2 border-t border-slate-700/30 flex items-center space-x-6 text-[11px] text-slate-400">
            <label className="flex items-center space-x-1.5 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded text-blue-600 focus:ring-0" />
              <span>Read-only</span>
            </label>
            <label className="flex items-center space-x-1.5 cursor-pointer">
              <input type="checkbox" className="rounded text-blue-600 focus:ring-0" />
              <span>Hidden</span>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div
          className={`px-4 py-2.5 border-t flex justify-end space-x-2 ${
            isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-medium cursor-pointer transition-colors"
          >
            OK
          </button>
          <button
            type="button"
            onClick={onClose}
            className={`px-3 py-1.5 rounded-md border transition-colors cursor-pointer ${
              isDark ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'
            }`}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
