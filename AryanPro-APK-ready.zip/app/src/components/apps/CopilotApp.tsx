import React, { useState, useRef, useEffect } from 'react';
import Markdown from 'react-markdown';
import {
  Sparkles,
  SendHorizontal,
  RotateCcw,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Trash2,
  AlertCircle,
  MessageSquare,
  ChevronRight,
  Info,
  Lightbulb,
  Code2,
  Compass,
  PenTool,
  Loader2,
} from 'lucide-react';
import { ChatMessage, AppTheme } from '../../types';

interface CopilotAppProps {
  theme: AppTheme;
}

const QUICK_STARTERS = [
  {
    icon: Lightbulb,
    title: 'Explain concepts',
    prompt: 'Can you explain quantum computing simply in 3 bullet points?',
  },
  {
    icon: Code2,
    title: 'Code generator',
    prompt: 'Write a TypeScript function to debounce an API call with cancel support.',
  },
  {
    icon: Sparkles,
    title: 'Windows tips',
    prompt: 'What are the top 5 productivity keyboard shortcuts in Windows 11?',
  },
  {
    icon: PenTool,
    title: 'Creative writing',
    prompt: 'Draft an email announcing a new Windows 11 Pro desktop release to the team.',
  },
];

export const CopilotApp: React.FC<CopilotAppProps> = ({ theme }) => {
  const isDark = theme === 'dark';

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'welcome-1',
        role: 'assistant',
        text: "Hi there! I'm your **Windows 11 Copilot Assistant**, powered by Google Gemini.\n\nAsk me anything, draft code, brainstorm ideas, or ask for help navigating Windows 11. What would you like to explore?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Web Speech API Voice Recognition setup
  useEffect(() => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRec) {
      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';
      rec.onresult = (e: any) => {
        const text = e.results[0][0].transcript;
        if (text) {
          setInputText((prev) => (prev ? `${prev} ${text}` : text));
        }
        setIsListening(false);
      };
      rec.onerror = () => setIsListening(false);
      rec.onend = () => setIsListening(false);
      recognitionRef.current = rec;
    }
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const handleToggleVoice = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch {
        setIsListening(false);
      }
    }
  };

  const handleSendMessage = async (textToSend: string, isRetry = false) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isLoading) return;

    let updatedList = messages;
    if (!isRetry) {
      const userMessage: ChatMessage = {
        id: `user-${Date.now()}`,
        role: 'user',
        text: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      updatedList = [...messages, userMessage];
      setMessages(updatedList);
    }

    setInputText('');
    setIsLoading(true);

    try {
      const conversationPayload = updatedList
        .filter((m) => !m.error)
        .map((m) => ({
          role: m.role,
          text: m.text,
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: conversationPayload }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to get a response.');
      }

      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        text: data.text || 'No response generated.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages([...updatedList, aiMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        text:
          err.message ||
          'Connection notice: The AI model is momentarily under high demand. Please click retry.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        error: true,
      };
      setMessages([...updatedList, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = (failedId: string) => {
    const filtered = messages.filter((m) => m.id !== failedId);
    const lastUser = [...filtered].reverse().find((m) => m.role === 'user');
    if (!lastUser) return;
    setMessages(filtered);
    handleSendMessage(lastUser.text, true);
  };

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // ignore
    }
  };

  const handleSpeak = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleClear = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        text: "Conversation cleared. I'm ready for your next question or task!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div
      className={`h-full w-full flex flex-col select-auto transition-colors ${
        isDark ? 'bg-slate-900 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Sub-header Toolbar */}
      <div
        className={`px-4 py-2 border-b flex items-center justify-between text-xs transition-colors shrink-0 ${
          isDark
            ? 'bg-slate-950/60 border-slate-800 text-slate-300'
            : 'bg-white/80 border-slate-200 text-slate-600'
        }`}
      >
        <div className="flex items-center space-x-2">
          <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-sky-400 via-indigo-500 to-fuchsia-500 flex items-center justify-center text-white shadow-xs">
            <Sparkles className="w-3 h-3" />
          </div>
          <span className="font-semibold text-xs tracking-tight">Copilot for Windows</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-blue-500/10 text-blue-500 border border-blue-500/20">
            Gemini Flash
          </span>
        </div>

        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={handleClear}
            className={`flex items-center space-x-1 px-2 py-1 rounded-md transition-colors cursor-pointer text-[11px] font-medium ${
              isDark
                ? 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
                : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
            title="Clear Chat"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* Messages List Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((m) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={m.id}
              className={`flex ${isUser ? 'justify-end' : 'justify-start'} animate-in fade-in-50 duration-200`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-xs text-[13.5px] leading-relaxed ${
                  isUser
                    ? 'bg-blue-600 text-white rounded-br-xs'
                    : m.error
                    ? isDark
                      ? 'bg-rose-950/40 border border-rose-800/80 text-rose-200 rounded-bl-xs'
                      : 'bg-rose-50 border border-rose-200 text-rose-900 rounded-bl-xs'
                    : isDark
                    ? 'bg-slate-800/90 border border-slate-700/80 text-slate-100 rounded-bl-xs'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-bl-xs'
                }`}
              >
                {m.error && (
                  <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-rose-500/20 text-xs">
                    <div className="flex items-center space-x-1 font-semibold text-rose-500">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Service Notice</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRetry(m.id)}
                      className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-rose-600/10 hover:bg-rose-600/20 text-rose-600 text-[11px] font-medium transition-colors"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Retry</span>
                    </button>
                  </div>
                )}

                {isUser ? (
                  <p className="whitespace-pre-wrap break-words">{m.text}</p>
                ) : (
                  <div
                    className={`markdown-body space-y-2 [&_pre]:bg-slate-950 [&_pre]:text-slate-100 [&_pre]:p-2.5 [&_pre]:rounded-lg [&_pre]:overflow-x-auto [&_code]:font-mono [&_code]:text-xs [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded ${
                      isDark ? '[&_code]:bg-slate-950 [&_code]:text-sky-300' : '[&_code]:bg-slate-100 [&_code]:text-blue-700'
                    }`}
                  >
                    <Markdown>{m.text}</Markdown>
                  </div>
                )}

                <div
                  className={`flex items-center justify-between mt-2 pt-1 text-[10px] select-none ${
                    isUser ? 'text-blue-100' : isDark ? 'text-slate-400' : 'text-slate-500'
                  }`}
                >
                  <span>{m.timestamp}</span>
                  {!isUser && !m.error && (
                    <div className="flex items-center space-x-1">
                      <button
                        type="button"
                        onClick={() => handleCopy(m.id, m.text)}
                        className="p-1 rounded hover:bg-slate-700/20 transition-colors"
                        title="Copy text"
                      >
                        {copiedId === m.id ? (
                          <Check className="w-3 h-3 text-emerald-500" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                      {'speechSynthesis' in window && (
                        <button
                          type="button"
                          onClick={() => handleSpeak(m.id, m.text)}
                          className="p-1 rounded hover:bg-slate-700/20 transition-colors"
                          title="Read aloud"
                        >
                          {speakingId === m.id ? (
                            <VolumeX className="w-3 h-3 text-blue-500" />
                          ) : (
                            <Volume2 className="w-3 h-3" />
                          )}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center space-x-2 text-xs py-2 px-3 text-slate-500">
            <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
            <span>Copilot is generating a response...</span>
          </div>
        )}

        {messages.length <= 1 && !isLoading && (
          <div className="pt-4 pb-2">
            <p className={`text-xs font-semibold mb-2.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Suggested Prompts:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {QUICK_STARTERS.map((s, idx) => {
                const Icon = s.icon;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSendMessage(s.prompt)}
                    className={`flex items-start text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isDark
                        ? 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 hover:border-blue-500/50'
                        : 'bg-white border-slate-200 hover:bg-blue-50/50 hover:border-blue-300'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-blue-500 mr-2 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs font-medium">{s.title}</div>
                      <div className={`text-[11px] line-clamp-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                        {s.prompt}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form Bar */}
      <div
        className={`p-3 border-t transition-colors shrink-0 ${
          isDark ? 'bg-slate-950/70 border-slate-800' : 'bg-white/90 border-slate-200'
        }`}
      >
        <div
          className={`flex items-end rounded-2xl border px-3 py-1.5 transition-colors ${
            isDark
              ? 'bg-slate-900 border-slate-700 focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500/30'
              : 'bg-slate-100 border-slate-200 focus-within:bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-100'
          }`}
        >
          <textarea
            ref={textareaRef}
            rows={1}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(inputText);
              }
            }}
            placeholder={isListening ? 'Listening... speak now' : 'Ask Copilot anything...'}
            disabled={isLoading}
            className={`flex-1 resize-none bg-transparent border-0 text-xs sm:text-sm focus:outline-hidden py-1 max-h-24 ${
              isDark ? 'text-slate-100 placeholder-slate-400' : 'text-slate-900 placeholder-slate-400'
            }`}
          />

          {('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) && (
            <button
              type="button"
              onClick={handleToggleVoice}
              className={`p-1.5 rounded-full transition-colors ml-1 ${
                isListening
                  ? 'text-rose-500 bg-rose-100 dark:bg-rose-950/60 animate-pulse'
                  : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
              }`}
              title={isListening ? 'Stop recording' : 'Voice input'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          )}

          <button
            type="button"
            onClick={() => handleSendMessage(inputText)}
            disabled={!inputText.trim() || isLoading}
            className={`p-1.5 rounded-full ml-1 transition-all ${
              inputText.trim() && !isLoading
                ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer shadow-xs'
                : 'text-slate-400 dark:text-slate-600 cursor-not-allowed'
            }`}
            title="Send"
          >
            <SendHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
