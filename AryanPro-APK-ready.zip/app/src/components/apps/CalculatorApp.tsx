import React, { useState, useEffect } from 'react';
import { Delete, History, RotateCcw } from 'lucide-react';
import { AppTheme } from '../../types';

interface CalculatorAppProps {
  theme: AppTheme;
}

export const CalculatorApp: React.FC<CalculatorAppProps> = ({ theme }) => {
  const isDark = theme === 'dark';

  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [prevVal, setPrevVal] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [memory, setMemory] = useState<number>(0);

  // Keyboard handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        inputDigit(e.key);
      } else if (e.key === '.') {
        inputDot();
      } else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
        performOperation(e.key === '*' ? '×' : e.key === '/' ? '÷' : e.key);
      } else if (e.key === 'Enter' || e.key === '=') {
        performEquals();
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        clearAll();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [display, prevVal, operator, waitingForOperand]);

  const inputDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const inputDot = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const clearAll = () => {
    setDisplay('0');
    setEquation('');
    setPrevVal(null);
    setOperator(null);
    setWaitingForOperand(false);
  };

  const clearEntry = () => {
    setDisplay('0');
  };

  const handleBackspace = () => {
    if (waitingForOperand) return;
    if (display.length === 1 || (display.length === 2 && display.startsWith('-'))) {
      setDisplay('0');
    } else {
      setDisplay(display.slice(0, -1));
    }
  };

  const performOperation = (nextOperator: string) => {
    const inputValue = parseFloat(display);

    if (prevVal === null) {
      setPrevVal(inputValue);
      setEquation(`${inputValue} ${nextOperator}`);
    } else if (operator) {
      const currentValue = prevVal || 0;
      const computed = compute(currentValue, inputValue, operator);
      setPrevVal(computed);
      setDisplay(String(computed));
      setEquation(`${computed} ${nextOperator}`);
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  };

  const compute = (first: number, second: number, op: string): number => {
    switch (op) {
      case '+':
        return first + second;
      case '-':
        return first - second;
      case '×':
        return first * second;
      case '÷':
        return second === 0 ? 0 : first / second;
      default:
        return second;
    }
  };

  const performEquals = () => {
    const inputValue = parseFloat(display);
    if (operator && prevVal !== null) {
      const result = compute(prevVal, inputValue, operator);
      setEquation(`${prevVal} ${operator} ${inputValue} =`);
      setDisplay(String(result));
      setPrevVal(null);
      setOperator(null);
      setWaitingForOperand(true);
    }
  };

  const handlePercent = () => {
    const val = parseFloat(display);
    setDisplay(String(val / 100));
  };

  const handleReciprocal = () => {
    const val = parseFloat(display);
    if (val !== 0) setDisplay(String(1 / val));
  };

  const handleSquare = () => {
    const val = parseFloat(display);
    setDisplay(String(val * val));
  };

  const handleSquareRoot = () => {
    const val = parseFloat(display);
    if (val >= 0) setDisplay(String(Math.sqrt(val)));
  };

  const handleToggleSign = () => {
    const val = parseFloat(display);
    setDisplay(String(-val));
  };

  return (
    <div
      className={`h-full w-full flex flex-col select-none text-xs p-3 transition-colors ${
        isDark ? 'bg-slate-900 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Top Standard Header */}
      <div className="flex items-center justify-between pb-1 text-slate-400">
        <span className="font-semibold text-xs text-slate-200">Standard</span>
        <button type="button" className="p-1 hover:text-slate-100 transition-colors">
          <History className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Screen Readout */}
      <div className="flex flex-col items-end justify-end py-3 px-2 min-h-[90px]">
        <div className="text-xs text-slate-400 font-mono tracking-wide h-4">
          {equation}
        </div>
        <div className="text-3xl sm:text-4xl font-semibold tracking-tight truncate max-w-full font-sans mt-1">
          {display}
        </div>
      </div>

      {/* Memory Bar */}
      <div className="flex items-center justify-between text-[11px] font-medium py-1 px-1 text-slate-400">
        <button
          type="button"
          onClick={() => setMemory(0)}
          className="hover:text-slate-200 px-1.5 py-0.5 rounded"
        >
          MC
        </button>
        <button
          type="button"
          onClick={() => setDisplay(String(memory))}
          className="hover:text-slate-200 px-1.5 py-0.5 rounded"
        >
          MR
        </button>
        <button
          type="button"
          onClick={() => setMemory(memory + parseFloat(display))}
          className="hover:text-slate-200 px-1.5 py-0.5 rounded"
        >
          M+
        </button>
        <button
          type="button"
          onClick={() => setMemory(memory - parseFloat(display))}
          className="hover:text-slate-200 px-1.5 py-0.5 rounded"
        >
          M-
        </button>
        <button
          type="button"
          onClick={() => setMemory(parseFloat(display))}
          className="hover:text-slate-200 px-1.5 py-0.5 rounded"
        >
          MS
        </button>
      </div>

      {/* Grid Keypad */}
      <div className="flex-1 grid grid-cols-4 gap-1.5 pt-2">
        {/* Row 1 */}
        <button
          type="button"
          onClick={handlePercent}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          %
        </button>
        <button
          type="button"
          onClick={clearEntry}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          CE
        </button>
        <button
          type="button"
          onClick={clearAll}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          C
        </button>
        <button
          type="button"
          onClick={handleBackspace}
          className={`rounded-lg flex items-center justify-center font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          <Delete className="w-4 h-4" />
        </button>

        {/* Row 2 */}
        <button
          type="button"
          onClick={handleReciprocal}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          1/x
        </button>
        <button
          type="button"
          onClick={handleSquare}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          x²
        </button>
        <button
          type="button"
          onClick={handleSquareRoot}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          √x
        </button>
        <button
          type="button"
          onClick={() => performOperation('÷')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800 text-blue-400 hover:bg-slate-700' : 'bg-white text-blue-600 hover:bg-slate-100 shadow-xs'
          }`}
        >
          ÷
        </button>

        {/* Row 3 */}
        <button
          type="button"
          onClick={() => inputDigit('7')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          7
        </button>
        <button
          type="button"
          onClick={() => inputDigit('8')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          8
        </button>
        <button
          type="button"
          onClick={() => inputDigit('9')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          9
        </button>
        <button
          type="button"
          onClick={() => performOperation('×')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800 text-blue-400 hover:bg-slate-700' : 'bg-white text-blue-600 hover:bg-slate-100 shadow-xs'
          }`}
        >
          ×
        </button>

        {/* Row 4 */}
        <button
          type="button"
          onClick={() => inputDigit('4')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          4
        </button>
        <button
          type="button"
          onClick={() => inputDigit('5')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          5
        </button>
        <button
          type="button"
          onClick={() => inputDigit('6')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          6
        </button>
        <button
          type="button"
          onClick={() => performOperation('-')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800 text-blue-400 hover:bg-slate-700' : 'bg-white text-blue-600 hover:bg-slate-100 shadow-xs'
          }`}
        >
          -
        </button>

        {/* Row 5 */}
        <button
          type="button"
          onClick={() => inputDigit('1')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          1
        </button>
        <button
          type="button"
          onClick={() => inputDigit('2')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          2
        </button>
        <button
          type="button"
          onClick={() => inputDigit('3')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          3
        </button>
        <button
          type="button"
          onClick={() => performOperation('+')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800 text-blue-400 hover:bg-slate-700' : 'bg-white text-blue-600 hover:bg-slate-100 shadow-xs'
          }`}
        >
          +
        </button>

        {/* Row 6 */}
        <button
          type="button"
          onClick={handleToggleSign}
          className={`rounded-lg font-medium transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          +/-
        </button>
        <button
          type="button"
          onClick={() => inputDigit('0')}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          0
        </button>
        <button
          type="button"
          onClick={inputDot}
          className={`rounded-lg font-semibold text-sm transition-all ${
            isDark ? 'bg-slate-800/60 hover:bg-slate-700' : 'bg-white hover:bg-slate-100 shadow-xs'
          }`}
        >
          .
        </button>
        <button
          type="button"
          onClick={performEquals}
          className="rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-md transition-all active:scale-95"
        >
          =
        </button>
      </div>
    </div>
  );
};
