import React, { useState } from 'react';
import {
  Layers,
  Search,
  SlidersHorizontal,
  Globe,
  FileText,
  Calculator,
  Bot,
  Sliders,
  Image,
  Terminal,
  Music,
  Trash2,
  Check,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface AppsSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

interface InstalledApp {
  id: string;
  name: string;
  publisher: string;
  size: string;
  version: string;
  icon: React.ReactNode;
  canUninstall: boolean;
}

export const AppsSection: React.FC<AppsSectionProps> = ({ isDark }) => {
  const [searchFilter, setSearchFilter] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'size'>('name');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const [apps, setApps] = useState<InstalledApp[]>([
    {
      id: 'edge',
      name: 'Microsoft Edge',
      publisher: 'Microsoft Corporation',
      size: '142 MB',
      version: '128.0.2739.42',
      icon: <Globe className="w-5 h-5 text-blue-500" />,
      canUninstall: false,
    },
    {
      id: 'copilot',
      name: 'Microsoft Copilot (AI Companion)',
      publisher: 'Google Gemini Flash Engine',
      size: '18.4 MB',
      version: '2.1.0',
      icon: <Bot className="w-5 h-5 text-indigo-500" />,
      canUninstall: false,
    },
    {
      id: 'notepad',
      name: 'Windows Notepad',
      publisher: 'Microsoft Corporation',
      size: '4.8 MB',
      version: '11.2405.21.0',
      icon: <FileText className="w-5 h-5 text-sky-500" />,
      canUninstall: true,
    },
    {
      id: 'calculator',
      name: 'Windows Calculator',
      publisher: 'Microsoft Corporation',
      size: '6.2 MB',
      version: '11.2309.16.0',
      icon: <Calculator className="w-5 h-5 text-amber-500" />,
      canUninstall: true,
    },
    {
      id: 'settings',
      name: 'Windows Settings',
      publisher: 'Microsoft Corporation',
      size: '12.0 MB',
      version: '24H2.1',
      icon: <Sliders className="w-5 h-5 text-blue-400" />,
      canUninstall: false,
    },
    {
      id: 'photos',
      name: 'Microsoft Photos',
      publisher: 'Microsoft Corporation',
      size: '48.6 MB',
      version: '2024.11050.8001.0',
      icon: <Image className="w-5 h-5 text-teal-500" />,
      canUninstall: true,
    },
    {
      id: 'terminal',
      name: 'Windows Terminal',
      publisher: 'Microsoft Corporation',
      size: '28.4 MB',
      version: '1.20.11781.0',
      icon: <Terminal className="w-5 h-5 text-slate-400" />,
      canUninstall: true,
    },
    {
      id: 'spotify',
      name: 'Spotify Music',
      publisher: 'Spotify AB',
      size: '185 MB',
      version: '1.2.45.454',
      icon: <Music className="w-5 h-5 text-emerald-500" />,
      canUninstall: true,
    },
  ]);

  const [startupApps, setStartupApps] = useState([
    { id: 'teams', name: 'Microsoft Teams', impact: 'High impact', enabled: true },
    { id: 'onedrive', name: 'Microsoft OneDrive', impact: 'Medium impact', enabled: true },
    { id: 'spotify-start', name: 'Spotify Desktop', impact: 'High impact', enabled: false },
    { id: 'security', name: 'Windows Security notification icon', impact: 'Low impact', enabled: true },
  ]);

  const handleUninstall = (id: string, name: string) => {
    setApps((prev) => prev.filter((a) => a.id !== id));
    setToastMsg(`Successfully uninstalled ${name}`);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const filteredApps = apps
    .filter((a) => a.name.toLowerCase().includes(searchFilter.toLowerCase()))
    .sort((a, b) => (sortBy === 'name' ? a.name.localeCompare(b.name) : b.size.localeCompare(a.size)));

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Toast Feedback */}
      {toastMsg && (
        <div className="fixed bottom-14 right-6 z-50 bg-blue-600 text-white px-4 py-2 rounded-xl shadow-lg text-xs flex items-center space-x-2 animate-fade-in">
          <Check className="w-4 h-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Apps</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Installed applications, default programs, and startup task manager
        </p>
      </div>

      {/* Installed Apps Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="font-semibold text-xs flex items-center space-x-1.5">
              <Layers className="w-4 h-4 text-violet-500" />
              <span>Installed Apps ({filteredApps.length})</span>
            </span>
            <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Manage, modify or uninstall applications on this PC
            </p>
          </div>

          <div className="flex items-center space-x-2">
            {/* Search Input */}
            <div
              className={`flex items-center px-2.5 py-1 rounded-lg border text-xs ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-100 border-slate-300 text-slate-800'
              }`}
            >
              <Search className="w-3.5 h-3.5 text-slate-400 mr-1.5 shrink-0" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search apps..."
                className="w-28 sm:w-36 bg-transparent border-0 focus:outline-hidden text-xs"
              />
            </div>

            {/* Sort Dropdown */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'name' | 'size')}
              className={`px-2.5 py-1 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="name">Sort by: Name</option>
              <option value="size">Sort by: Size</option>
            </select>
          </div>
        </div>

        {/* Apps List */}
        <div className="space-y-2 pt-1">
          {filteredApps.map((app) => (
            <div
              key={app.id}
              className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                isDark ? 'border-slate-800 bg-slate-800/40' : 'border-slate-200 bg-slate-50'
              }`}
            >
              <div className="flex items-center space-x-3 min-w-0">
                <div className="p-2 rounded-lg bg-white/5 shrink-0">{app.icon}</div>
                <div className="min-w-0">
                  <div className="font-semibold text-xs truncate">{app.name}</div>
                  <div className="text-[11px] text-slate-400">
                    {app.publisher} • v{app.version}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3 shrink-0">
                <span className="text-xs text-slate-400 hidden sm:inline">{app.size}</span>

                {app.canUninstall && (
                  <button
                    type="button"
                    onClick={() => handleUninstall(app.id, app.name)}
                    className="px-2.5 py-1 rounded-lg border text-[11px] text-slate-400 hover:text-red-400 hover:border-red-500/40 cursor-pointer transition-colors"
                  >
                    Uninstall
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Default Apps Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs">Default Applications</span>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
          <div className="p-2.5 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Web Browser</div>
              <div className="font-medium">Microsoft Edge</div>
            </div>
            <Globe className="w-4 h-4 text-blue-500" />
          </div>

          <div className="p-2.5 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Text Editor</div>
              <div className="font-medium">Windows Notepad</div>
            </div>
            <FileText className="w-4 h-4 text-sky-500" />
          </div>

          <div className="p-2.5 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Photo Viewer</div>
              <div className="font-medium">Microsoft Photos</div>
            </div>
            <Image className="w-4 h-4 text-teal-500" />
          </div>

          <div className="p-2.5 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">AI Assistant</div>
              <div className="font-medium">Copilot (Gemini Flash)</div>
            </div>
            <Bot className="w-4 h-4 text-indigo-500" />
          </div>
        </div>
      </div>

      {/* Startup Apps Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="font-semibold text-xs">Startup Apps</span>
          <span className="text-[11px] text-slate-400">Apps start when you sign in</span>
        </div>

        <div className="space-y-2 pt-1">
          {startupApps.map((item) => (
            <div key={item.id} className="flex items-center justify-between py-1.5 border-b border-inherit text-xs">
              <div>
                <div className="font-medium">{item.name}</div>
                <div className="text-[10px] text-slate-400">{item.impact}</div>
              </div>

              <button
                type="button"
                onClick={() =>
                  setStartupApps((prev) =>
                    prev.map((s) => (s.id === item.id ? { ...s, enabled: !s.enabled } : s))
                  )
                }
                className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                  item.enabled ? 'bg-blue-600' : 'bg-slate-600'
                }`}
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                    item.enabled ? 'left-5.5' : 'left-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
