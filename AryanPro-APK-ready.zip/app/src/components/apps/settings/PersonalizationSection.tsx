import React from 'react';
import {
  Sun,
  Moon,
  Check,
  LayoutGrid,
  Sliders,
  Sparkles,
  Eye,
  Monitor,
  CheckCircle2,
  Paintbrush,
} from 'lucide-react';
import { SystemSettings, WallpaperId } from '../../../types';
import { WALLPAPERS } from '../../../utils/wallpapers';
import { ACCENT_COLOR_PALETTE, PRESET_THEMES } from './types';

interface PersonalizationSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const PersonalizationSection: React.FC<PersonalizationSectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const currentWallpaper = WALLPAPERS.find((w) => w.id === settings.wallpaper) || WALLPAPERS[0];

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Personalization</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Customize wallpapers, themes, taskbar position, and Windows colors
        </p>
      </div>

      {/* Mini Desktop Live Preview Banner */}
      <div
        className={`p-4 rounded-2xl border relative overflow-hidden transition-all ${
          isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold flex items-center space-x-1.5">
            <Monitor className="w-4 h-4 text-blue-500" />
            <span>Active Desktop Preview</span>
          </span>
          <span className="text-[11px] text-slate-400">
            {currentWallpaper.name} • {settings.theme === 'dark' ? 'Dark' : 'Light'} Mode
          </span>
        </div>

        {/* Scaled desktop simulator screen */}
        <div className="relative w-full h-44 sm:h-52 rounded-xl overflow-hidden shadow-inner border border-black/20 flex flex-col justify-between p-3 select-none">
          {/* Simulated wallpaper background */}
          <div className={`absolute inset-0 bg-gradient-to-tr ${currentWallpaper.previewGradient} transition-all duration-500`} />
          <div className="absolute inset-0 bg-black/10 backdrop-blur-[0.5px]" />

          {/* Mini Window floating on the desktop preview */}
          <div
            className={`relative z-10 w-48 sm:w-60 rounded-lg shadow-xl border overflow-hidden transition-colors ${
              isDark ? 'bg-slate-900/90 border-slate-700 text-white' : 'bg-white/95 border-slate-300 text-slate-900'
            }`}
          >
            {/* Titlebar */}
            <div
              className={`h-5 px-2 flex items-center justify-between text-[9px] border-b ${
                settings.showAccentOnTitleBars
                  ? 'text-white'
                  : isDark
                  ? 'border-slate-800 bg-slate-950/40 text-slate-300'
                  : 'border-slate-200 bg-slate-100 text-slate-700'
              }`}
              style={{
                backgroundColor: settings.showAccentOnTitleBars ? settings.accentColor : undefined,
              }}
            >
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 rounded-xs bg-blue-500" />
                <span className="font-semibold">Sample Window</span>
              </div>
              <div className="flex space-x-1">
                <div className="w-2 h-2 rounded-full bg-amber-500/80" />
                <div className="w-2 h-2 rounded-full bg-red-500/80" />
              </div>
            </div>
            {/* Window Content */}
            <div className="p-2.5 text-[10px] space-y-1.5">
              <div className="flex items-center justify-between">
                <span>Theme: {settings.theme.toUpperCase()}</span>
                <span
                  className="px-1.5 py-0.5 rounded text-[8px] font-bold text-white shadow-xs"
                  style={{ backgroundColor: settings.accentColor }}
                >
                  Accent
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-500/20 overflow-hidden">
                <div className="h-full rounded-full" style={{ width: '70%', backgroundColor: settings.accentColor }} />
              </div>
            </div>
          </div>

          {/* Mini Taskbar Simulator */}
          <div
            className={`relative z-10 w-full h-6 rounded-md border flex items-center px-2 transition-all ${
              settings.transparencyEffects !== false
                ? isDark
                  ? 'bg-slate-950/80 border-white/10 backdrop-blur-md'
                  : 'bg-white/80 border-slate-300 backdrop-blur-md'
                : isDark
                ? 'bg-slate-950 border-slate-800'
                : 'bg-white border-slate-300'
            }`}
          >
            <div
              className={`flex items-center space-x-1.5 w-full ${
                settings.taskbarAlignment === 'center' ? 'justify-center' : 'justify-start'
              }`}
            >
              {/* Mini Start icon */}
              <div className="grid grid-cols-2 gap-0.5 w-3 h-3">
                <div className="bg-sky-400 rounded-xs" />
                <div className="bg-sky-500 rounded-xs" />
                <div className="bg-blue-600 rounded-xs" />
                <div className="bg-blue-500 rounded-xs" />
              </div>

              {/* Mini Search */}
              {settings.taskbarSearch !== 'hide' && (
                <div className="w-8 h-2.5 rounded-full bg-slate-500/30" />
              )}

              {/* Mini App Icons */}
              <div className="w-3 h-3 rounded-xs bg-amber-500" />
              <div className="relative">
                <div className="w-3 h-3 rounded-xs bg-blue-600" />
                <div
                  className="absolute -bottom-1 left-0.5 right-0.5 h-0.5 rounded-full"
                  style={{ backgroundColor: settings.accentColor }}
                />
              </div>
              <div className="w-3 h-3 rounded-xs bg-indigo-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Preset One-Click Themes */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center space-x-2 mb-1 font-semibold text-xs">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>Preset Windows 11 Themes</span>
        </div>
        <p className={`text-[11px] mb-3.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Select a coordinated theme pairing wallpaper, color mode, and accent color in one click
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {PRESET_THEMES.map((theme) => {
            const isMatch =
              settings.wallpaper === theme.wallpaper &&
              settings.theme === theme.theme &&
              settings.accentColor.toLowerCase() === theme.accentColor.toLowerCase();

            return (
              <button
                key={theme.id}
                type="button"
                onClick={() =>
                  onUpdateSettings({
                    wallpaper: theme.wallpaper,
                    theme: theme.theme,
                    accentColor: theme.accentColor,
                  })
                }
                className={`p-2 rounded-xl border text-left cursor-pointer transition-all hover:scale-[1.02] ${
                  isMatch
                    ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/5'
                    : isDark
                    ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                }`}
              >
                <div
                  className={`w-full h-12 rounded-lg ${theme.preview} mb-2 shadow-inner flex items-center justify-center relative`}
                >
                  {isMatch && (
                    <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                  <span
                    className="absolute bottom-1 right-1 w-3 h-3 rounded-full border border-white/50 shadow-xs"
                    style={{ backgroundColor: theme.accentColor }}
                  />
                </div>
                <div className="text-[11px] font-semibold truncate">{theme.name}</div>
                <div className="text-[10px] text-slate-400 capitalize">{theme.theme} Mode</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Background / Wallpaper Selection */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between mb-1">
          <span className="font-semibold text-xs">Desktop Background</span>
          <span className="text-[11px] text-blue-500 font-medium">{WALLPAPERS.length} Windows 11 wallpapers</span>
        </div>
        <p className={`text-[11px] mb-3.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Choose an interactive animated or gradient backdrop for your Windows 11 desktop:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {WALLPAPERS.map((wp) => {
            const isSelected = settings.wallpaper === wp.id;
            return (
              <button
                key={wp.id}
                type="button"
                onClick={() => onUpdateSettings({ wallpaper: wp.id })}
                className={`group relative p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/5 shadow-md'
                    : isDark
                    ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                }`}
              >
                <div
                  className={`w-full h-20 rounded-lg bg-gradient-to-tr ${wp.previewGradient} flex items-center justify-center mb-2 shadow-inner relative overflow-hidden`}
                >
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg">
                      <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                    </div>
                  )}
                </div>
                <div className="text-xs font-semibold truncate">{wp.name}</div>
                <div className="text-[10px] text-slate-400">Desktop Wallpaper</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Colors & Light/Dark Mode */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div>
          <span className="font-semibold text-xs">Colors & Mode</span>
          <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Configure your Windows light or dark appearance and accent highlights
          </p>
        </div>

        {/* Light / Dark Mode Toggle Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => onUpdateSettings({ theme: 'light' })}
            className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-center space-x-3 ${
              settings.theme === 'light'
                ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-50/60 shadow-xs'
                : isDark
                ? 'border-slate-800 bg-slate-800/30 hover:bg-slate-800/60'
                : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
            }`}
          >
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-500">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-xs">Light Mode</div>
              <div className="text-[10px] text-slate-400">Crisp white fluent surfaces</div>
            </div>
            {settings.theme === 'light' && (
              <CheckCircle2 className="w-4 h-4 text-blue-600 ml-auto shrink-0" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onUpdateSettings({ theme: 'dark' })}
            className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-center space-x-3 ${
              settings.theme === 'dark'
                ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/10 shadow-xs'
                : isDark
                ? 'border-slate-800 bg-slate-800/30 hover:bg-slate-800/60'
                : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
            }`}
          >
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-xs">Dark Mode</div>
              <div className="text-[10px] text-slate-400">Deep sleek dark acrylic surfaces</div>
            </div>
            {settings.theme === 'dark' && (
              <CheckCircle2 className="w-4 h-4 text-blue-500 ml-auto shrink-0" />
            )}
          </button>
        </div>

        {/* Transparency Effects Toggle */}
        <div className="pt-3 border-t border-inherit flex items-center justify-between">
          <div>
            <div className="font-semibold text-xs">Transparency effects</div>
            <div className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Windows and taskbar appear translucent with acrylic blur
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              onUpdateSettings({
                transparencyEffects: settings.transparencyEffects === false ? true : false,
              })
            }
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.transparencyEffects !== false ? 'bg-blue-600' : 'bg-slate-600'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                settings.transparencyEffects !== false ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Accent Color Palette */}
        <div className="pt-3 border-t border-inherit">
          <div className="font-semibold text-xs mb-1">Accent Color</div>
          <div className={`text-[11px] mb-3 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Choose an accent color for active app markers, sliders, and highlights:
          </div>

          <div className="flex flex-wrap items-center gap-2.5 mb-4">
            {ACCENT_COLOR_PALETTE.map((c) => {
              const isSelected = settings.accentColor.toLowerCase() === c.value.toLowerCase();
              return (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => onUpdateSettings({ accentColor: c.value })}
                  title={c.name}
                  className="relative w-8 h-8 rounded-full cursor-pointer transition-transform hover:scale-110 flex items-center justify-center shadow-xs"
                  style={{ backgroundColor: c.value }}
                >
                  {isSelected && <Check className="w-4 h-4 text-white stroke-[3]" />}
                </button>
              );
            })}

            {/* Custom Hex Color Picker */}
            <label
              title="Custom Color"
              className="w-8 h-8 rounded-full border-2 border-dashed border-slate-400 flex items-center justify-center cursor-pointer hover:border-slate-200 transition-colors relative"
            >
              <Paintbrush className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="color"
                value={settings.accentColor}
                onChange={(e) => onUpdateSettings({ accentColor: e.target.value })}
                className="opacity-0 absolute inset-0 cursor-pointer w-full h-full"
              />
            </label>
          </div>

          {/* Accent Color Toggles */}
          <div className="space-y-2.5 pt-2 border-t border-inherit">
            <div className="flex items-center justify-between">
              <span className="text-xs">Show accent color on Start and taskbar</span>
              <button
                type="button"
                onClick={() =>
                  onUpdateSettings({
                    showAccentOnTaskbar: settings.showAccentOnTaskbar === false ? true : false,
                  })
                }
                className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                  settings.showAccentOnTaskbar !== false ? 'bg-blue-600' : 'bg-slate-600'
                }`}
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                    settings.showAccentOnTaskbar !== false ? 'left-5.5' : 'left-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs">Show accent color on title bars and window borders</span>
              <button
                type="button"
                onClick={() =>
                  onUpdateSettings({
                    showAccentOnTitleBars: !settings.showAccentOnTitleBars,
                  })
                }
                className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                  settings.showAccentOnTitleBars ? 'bg-blue-600' : 'bg-slate-600'
                }`}
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                    settings.showAccentOnTitleBars ? 'left-5.5' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Taskbar Settings (COMPLETE & FUNCTIONAL) */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div>
          <span className="font-semibold text-xs flex items-center space-x-1.5">
            <LayoutGrid className="w-4 h-4 text-blue-500" />
            <span>Taskbar Behaviors & Items</span>
          </span>
          <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Configure taskbar alignment, search item style, and pinned system shortcuts
          </p>
        </div>

        {/* Taskbar Alignment */}
        <div className="flex items-center justify-between p-3 rounded-xl border border-inherit bg-slate-500/5">
          <div>
            <div className="font-semibold text-xs">Taskbar Alignment</div>
            <div className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Position the Start button and apps in the center or on the left
            </div>
          </div>

          <div className="flex items-center space-x-1 p-0.5 rounded-lg border border-inherit bg-slate-500/10">
            <button
              type="button"
              onClick={() => onUpdateSettings({ taskbarAlignment: 'center' })}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                settings.taskbarAlignment === 'center'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Center
            </button>
            <button
              type="button"
              onClick={() => onUpdateSettings({ taskbarAlignment: 'left' })}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                settings.taskbarAlignment === 'left'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Left
            </button>
          </div>
        </div>

        {/* Taskbar Search Item */}
        <div className="flex items-center justify-between p-3 rounded-xl border border-inherit bg-slate-500/5">
          <div>
            <div className="font-semibold text-xs">Search Button Style</div>
            <div className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Choose how search appears on your taskbar
            </div>
          </div>

          <select
            value={settings.taskbarSearch || 'box'}
            onChange={(e) =>
              onUpdateSettings({
                taskbarSearch: e.target.value as 'box' | 'icon' | 'hide',
              })
            }
            className={`px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
              isDark
                ? 'bg-slate-800 border-slate-700 text-slate-200'
                : 'bg-white border-slate-300 text-slate-800'
            }`}
          >
            <option value="box">Search box</option>
            <option value="icon">Search icon only</option>
            <option value="hide">Hide search</option>
          </select>
        </div>

        {/* Taskbar Items Toggles */}
        <div className="space-y-2.5 pt-1">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-medium">Weather & Widgets</div>
              <div className="text-[11px] text-slate-400">Show weather ticker on left taskbar</div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  taskbarWidgets: settings.taskbarWidgets === false ? true : false,
                })
              }
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                settings.taskbarWidgets !== false ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  settings.taskbarWidgets !== false ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-medium">Copilot (AI Companion)</div>
              <div className="text-[11px] text-slate-400">Show Copilot pinned to taskbar</div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  taskbarCopilot: settings.taskbarCopilot === false ? true : false,
                })
              }
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                settings.taskbarCopilot !== false ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  settings.taskbarCopilot !== false ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-medium">Show badges on taskbar apps</div>
              <div className="text-[11px] text-slate-400">Show notification counts on running icons</div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  taskbarBadges: settings.taskbarBadges === false ? true : false,
                })
              }
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                settings.taskbarBadges !== false ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  settings.taskbarBadges !== false ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
