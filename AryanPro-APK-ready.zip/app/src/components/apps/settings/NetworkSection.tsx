import React, { useState } from 'react';
import {
  Wifi,
  WifiOff,
  Globe,
  Radio,
  Shield,
  Smartphone,
  HardDrive,
  Lock,
  Check,
  RefreshCw,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface NetworkSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

interface WifiNetwork {
  ssid: string;
  security: string;
  signal: number;
  connected: boolean;
}

export const NetworkSection: React.FC<NetworkSectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const [networks, setNetworks] = useState<WifiNetwork[]>([
    { ssid: 'Home-Ultra-5G', security: 'WPA3-Personal', signal: 4, connected: true },
    { ssid: 'Studio_Office_Fast', security: 'WPA2/WPA3', signal: 4, connected: false },
    { ssid: 'Neighbor_5G_Ext', security: 'WPA2-Personal', signal: 3, connected: false },
    { ssid: 'CoffeeShop_Guest', security: 'Open', signal: 2, connected: false },
  ]);

  const [vpnEnabled, setVpnEnabled] = useState(false);
  const [hotspotEnabled, setHotspotEnabled] = useState(false);
  const [airplaneMode, setAirplaneMode] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  const handleConnect = (ssid: string) => {
    setNetworks((prev) =>
      prev.map((n) => ({
        ...n,
        connected: n.ssid === ssid ? !n.connected : false,
      }))
    );
  };

  const handleScan = () => {
    setIsScanning(true);
    setTimeout(() => setIsScanning(false), 1200);
  };

  const activeNet = networks.find((n) => n.connected);

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Network & internet</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Wi-Fi, Ethernet, VPN, mobile hotspot, and internet connectivity status
        </p>
      </div>

      {/* Primary Connection Status Hero */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                settings.wifiEnabled && activeNet
                  ? 'bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-500'
                  : 'bg-slate-500/10 text-slate-400'
              }`}
            >
              {settings.wifiEnabled ? <Wifi className="w-6 h-6" /> : <WifiOff className="w-6 h-6" />}
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm">
                  {settings.wifiEnabled && activeNet ? activeNet.ssid : 'Not Connected'}
                </span>
                {settings.wifiEnabled && activeNet && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 font-semibold">
                    Connected, secured
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {settings.wifiEnabled && activeNet
                  ? 'Wi-Fi 6 (802.11ax) • 5 GHz • 48.2 GB used in last 30 days'
                  : 'Turn on Wi-Fi to connect to the internet'}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleScan}
              title="Refresh network list"
              className={`p-2 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 text-slate-400 ${isScanning ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Wi-Fi Master Toggle & Networks List */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-500">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-xs">Wi-Fi</div>
              <div className="text-[11px] text-slate-400">
                {settings.wifiEnabled ? 'Connect to available wireless networks' : 'Wi-Fi is turned off'}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onUpdateSettings({ wifiEnabled: !settings.wifiEnabled })}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.wifiEnabled ? 'bg-blue-600' : 'bg-slate-600'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                settings.wifiEnabled ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Available Networks List */}
        {settings.wifiEnabled && (
          <div className="space-y-2 pt-2 border-t border-inherit">
            <div className="text-[11px] font-semibold text-slate-400">Available Networks</div>

            {networks.map((net) => (
              <div
                key={net.ssid}
                className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                  net.connected
                    ? isDark
                      ? 'border-emerald-500/50 bg-emerald-500/5'
                      : 'border-emerald-500/50 bg-emerald-50'
                    : isDark
                    ? 'border-slate-800 bg-slate-800/40'
                    : 'border-slate-200 bg-slate-50'
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <Wifi className={`w-4 h-4 shrink-0 ${net.connected ? 'text-emerald-500' : 'text-slate-400'}`} />
                  <div className="min-w-0">
                    <div className="font-semibold text-xs truncate">{net.ssid}</div>
                    <div className="text-[10px] text-slate-400">
                      {net.security} {net.connected ? '• Connected' : ''}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {net.security !== 'Open' && <Lock className="w-3.5 h-3.5 text-slate-400" />}
                  <button
                    type="button"
                    onClick={() => handleConnect(net.ssid)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium border cursor-pointer transition-colors ${
                      net.connected
                        ? 'border-slate-600 hover:bg-slate-700/50 text-slate-300'
                        : 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {net.connected ? 'Disconnect' : 'Connect'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Hardware Properties */}
      {settings.wifiEnabled && activeNet && (
        <div
          className={`p-4 rounded-2xl border transition-colors space-y-3 ${
            isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <span className="font-semibold text-xs">Hardware Properties</span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <div className="text-[11px] text-slate-400">SSID</div>
              <div className="font-medium">{activeNet.ssid}</div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">Protocol</div>
              <div className="font-medium">Wi-Fi 6 (802.11ax)</div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">Security type</div>
              <div className="font-medium">WPA3-Personal</div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">IPv4 address</div>
              <div className="font-medium">192.168.1.108</div>
            </div>
          </div>
        </div>
      )}

      {/* Additional Network Features (VPN, Hotspot, Airplane Mode) */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs">Advanced Network Controls</span>

        <div className="space-y-3 pt-1">
          {/* VPN Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Shield className="w-4 h-4 text-indigo-500" />
              <div>
                <div className="text-xs font-medium">VPN</div>
                <div className="text-[11px] text-slate-400">Secure tunneling and network privacy</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setVpnEnabled(!vpnEnabled)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                vpnEnabled ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  vpnEnabled ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Mobile Hotspot */}
          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div className="flex items-center space-x-3">
              <Smartphone className="w-4 h-4 text-teal-500" />
              <div>
                <div className="text-xs font-medium">Mobile hotspot</div>
                <div className="text-[11px] text-slate-400">Share your internet connection with other devices</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setHotspotEnabled(!hotspotEnabled)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                hotspotEnabled ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  hotspotEnabled ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Airplane Mode */}
          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div className="flex items-center space-x-3">
              <Radio className="w-4 h-4 text-amber-500" />
              <div>
                <div className="text-xs font-medium">Airplane mode</div>
                <div className="text-[11px] text-slate-400">Stop all wireless communication</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setAirplaneMode(!airplaneMode);
                if (!airplaneMode) {
                  onUpdateSettings({ wifiEnabled: false, bluetoothEnabled: false });
                }
              }}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                airplaneMode ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  airplaneMode ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
