import React, { useState } from 'react';
import {
  User,
  Shield,
  Key,
  Fingerprint,
  Smile,
  Cloud,
  Users,
  Check,
  ChevronRight,
  Lock,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface AccountsSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const AccountsSection: React.FC<AccountsSectionProps> = ({
  settings,
  isDark,
}) => {
  const [backupSynced, setBackupSynced] = useState(true);
  const [rememberApps, setRememberApps] = useState(true);
  const [rememberPrefs, setRememberPrefs] = useState(true);

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Accounts</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Your user profile, Windows Hello sign-in options, OneDrive cloud backup, and family
        </p>
      </div>

      {/* User Profile Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center font-bold text-lg text-white shadow-md shrink-0"
              style={{ backgroundColor: settings.accentColor }}
            >
              AD
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-base">Administrator</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-500 font-semibold">
                  Administrator
                </span>
              </div>
              <div className="text-xs text-slate-400">parveshsaiyam34@gmail.com</div>
              <div className="text-[11px] text-emerald-500 flex items-center space-x-1 mt-1 font-medium">
                <Check className="w-3.5 h-3.5" />
                <span>Microsoft Account connected & synced</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
              isDark ? 'border-slate-700 hover:bg-slate-800 text-slate-200' : 'border-slate-300 hover:bg-slate-100 text-slate-800'
            }`}
          >
            Manage Account
          </button>
        </div>
      </div>

      {/* Sign-in Options (Windows Hello) */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs flex items-center space-x-1.5">
          <Key className="w-4 h-4 text-amber-500" />
          <span>Sign-in Options (Windows Hello)</span>
        </span>
        <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Ways to sign in to Windows using biometric authentication or security credentials
        </p>

        <div className="space-y-2 pt-1 text-xs">
          {/* Facial Recognition */}
          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Smile className="w-5 h-5 text-sky-500" />
              <div>
                <div className="font-semibold">Facial recognition (Windows Hello)</div>
                <div className="text-[11px] text-slate-400">Sign in with your IR camera</div>
              </div>
            </div>
            <button
              type="button"
              className="px-3 py-1 rounded-lg border border-slate-600 hover:bg-slate-700/50 text-slate-300 cursor-pointer text-xs"
            >
              Set up
            </button>
          </div>

          {/* Fingerprint */}
          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Fingerprint className="w-5 h-5 text-indigo-500" />
              <div>
                <div className="font-semibold">Fingerprint recognition (Windows Hello)</div>
                <div className="text-[11px] text-slate-400">Sign in with your fingerprint scanner</div>
              </div>
            </div>
            <button
              type="button"
              className="px-3 py-1 rounded-lg border border-slate-600 hover:bg-slate-700/50 text-slate-300 cursor-pointer text-xs"
            >
              Set up
            </button>
          </div>

          {/* PIN */}
          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Key className="w-5 h-5 text-emerald-500" />
              <div>
                <div className="font-semibold">PIN (Windows Hello)</div>
                <div className="text-[11px] text-slate-400">Sign in with a secure numerical or alphanumeric PIN</div>
              </div>
            </div>
            <button
              type="button"
              className="px-3 py-1 rounded-lg border border-slate-600 hover:bg-slate-700/50 text-slate-300 cursor-pointer text-xs"
            >
              Change PIN
            </button>
          </div>

          {/* Password */}
          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Lock className="w-5 h-5 text-violet-500" />
              <div>
                <div className="font-semibold">Password</div>
                <div className="text-[11px] text-slate-400">Sign in with your account password</div>
              </div>
            </div>
            <button
              type="button"
              className="px-3 py-1 rounded-lg border border-slate-600 hover:bg-slate-700/50 text-slate-300 cursor-pointer text-xs"
            >
              Change
            </button>
          </div>
        </div>
      </div>

      {/* Windows Backup Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Cloud className="w-4 h-4 text-blue-500" />
            <span className="font-semibold text-xs">Windows Backup & Cloud Sync</span>
          </div>
          <span className="text-[11px] text-emerald-500 font-semibold">Backed up to OneDrive</span>
        </div>

        <div className="space-y-2.5 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Remember my apps</div>
              <div className="text-[11px] text-slate-400">Sync app list to restore on new devices</div>
            </div>
            <button
              type="button"
              onClick={() => setRememberApps(!rememberApps)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                rememberApps ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  rememberApps ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div>
              <div className="font-medium">Remember my preferences</div>
              <div className="text-[11px] text-slate-400">Sync theme, accent colors, and taskbar options</div>
            </div>
            <button
              type="button"
              onClick={() => setRememberPrefs(!rememberPrefs)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                rememberPrefs ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  rememberPrefs ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
