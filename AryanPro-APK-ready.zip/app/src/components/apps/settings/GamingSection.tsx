import React, { useState } from 'react';
import {
  Gamepad2,
  Video,
  Sparkles,
  Sliders,
  Tv,
  Zap,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface GamingSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const GamingSection: React.FC<GamingSectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const [gameBarEnabled, setGameBarEnabled] = useState(true);
  const [recordLast30, setRecordLast30] = useState(true);
  const [fps, setFps] = useState<'60' | '30'>('60');
  const [autoHdr, setAutoHdr] = useState(true);
  const [hardwareGpu, setHardwareGpu] = useState(true);

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Gaming</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Xbox Game Bar, screen captures, Game Mode optimization, and graphics settings
        </p>
      </div>

      {/* Game Mode Banner */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-xl bg-lime-500/10 dark:bg-lime-500/20 text-lime-500 flex items-center justify-center shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm">Game Mode</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-lime-500/10 text-lime-500 font-semibold">
                  Active
                </span>
              </div>
              <div className="text-xs text-slate-400">
                Optimizes your PC for play by turning things off in the background
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() =>
              onUpdateSettings({
                gameMode: settings.gameMode === false ? true : false,
              })
            }
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.gameMode !== false ? 'bg-blue-600' : 'bg-slate-600'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                settings.gameMode !== false ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Xbox Game Bar Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Gamepad2 className="w-5 h-5 text-lime-500" />
            <div>
              <div className="font-semibold text-xs">Xbox Game Bar</div>
              <div className="text-[11px] text-slate-400">
                Open Game Bar using <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px]">Win</kbd> + <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px]">G</kbd>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setGameBarEnabled(!gameBarEnabled)}
            className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
              gameBarEnabled ? 'bg-blue-600' : 'bg-slate-600'
            }`}
          >
            <div
              className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                gameBarEnabled ? 'left-5.5' : 'left-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Captures Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs flex items-center space-x-1.5">
          <Video className="w-4 h-4 text-sky-500" />
          <span>Captures & Gameplay Recording</span>
        </span>

        <div className="space-y-3 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Record what happened (Background Recording)</div>
              <div className="text-[11px] text-slate-400">Records the last 30 seconds of gameplay</div>
            </div>
            <button
              type="button"
              onClick={() => setRecordLast30(!recordLast30)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                recordLast30 ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  recordLast30 ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-inherit">
            <div>
              <label className="text-[11px] text-slate-400 mb-1 block">Video frame rate</label>
              <select
                value={fps}
                onChange={(e) => setFps(e.target.value as '60' | '30')}
                className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                  isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
                }`}
              >
                <option value="60">60 fps (Smooth motion)</option>
                <option value="30">30 fps (Standard)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-slate-400 mb-1 block">Max recording length</label>
              <select
                defaultValue="2h"
                className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                  isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
                }`}
              >
                <option value="30m">30 minutes</option>
                <option value="1h">1 hour</option>
                <option value="2h">2 hours (Recommended)</option>
                <option value="4h">4 hours</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Graphics & HDR Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs flex items-center space-x-1.5">
          <Tv className="w-4 h-4 text-violet-500" />
          <span>Advanced Graphics & HDR</span>
        </span>

        <div className="space-y-3 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Hardware-accelerated GPU scheduling</div>
              <div className="text-[11px] text-slate-400">Reduce latency and improve graphics performance</div>
            </div>
            <button
              type="button"
              onClick={() => setHardwareGpu(!hardwareGpu)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                hardwareGpu ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  hardwareGpu ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div>
              <div className="font-medium">Auto HDR</div>
              <div className="text-[11px] text-slate-400">Automatically upgrade SDR games to vibrant HDR colors</div>
            </div>
            <button
              type="button"
              onClick={() => setAutoHdr(!autoHdr)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                autoHdr ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  autoHdr ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
