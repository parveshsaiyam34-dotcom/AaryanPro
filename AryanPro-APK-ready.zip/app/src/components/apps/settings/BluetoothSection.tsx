import React, { useState } from 'react';
import {
  Bluetooth,
  Plus,
  Mouse,
  Keyboard,
  Headphones,
  Smartphone,
  Printer,
  Sliders,
  MoreVertical,
  Check,
  X,
  Radio,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface BluetoothSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

interface DeviceItem {
  id: string;
  name: string;
  type: 'mouse' | 'keyboard' | 'audio' | 'phone';
  status: 'connected' | 'paired';
  battery?: number;
}

export const BluetoothSection: React.FC<BluetoothSectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const [devices, setDevices] = useState<DeviceItem[]>([
    { id: '1', name: 'Surface Precision Mouse', type: 'mouse', status: 'connected', battery: 85 },
    { id: '2', name: 'Keychron K2 Mechanical Keyboard', type: 'keyboard', status: 'connected', battery: 92 },
    { id: '3', name: 'Sony WH-1000XM5 Headphones', type: 'audio', status: 'paired' },
    { id: '4', name: 'Pixel 9 Pro (Phone Link)', type: 'phone', status: 'connected', battery: 74 },
  ]);

  const [isAddDeviceOpen, setIsAddDeviceOpen] = useState(false);
  const [newDeviceScanning, setNewDeviceScanning] = useState(false);
  const [primaryMouseButton, setPrimaryMouseButton] = useState<'left' | 'right'>('left');
  const [mouseSpeed, setMouseSpeed] = useState(10);

  const toggleConnect = (id: string) => {
    setDevices((prev) =>
      prev.map((d) =>
        d.id === id
          ? { ...d, status: d.status === 'connected' ? 'paired' : 'connected' }
          : d
      )
    );
  };

  const removeDevice = (id: string) => {
    setDevices((prev) => prev.filter((d) => d.id !== id));
  };

  const getDeviceIcon = (type: DeviceItem['type']) => {
    switch (type) {
      case 'mouse':
        return <Mouse className="w-5 h-5 text-sky-500" />;
      case 'keyboard':
        return <Keyboard className="w-5 h-5 text-indigo-500" />;
      case 'audio':
        return <Headphones className="w-5 h-5 text-purple-500" />;
      case 'phone':
        return <Smartphone className="w-5 h-5 text-emerald-500" />;
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Bluetooth & devices</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Pair and manage Bluetooth accessories, mice, keyboards, and printers
        </p>
      </div>

      {/* Master Toggle & Add Device Banner */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3.5">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                settings.bluetoothEnabled
                  ? 'bg-sky-500/10 dark:bg-sky-500/20 text-sky-500'
                  : 'bg-slate-500/10 text-slate-400'
              }`}
            >
              <Bluetooth className="w-6 h-6" />
            </div>
            <div>
              <div className="font-semibold text-sm">Bluetooth</div>
              <div className="text-xs text-slate-400">
                {settings.bluetoothEnabled
                  ? 'Discoverable as "DESKTOP-WIN11-PRO"'
                  : 'Bluetooth is turned off'}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => onUpdateSettings({ bluetoothEnabled: !settings.bluetoothEnabled })}
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.bluetoothEnabled ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                  settings.bluetoothEnabled ? 'left-6' : 'left-1'
                }`}
              />
            </button>

            <button
              type="button"
              disabled={!settings.bluetoothEnabled}
              onClick={() => {
                setIsAddDeviceOpen(true);
                setNewDeviceScanning(true);
                setTimeout(() => setNewDeviceScanning(false), 2000);
              }}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
                !settings.bluetoothEnabled
                  ? 'opacity-40 cursor-not-allowed border-slate-700'
                  : 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add device</span>
            </button>
          </div>
        </div>
      </div>

      {/* Devices Grid */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="font-semibold text-xs">Paired & Connected Devices</span>
          <span className="text-[11px] text-slate-400">{devices.length} devices</span>
        </div>

        {!settings.bluetoothEnabled ? (
          <div className="py-6 text-center text-xs text-slate-400">
            Turn on Bluetooth to view and connect with paired devices
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {devices.map((device) => (
              <div
                key={device.id}
                className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                  isDark ? 'border-slate-800 bg-slate-800/40' : 'border-slate-200 bg-slate-50'
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div className="p-2 rounded-lg bg-white/5">{getDeviceIcon(device.type)}</div>
                  <div className="min-w-0">
                    <div className="font-semibold text-xs truncate">{device.name}</div>
                    <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          device.status === 'connected' ? 'bg-emerald-500' : 'bg-slate-500'
                        }`}
                      />
                      <span className="capitalize">{device.status}</span>
                      {device.battery !== undefined && (
                        <span>• {device.battery}% battery</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => toggleConnect(device.id)}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium border cursor-pointer transition-colors ${
                      device.status === 'connected'
                        ? 'border-slate-600 hover:bg-slate-700/50 text-slate-300'
                        : 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {device.status === 'connected' ? 'Disconnect' : 'Connect'}
                  </button>

                  <button
                    type="button"
                    onClick={() => removeDevice(device.id)}
                    title="Remove device"
                    className="p-1 rounded-md text-slate-400 hover:text-red-400 hover:bg-red-500/10 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Mouse & Touchpad Preferences */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div>
          <span className="font-semibold text-xs flex items-center space-x-1.5">
            <Mouse className="w-4 h-4 text-sky-500" />
            <span>Mouse & Cursor Configuration</span>
          </span>
          <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Primary button and pointer velocity settings
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-[11px] text-slate-400 mb-1 block">Primary Mouse Button</label>
            <select
              value={primaryMouseButton}
              onChange={(e) => setPrimaryMouseButton(e.target.value as 'left' | 'right')}
              className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="left">Left (Standard)</option>
              <option value="right">Right (Left-handed)</option>
            </select>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Mouse pointer speed</span>
              <span className="font-semibold">{mouseSpeed}</span>
            </div>
            <input
              type="range"
              min={1}
              max={20}
              value={mouseSpeed}
              onChange={(e) => setMouseSpeed(Number(e.target.value))}
              className="w-full accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer mt-2"
            />
          </div>
        </div>
      </div>

      {/* Printers & Scanners Subsection */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="font-semibold text-xs flex items-center space-x-1.5">
            <Printer className="w-4 h-4 text-violet-500" />
            <span>Printers & Scanners</span>
          </span>
          <span className="text-[11px] text-slate-400">3 installed</span>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-500/5">
            <div>
              <div className="font-medium">Microsoft Print to PDF</div>
              <div className="text-[10px] text-slate-400">Default printer</div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500">Ready</span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-500/5">
            <div>
              <div className="font-medium">Microsoft XPS Document Writer</div>
              <div className="text-[10px] text-slate-400">Document writer</div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500">Ready</span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-500/5">
            <div>
              <div className="font-medium">Brother HL-L2350DW Series</div>
              <div className="text-[10px] text-slate-400">Wi-Fi Laser Printer</div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-500/10 text-slate-400">Offline</span>
          </div>
        </div>
      </div>

      {/* Add Device Modal Simulator */}
      {isAddDeviceOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-5 space-y-4 ${
              isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm">Add a device</h3>
              <button
                type="button"
                onClick={() => setIsAddDeviceOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Choose the kind of device you want to add:
            </p>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  setDevices((prev) => [
                    ...prev,
                    {
                      id: Date.now().toString(),
                      name: 'Xbox Wireless Controller',
                      type: 'keyboard',
                      status: 'connected',
                      battery: 100,
                    },
                  ]);
                  setIsAddDeviceOpen(false);
                }}
                className={`w-full p-3 rounded-xl border text-left cursor-pointer transition-colors flex items-center space-x-3 ${
                  isDark ? 'border-slate-800 hover:bg-slate-800' : 'border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Bluetooth className="w-5 h-5 text-blue-500 shrink-0" />
                <div>
                  <div className="font-semibold text-xs">Bluetooth</div>
                  <div className="text-[10px] text-slate-400">Audio devices, mice, keyboards, phones, controllers</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsAddDeviceOpen(false)}
                className={`w-full p-3 rounded-xl border text-left cursor-pointer transition-colors flex items-center space-x-3 ${
                  isDark ? 'border-slate-800 hover:bg-slate-800' : 'border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Radio className="w-5 h-5 text-emerald-500 shrink-0" />
                <div>
                  <div className="font-semibold text-xs">Wireless display or dock</div>
                  <div className="text-[10px] text-slate-400">Miracast, wireless monitors, TVs</div>
                </div>
              </button>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsAddDeviceOpen(false)}
                className="px-4 py-1.5 rounded-lg border text-xs cursor-pointer text-slate-400 hover:text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
