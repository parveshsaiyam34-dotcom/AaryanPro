import React, { useState } from 'react';
import {
  Laptop,
  Cpu,
  HardDrive,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Battery,
  Bell,
  Check,
  Copy,
  Sliders,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface SystemSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const SystemSection: React.FC<SystemSectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const [copied, setCopied] = useState(false);
  const [isCleaningStorage, setIsCleaningStorage] = useState(false);
  const [storageCleaned, setStorageCleaned] = useState(false);

  const handleCopySpecs = () => {
    navigator.clipboard?.writeText(
      `Device name: DESKTOP-WIN11-PRO\nProcessor: 13th Gen Intel(R) Core(TM) i9-13900K @ 3.00 GHz\nInstalled RAM: 32.0 GB\nSystem type: 64-bit operating system, x64-based processor\nEdition: Windows 11 Pro 24H2\nOS build: 26100.1882`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCleanTemp = () => {
    setIsCleaningStorage(true);
    setTimeout(() => {
      setIsCleaningStorage(false);
      setStorageCleaned(true);
      setTimeout(() => setStorageCleaned(false), 3000);
    }, 1500);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">System</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Display, sound, notifications, power, storage, and device specifications
        </p>
      </div>

      {/* Top PC Specifications Banner */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-xl bg-blue-600/10 dark:bg-blue-500/20 text-blue-500 flex items-center justify-center shrink-0">
              <Laptop className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm">DESKTOP-WIN11-PRO</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 font-medium">
                  Active
                </span>
              </div>
              <div className="text-xs text-slate-400">
                13th Gen Intel(R) Core(TM) i9-13900K • 32.0 GB RAM
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCopySpecs}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
              copied
                ? 'bg-emerald-600 text-white border-emerald-600'
                : isDark
                ? 'border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'border-slate-300 hover:bg-slate-100 text-slate-800'
            }`}
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Specs Copied' : 'Copy Specs'}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-inherit text-xs">
          <div>
            <div className="text-[11px] text-slate-400">Processor</div>
            <div className="font-medium truncate">Intel i9-13900K</div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Installed RAM</div>
            <div className="font-medium">32.0 GB (31.8 GB usable)</div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">System type</div>
            <div className="font-medium">64-bit OS, x64</div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Pen and touch</div>
            <div className="font-medium">10 touch points</div>
          </div>
        </div>
      </div>

      {/* Display Settings Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <span className="font-semibold text-xs flex items-center space-x-1.5">
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Display & Brightness</span>
            </span>
            <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Adjust brightness, night light filter, and scale factor
            </p>
          </div>
        </div>

        {/* Brightness Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Brightness</span>
            <span className="font-semibold">{settings.brightness}%</span>
          </div>
          <div className="flex items-center space-x-3">
            <Sun className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="range"
              min={10}
              max={100}
              value={settings.brightness}
              onChange={(e) => onUpdateSettings({ brightness: Number(e.target.value) })}
              className="w-full accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Night Light Toggle */}
        <div className="pt-2 border-t border-inherit flex items-center justify-between">
          <div>
            <div className="font-semibold text-xs">Night light</div>
            <div className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Use warmer colors to help reduce eye strain at night
            </div>
          </div>
          <button
            type="button"
            onClick={() => onUpdateSettings({ nightLight: !settings.nightLight })}
            className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
              settings.nightLight ? 'bg-blue-600' : 'bg-slate-600'
            }`}
          >
            <div
              className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                settings.nightLight ? 'left-5.5' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Resolution & Scale */}
        <div className="pt-2 border-t border-inherit grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-[11px] text-slate-400 mb-1 block">Display Resolution</label>
            <select
              defaultValue="1920x1080"
              className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="1920x1080">1920 x 1080 (Recommended)</option>
              <option value="2560x1440">2560 x 1440 (2K QHD)</option>
              <option value="3840x2160">3840 x 2160 (4K UHD)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 mb-1 block">Scale (Layout)</label>
            <select
              defaultValue="100"
              className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="100">100% (Recommended)</option>
              <option value="125">125%</option>
              <option value="150">150%</option>
            </select>
          </div>
        </div>
      </div>

      {/* Sound Settings Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <span className="font-semibold text-xs flex items-center space-x-1.5">
              <Volume2 className="w-4 h-4 text-emerald-500" />
              <span>Sound & Audio Output</span>
            </span>
            <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Choose where to play sound and set volume levels
            </p>
          </div>
        </div>

        {/* Master Volume */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Master Volume</span>
            <span className="font-semibold">{settings.volume}%</span>
          </div>
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => onUpdateSettings({ volume: settings.volume === 0 ? 50 : 0 })}
              className="text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              {settings.volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.volume}
              onChange={(e) => onUpdateSettings({ volume: Number(e.target.value) })}
              className="w-full accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Output Device */}
        <div className="pt-2 border-t border-inherit">
          <label className="text-[11px] text-slate-400 mb-1 block">Output Device</label>
          <select
            defaultValue="speakers"
            className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
            }`}
          >
            <option value="speakers">Realtek High Definition Audio (Speakers)</option>
            <option value="headphones">Surface Precision Headphones (Bluetooth)</option>
            <option value="display">Digital Audio (DisplayPort 1.4)</option>
          </select>
        </div>
      </div>

      {/* Storage Meter Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <HardDrive className="w-4 h-4 text-blue-500" />
            <span className="font-semibold text-xs">Local Disk (C:) Storage</span>
          </div>
          <button
            type="button"
            onClick={handleCleanTemp}
            disabled={isCleaningStorage}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium border cursor-pointer transition-all ${
              storageCleaned
                ? 'bg-emerald-600 text-white border-emerald-600'
                : isDark
                ? 'border-slate-700 hover:bg-slate-800 text-slate-300'
                : 'border-slate-300 hover:bg-slate-100 text-slate-700'
            }`}
          >
            {isCleaningStorage ? 'Cleaning...' : storageCleaned ? 'Temporary Files Cleaned ✓' : 'Clean up recommendations'}
          </button>
        </div>

        <div className="w-full h-3 rounded-full bg-slate-700/30 overflow-hidden">
          <div className="h-full bg-blue-600 rounded-full" style={{ width: '42%' }} />
        </div>

        <div className="flex justify-between text-[11px] text-slate-400">
          <span>418 GB used</span>
          <span>582 GB free of 1.0 TB NVMe SSD</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-inherit text-[11px]">
          <div>
            <span className="text-slate-400">Installed apps: </span>
            <span className="font-medium">128 GB</span>
          </div>
          <div>
            <span className="text-slate-400">Temporary files: </span>
            <span className="font-medium">{storageCleaned ? '0 MB' : '14.2 GB'}</span>
          </div>
          <div>
            <span className="text-slate-400">System & reserved: </span>
            <span className="font-medium">64 GB</span>
          </div>
          <div>
            <span className="text-slate-400">Documents: </span>
            <span className="font-medium">42 GB</span>
          </div>
        </div>
      </div>

      {/* Power & Battery Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Battery className="w-4 h-4 text-emerald-500" />
            <span className="font-semibold text-xs">Power & Battery</span>
          </div>
          <span className="text-xs text-emerald-500 font-semibold">94% • Fully Charged</span>
        </div>

        <div className="flex items-center justify-between pt-1">
          <div>
            <div className="font-semibold text-xs">Power mode</div>
            <div className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Optimize performance or energy consumption
            </div>
          </div>

          <select
            value={settings.powerMode || 'balanced'}
            onChange={(e) =>
              onUpdateSettings({ powerMode: e.target.value as 'balanced' | 'performance' | 'saver' })
            }
            className={`px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
            }`}
          >
            <option value="performance">Best performance</option>
            <option value="balanced">Balanced (Recommended)</option>
            <option value="saver">Best power efficiency</option>
          </select>
        </div>
      </div>
    </div>
  );
};
