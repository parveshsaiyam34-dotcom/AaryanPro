import React from 'react';
import {
  Laptop,
  Bluetooth,
  Wifi,
  Palette,
  Layers,
  User,
  Clock,
  Gamepad2,
  Accessibility,
  ShieldCheck,
  RefreshCw,
  ChevronRight,
} from 'lucide-react';
import { SettingsSectionId } from '../../../types';
import { SETTINGS_SECTIONS } from './types';

interface SettingsSidebarProps {
  activeSection: SettingsSectionId;
  onSelectSection: (id: SettingsSectionId) => void;
  isDark: boolean;
  accentColor: string;
}

const ICONS: Record<string, React.ElementType> = {
  Laptop,
  Bluetooth,
  Wifi,
  Palette,
  Layers,
  User,
  Clock,
  Gamepad2,
  Accessibility,
  ShieldCheck,
  RefreshCw,
};

export const SettingsSidebar: React.FC<SettingsSidebarProps> = ({
  activeSection,
  onSelectSection,
  isDark,
  accentColor,
}) => {
  return (
    <aside
      className={`w-52 sm:w-60 md:w-64 border-r flex flex-col shrink-0 overflow-y-auto select-none transition-colors ${
        isDark ? 'bg-slate-950/60 border-slate-800/80' : 'bg-slate-50/80 border-slate-200/80'
      }`}
    >
      {/* User profile card */}
      <div className="p-3 border-b border-inherit">
        <button
          type="button"
          onClick={() => onSelectSection('accounts')}
          className={`w-full flex items-center space-x-3 p-2 rounded-xl text-left transition-colors cursor-pointer group ${
            isDark ? 'hover:bg-slate-900/80' : 'hover:bg-slate-200/60'
          }`}
        >
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white shadow-xs shrink-0"
            style={{ backgroundColor: accentColor }}
          >
            AD
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center space-x-1.5">
              <span className="font-semibold text-xs truncate">Administrator</span>
            </div>
            <div className="text-[11px] text-slate-400 truncate">parveshsaiyam34@gmail.com</div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>
      </div>

      {/* Navigation Sections */}
      <nav className="p-2 space-y-0.5 flex-1">
        {SETTINGS_SECTIONS.map((sec) => {
          const IconComp = ICONS[sec.iconName] || Laptop;
          const isSelected = activeSection === sec.id;

          return (
            <button
              key={sec.id}
              type="button"
              onClick={() => onSelectSection(sec.id)}
              className={`w-full flex items-center space-x-3 px-2.5 py-2 rounded-xl text-left text-xs transition-all relative cursor-pointer group ${
                isSelected
                  ? isDark
                    ? 'bg-slate-800/90 text-white font-medium shadow-xs'
                    : 'bg-white text-slate-900 font-medium shadow-xs border border-slate-200/60'
                  : isDark
                  ? 'text-slate-300 hover:bg-slate-900/60 hover:text-white'
                  : 'text-slate-700 hover:bg-slate-200/60 hover:text-slate-900'
              }`}
            >
              {/* Active Left Indicator Pill */}
              {isSelected && (
                <div
                  className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full transition-all"
                  style={{ backgroundColor: accentColor }}
                />
              )}

              {/* Icon Container with subtle color tint */}
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${sec.colorClass}`}
              >
                <IconComp className="w-4 h-4" />
              </div>

              <span className="truncate flex-1 font-medium">{sec.title}</span>

              {sec.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-medium shrink-0">
                  {sec.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </aside>
  );
};
