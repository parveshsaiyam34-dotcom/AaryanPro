import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  MapPin,
  Camera,
  Mic,
  Lock,
  Eye,
  Check,
  RefreshCw,
  Search,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface PrivacySecuritySectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const PrivacySecuritySection: React.FC<PrivacySecuritySectionProps> = ({
  isDark,
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanComplete, setScanComplete] = useState(false);

  const [locationPerm, setLocationPerm] = useState(true);
  const [cameraPerm, setCameraPerm] = useState(true);
  const [micPerm, setMicPerm] = useState(true);

  const [advertisingId, setAdvertisingId] = useState(false);
  const [diagnosticData, setDiagnosticData] = useState(false);

  const handleQuickScan = () => {
    setIsScanning(true);
    setScanProgress(0);
    setScanComplete(false);

    let p = 0;
    const interval = setInterval(() => {
      p += 15;
      if (p >= 100) {
        clearInterval(interval);
        setScanProgress(100);
        setIsScanning(false);
        setScanComplete(true);
      } else {
        setScanProgress(p);
      }
    }, 200);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Privacy & security</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Windows Security defense, virus threat scans, diagnostic feedback, and app permissions
        </p>
      </div>

      {/* Windows Security Status Banner */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-500 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm">Security at a glance</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 font-semibold">
                  Protected
                </span>
              </div>
              <div className="text-xs text-slate-400">
                No active threats found. Microsoft Defender Antivirus definition up to date.
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleQuickScan}
            disabled={isScanning}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
              isDark
                ? 'border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'border-slate-300 hover:bg-slate-100 text-slate-800'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? `Scanning (${scanProgress}%)...` : 'Quick scan'}</span>
          </button>
        </div>

        {/* Scan Progress Bar & Feedback */}
        {isScanning && (
          <div className="mt-3 pt-3 border-t border-inherit space-y-1.5">
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Scanning system directories and active processes...</span>
              <span>{Math.floor(scanProgress * 128)} files scanned</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-700/30 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-200"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
          </div>
        )}

        {scanComplete && (
          <div className="mt-3 pt-3 border-t border-inherit text-xs text-emerald-500 flex items-center space-x-1.5">
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>Scan finished: 0 threats detected across 12,800 scanned files.</span>
          </div>
        )}
      </div>

      {/* Protection Areas */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-2.5 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs">Security Pillars</span>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center space-x-3">
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
            <div>
              <div className="font-medium">Virus & threat protection</div>
              <div className="text-[10px] text-slate-400">Real-time protection turned on</div>
            </div>
          </div>

          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center space-x-3">
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
            <div>
              <div className="font-medium">Firewall & network protection</div>
              <div className="text-[10px] text-slate-400">Domain, private & public networks secure</div>
            </div>
          </div>

          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center space-x-3">
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
            <div>
              <div className="font-medium">App & browser control</div>
              <div className="text-[10px] text-slate-400">Reputation-based protection active</div>
            </div>
          </div>

          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center space-x-3">
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
            <div>
              <div className="font-medium">Device security</div>
              <div className="text-[10px] text-slate-400">Core isolation & TPM 2.0 active</div>
            </div>
          </div>
        </div>
      </div>

      {/* App Permissions Card (Location, Camera, Microphone) */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs">App Permissions</span>

        <div className="space-y-3 pt-1 text-xs">
          {/* Location */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <MapPin className="w-4 h-4 text-rose-500" />
              <div>
                <div className="font-medium">Location</div>
                <div className="text-[11px] text-slate-400">Let apps access your device location (Maps, Weather)</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setLocationPerm(!locationPerm)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                locationPerm ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  locationPerm ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Camera */}
          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div className="flex items-center space-x-3">
              <Camera className="w-4 h-4 text-sky-500" />
              <div>
                <div className="font-medium">Camera</div>
                <div className="text-[11px] text-slate-400">Let apps access your webcam</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setCameraPerm(!cameraPerm)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                cameraPerm ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  cameraPerm ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Microphone */}
          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div className="flex items-center space-x-3">
              <Mic className="w-4 h-4 text-amber-500" />
              <div>
                <div className="font-medium">Microphone</div>
                <div className="text-[11px] text-slate-400">Let apps use your microphone (Copilot Voice)</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMicPerm(!micPerm)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                micPerm ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  micPerm ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Windows Diagnostic Permissions */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs">Windows Permissions</span>

        <div className="space-y-3 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Advertising ID</div>
              <div className="text-[11px] text-slate-400">Let apps use advertising ID for personalized experiences</div>
            </div>
            <button
              type="button"
              onClick={() => setAdvertisingId(!advertisingId)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                advertisingId ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  advertisingId ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div>
              <div className="font-medium">Send optional diagnostic data</div>
              <div className="text-[11px] text-slate-400">Help improve Windows by sending additional telemetry</div>
            </div>
            <button
              type="button"
              onClick={() => setDiagnosticData(!diagnosticData)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                diagnosticData ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  diagnosticData ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
