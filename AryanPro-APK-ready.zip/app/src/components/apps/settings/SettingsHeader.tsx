import React, { useState, useRef, useEffect } from 'react';
import { Search, ChevronRight, X, ArrowLeft } from 'lucide-react';
import { SettingsSectionId } from '../../../types';
import { SETTINGS_SECTIONS } from './types';

interface SettingsHeaderProps {
  activeSection: SettingsSectionId;
  onSelectSection: (id: SettingsSectionId) => void;
  isDark: boolean;
  accentColor: string;
  canGoBack?: boolean;
  onBack?: () => void;
}

export const SettingsHeader: React.FC<SettingsHeaderProps> = ({
  activeSection,
  onSelectSection,
  isDark,
  accentColor,
  canGoBack,
  onBack,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const currentSection = SETTINGS_SECTIONS.find((s) => s.id === activeSection) || SETTINGS_SECTIONS[0];

  // Filter matching sections based on title, subtitle, or keywords
  const filteredSections = searchQuery.trim()
    ? SETTINGS_SECTIONS.filter((sec) => {
        const query = searchQuery.toLowerCase();
        return (
          sec.title.toLowerCase().includes(query) ||
          sec.subtitle.toLowerCase().includes(query) ||
          sec.keywords.some((k) => k.toLowerCase().includes(query))
        );
      })
    : [];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header
      className={`h-13 px-4 border-b flex items-center justify-between shrink-0 select-none transition-colors ${
        isDark ? 'bg-slate-950/70 border-slate-800' : 'bg-white/90 border-slate-200'
      }`}
    >
      {/* Breadcrumb Navigation */}
      <div className="flex items-center space-x-2 text-xs">
        {canGoBack && (
          <button
            type="button"
            onClick={onBack}
            className={`p-1 rounded-md transition-colors cursor-pointer mr-1 ${
              isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-700'
            }`}
            title="Go back"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        )}

        <button
          type="button"
          onClick={() => onSelectSection('system')}
          className={`flex items-center space-x-1 font-medium transition-colors cursor-pointer ${
            isDark ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Settings</span>
        </button>

        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />

        <span className="font-semibold text-xs text-slate-900 dark:text-slate-100 truncate">
          {currentSection.title}
        </span>
      </div>

      {/* Global Setting Search */}
      <div ref={searchContainerRef} className="relative w-52 sm:w-72">
        <div
          className={`flex items-center px-3 py-1.5 rounded-lg border text-xs transition-all ${
            isSearchOpen
              ? 'ring-2 ring-blue-500/30'
              : ''
          } ${
            isDark
              ? 'bg-slate-900 border-slate-700/80 text-slate-200'
              : 'bg-slate-100/90 border-slate-300/80 text-slate-800'
          }`}
        >
          <Search className="w-3.5 h-3.5 text-slate-400 mr-2 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setIsSearchOpen(true);
            }}
            onFocus={() => setIsSearchOpen(true)}
            placeholder="Find a setting"
            className="w-full bg-transparent border-0 focus:outline-hidden text-xs placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="p-0.5 rounded hover:bg-slate-700/30 text-slate-400 cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Search Results Dropdown */}
        {isSearchOpen && searchQuery.trim() && (
          <div
            className={`absolute right-0 top-full mt-1.5 w-80 rounded-xl shadow-xl border p-1.5 z-50 max-h-72 overflow-y-auto ${
              isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            <div className="text-[11px] font-medium px-2 py-1 text-slate-400">
              Matching Settings ({filteredSections.length})
            </div>

            {filteredSections.length === 0 ? (
              <div className="p-3 text-center text-slate-400 text-xs">
                No setting found for "{searchQuery}"
              </div>
            ) : (
              filteredSections.map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => {
                    onSelectSection(sec.id);
                    setIsSearchOpen(false);
                    setSearchQuery('');
                  }}
                  className={`w-full flex items-start space-x-2.5 p-2 rounded-lg text-left cursor-pointer transition-colors ${
                    isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className={`p-1.5 rounded-md shrink-0 ${sec.colorClass}`}>
                    <Search className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-xs leading-tight">{sec.title}</div>
                    <div className="text-[11px] text-slate-400 truncate">{sec.subtitle}</div>
                  </div>
                </button>
              ))
            )}
          </div>
        )}
      </div>
    </header>
  );
};
