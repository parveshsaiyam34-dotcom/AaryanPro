import React, { useState, useEffect } from 'react';
import {
  Clock,
  Globe,
  RefreshCw,
  Check,
  Plus,
  Type,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface TimeLanguageSectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const TimeLanguageSection: React.FC<TimeLanguageSectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncDone, setSyncDone] = useState(false);

  const [autoTime, setAutoTime] = useState(settings.autoTime !== false);
  const [selectedTimeZone, setSelectedTimeZone] = useState(
    settings.timeZone || 'Pacific Standard Time (UTC-08:00)'
  );

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncDone(true);
      setTimeout(() => setSyncDone(false), 3000);
    }, 1200);
  };

  const formattedTime = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const formattedDate = currentTime.toLocaleDateString([], {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Time & language</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Date & time synchronization, language packs, regional formatting, and typing
        </p>
      </div>

      {/* Real-time Clock Banner */}
      <div
        className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-500 flex items-center justify-center shrink-0">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xl font-bold tracking-tight">{formattedTime}</div>
              <div className="text-xs text-slate-400">{formattedDate}</div>
              <div className="text-[11px] text-slate-500 mt-0.5">{selectedTimeZone}</div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleSync}
            disabled={isSyncing}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
              syncDone
                ? 'bg-emerald-600 text-white border-emerald-600'
                : isDark
                ? 'border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'border-slate-300 hover:bg-slate-100 text-slate-800'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : syncDone ? 'Clock Synced ✓' : 'Sync now'}</span>
          </button>
        </div>
      </div>

      {/* Date & Time Settings */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs">Date & Time Automation</span>

        <div className="space-y-3 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Set time automatically</div>
              <div className="text-[11px] text-slate-400">Synchronize clock with time.windows.com NTP server</div>
            </div>
            <button
              type="button"
              onClick={() => setAutoTime(!autoTime)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                autoTime ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  autoTime ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Time Zone Dropdown */}
          <div className="pt-2 border-t border-inherit">
            <label className="text-[11px] text-slate-400 mb-1 block">Time Zone</label>
            <select
              value={selectedTimeZone}
              onChange={(e) => {
                setSelectedTimeZone(e.target.value);
                onUpdateSettings({ timeZone: e.target.value });
              }}
              className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="Pacific Standard Time (UTC-08:00)">
                (UTC-08:00) Pacific Time (US & Canada)
              </option>
              <option value="Mountain Standard Time (UTC-07:00)">
                (UTC-07:00) Mountain Time (US & Canada)
              </option>
              <option value="Central Standard Time (UTC-06:00)">
                (UTC-06:00) Central Time (US & Canada)
              </option>
              <option value="Eastern Standard Time (UTC-05:00)">
                (UTC-05:00) Eastern Time (US & Canada)
              </option>
              <option value="Greenwich Mean Time (UTC+00:00)">
                (UTC+00:00) Dublin, Edinburgh, Lisbon, London
              </option>
              <option value="Central European Time (UTC+01:00)">
                (UTC+01:00) Amsterdam, Berlin, Bern, Rome, Paris
              </option>
              <option value="India Standard Time (UTC+05:30)">
                (UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi
              </option>
              <option value="Singapore Standard Time (UTC+08:00)">
                (UTC+08:00) Kuala Lumpur, Singapore, Beijing
              </option>
              <option value="Tokyo Standard Time (UTC+09:00)">
                (UTC+09:00) Osaka, Sapporo, Tokyo
              </option>
            </select>
          </div>
        </div>
      </div>

      {/* Language & Region */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="font-semibold text-xs flex items-center space-x-1.5">
            <Globe className="w-4 h-4 text-emerald-500" />
            <span>Preferred Languages</span>
          </span>
          <button
            type="button"
            className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg border text-xs font-medium cursor-pointer ${
              isDark ? 'border-slate-700 hover:bg-slate-800 text-slate-200' : 'border-slate-300 hover:bg-slate-100 text-slate-800'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add a language</span>
          </button>
        </div>

        <div className="space-y-2 text-xs pt-1">
          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div>
              <div className="font-semibold">English (United States)</div>
              <div className="text-[10px] text-slate-400">
                Default display language • Text-to-speech • Speech recognition • Handwriting
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-500 font-semibold">
              Default
            </span>
          </div>

          <div className="p-3 rounded-xl border border-inherit bg-slate-500/5 flex items-center justify-between">
            <div>
              <div className="font-semibold">English (United Kingdom)</div>
              <div className="text-[10px] text-slate-400">Basic typing keyboard</div>
            </div>
            <span className="text-[10px] text-slate-400">Installed</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-inherit">
          <div>
            <label className="text-[11px] text-slate-400 mb-1 block">Country or region</label>
            <select
              defaultValue="US"
              className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="US">United States</option>
              <option value="UK">United Kingdom</option>
              <option value="CA">Canada</option>
              <option value="IN">India</option>
              <option value="AU">Australia</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 mb-1 block">Regional format</label>
            <select
              defaultValue="en-US"
              className={`w-full px-3 py-1.5 rounded-lg border text-xs cursor-pointer ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="en-US">Recommended [English (United States)]</option>
              <option value="en-GB">English (United Kingdom)</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
