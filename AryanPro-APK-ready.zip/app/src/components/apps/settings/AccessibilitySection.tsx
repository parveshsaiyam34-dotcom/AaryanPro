import React, { useState } from 'react';
import {
  Accessibility,
  Type,
  Eye,
  Mouse,
  Volume2,
  Keyboard,
  Check,
} from 'lucide-react';
import { SystemSettings } from '../../../types';

interface AccessibilitySectionProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  isDark: boolean;
}

export const AccessibilitySection: React.FC<AccessibilitySectionProps> = ({
  settings,
  onUpdateSettings,
  isDark,
}) => {
  const [textScale, setTextScale] = useState(settings.textScale || 100);
  const [textApplied, setTextApplied] = useState(false);
  const [scrollbarsAlways, setScrollbarsAlways] = useState(true);
  const [animationEffects, setAnimationEffects] = useState(true);
  const [pointerSize, setPointerSize] = useState(1);
  const [pointerStyle, setPointerStyle] = useState<'white' | 'black' | 'inverted' | 'accent'>('white');
  const [monoAudio, setMonoAudio] = useState(false);
  const [stickyKeys, setStickyKeys] = useState(false);

  const handleApplyText = () => {
    onUpdateSettings({ textScale });
    setTextApplied(true);
    setTimeout(() => setTextApplied(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold tracking-tight">Accessibility</h1>
        <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Vision, text size scaling, mouse cursor customizations, audio, and keyboard aids
        </p>
      </div>

      {/* Text Size Scaling Card with Interactive Live Preview */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <span className="font-semibold text-xs flex items-center space-x-1.5">
              <Type className="w-4 h-4 text-teal-500" />
              <span>Text Size</span>
            </span>
            <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Make text bigger across Windows and apps
            </p>
          </div>

          <button
            type="button"
            onClick={handleApplyText}
            className={`px-3 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              textApplied
                ? 'bg-emerald-600 text-white'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {textApplied ? 'Applied ✓' : 'Apply'}
          </button>
        </div>

        {/* Live Interactive Text Size Preview Box */}
        <div
          className={`p-4 rounded-xl border transition-all select-none ${
            isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div
            className="transition-all duration-200 leading-snug"
            style={{ fontSize: `${(textScale / 100) * 14}px` }}
          >
            Make text bigger across your Windows 11 device. Preview how sentences and paragraphs scale smoothly.
          </div>
          <div className="text-[10px] text-slate-400 mt-2">
            Scaling at: <span className="font-semibold text-blue-500">{textScale}%</span>
          </div>
        </div>

        {/* Slider */}
        <div className="flex items-center space-x-3 pt-1">
          <span className="text-xs text-slate-400">A</span>
          <input
            type="range"
            min={100}
            max={225}
            step={5}
            value={textScale}
            onChange={(e) => setTextScale(Number(e.target.value))}
            className="w-full accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer"
          />
          <span className="text-base font-bold text-slate-400">A</span>
        </div>
      </div>

      {/* Visual Effects Card */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs flex items-center space-x-1.5">
          <Eye className="w-4 h-4 text-sky-500" />
          <span>Visual Effects</span>
        </span>

        <div className="space-y-3 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Always show scrollbars</div>
              <div className="text-[11px] text-slate-400">Keep scrollbars visible in Windows and apps</div>
            </div>
            <button
              type="button"
              onClick={() => setScrollbarsAlways(!scrollbarsAlways)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                scrollbarsAlways ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  scrollbarsAlways ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div>
              <div className="font-medium">Animation effects</div>
              <div className="text-[11px] text-slate-400">Show smooth window minimize and open animations</div>
            </div>
            <button
              type="button"
              onClick={() => setAnimationEffects(!animationEffects)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                animationEffects ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  animationEffects ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Mouse Pointer & Touch */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-4 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs flex items-center space-x-1.5">
          <Mouse className="w-4 h-4 text-violet-500" />
          <span>Mouse Pointer & Touch Indicator</span>
        </span>

        {/* Pointer Style Picker */}
        <div>
          <div className="text-[11px] text-slate-400 mb-2">Mouse pointer style</div>
          <div className="grid grid-cols-4 gap-2.5">
            <button
              type="button"
              onClick={() => setPointerStyle('white')}
              className={`p-2.5 rounded-xl border text-center cursor-pointer transition-all ${
                pointerStyle === 'white'
                  ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/10'
                  : 'border-slate-700 bg-slate-800/30'
              }`}
            >
              <div className="w-6 h-6 rounded-full bg-white border border-slate-400 mx-auto mb-1 flex items-center justify-center text-slate-900 text-[10px] font-bold">
                ↖
              </div>
              <div className="text-[10px] font-medium">White</div>
            </button>

            <button
              type="button"
              onClick={() => setPointerStyle('black')}
              className={`p-2.5 rounded-xl border text-center cursor-pointer transition-all ${
                pointerStyle === 'black'
                  ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/10'
                  : 'border-slate-700 bg-slate-800/30'
              }`}
            >
              <div className="w-6 h-6 rounded-full bg-black border border-slate-600 mx-auto mb-1 flex items-center justify-center text-white text-[10px] font-bold">
                ↖
              </div>
              <div className="text-[10px] font-medium">Black</div>
            </button>

            <button
              type="button"
              onClick={() => setPointerStyle('inverted')}
              className={`p-2.5 rounded-xl border text-center cursor-pointer transition-all ${
                pointerStyle === 'inverted'
                  ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/10'
                  : 'border-slate-700 bg-slate-800/30'
              }`}
            >
              <div className="w-6 h-6 rounded-full bg-gradient-to-r from-white to-black border border-slate-500 mx-auto mb-1 flex items-center justify-center text-[10px] font-bold">
                ↖
              </div>
              <div className="text-[10px] font-medium">Inverted</div>
            </button>

            <button
              type="button"
              onClick={() => setPointerStyle('accent')}
              className={`p-2.5 rounded-xl border text-center cursor-pointer transition-all ${
                pointerStyle === 'accent'
                  ? 'border-blue-500 ring-2 ring-blue-500/30 bg-blue-500/10'
                  : 'border-slate-700 bg-slate-800/30'
              }`}
            >
              <div
                className="w-6 h-6 rounded-full mx-auto mb-1 flex items-center justify-center text-white text-[10px] font-bold shadow-xs"
                style={{ backgroundColor: settings.accentColor }}
              >
                ↖
              </div>
              <div className="text-[10px] font-medium">Custom</div>
            </button>
          </div>
        </div>

        {/* Pointer Size */}
        <div className="space-y-1 pt-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Pointer size</span>
            <span className="font-semibold">{pointerSize}</span>
          </div>
          <input
            type="range"
            min={1}
            max={15}
            value={pointerSize}
            onChange={(e) => setPointerSize(Number(e.target.value))}
            className="w-full accent-blue-600 h-1.5 bg-slate-700/30 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* Hearing & Keyboard */}
      <div
        className={`p-4 rounded-2xl border transition-colors space-y-3 ${
          isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <span className="font-semibold text-xs flex items-center space-x-1.5">
          <Keyboard className="w-4 h-4 text-emerald-500" />
          <span>Hearing & Keyboard Accessibility</span>
        </span>

        <div className="space-y-3 pt-1 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Mono audio</div>
              <div className="text-[11px] text-slate-400">Combine left and right audio channels into one</div>
            </div>
            <button
              type="button"
              onClick={() => setMonoAudio(!monoAudio)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                monoAudio ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  monoAudio ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-inherit">
            <div>
              <div className="font-medium">Sticky keys</div>
              <div className="text-[11px] text-slate-400">
                Press one key at a time for keyboard shortcuts (Shift 5 times)
              </div>
            </div>
            <button
              type="button"
              onClick={() => setStickyKeys(!stickyKeys)}
              className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                stickyKeys ? 'bg-blue-600' : 'bg-slate-600'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-transform ${
                  stickyKeys ? 'left-5.5' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
