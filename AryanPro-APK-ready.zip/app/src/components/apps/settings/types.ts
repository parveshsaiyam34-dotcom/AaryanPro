import { SettingsSectionId } from '../../../types';

export interface SettingsSectionMeta {
  id: SettingsSectionId;
  title: string;
  subtitle: string;
  iconName: string;
  colorClass: string;
  badge?: string;
  keywords: string[];
}

export const SETTINGS_SECTIONS: SettingsSectionMeta[] = [
  {
    id: 'system',
    title: 'System',
    subtitle: 'Display, sound, notifications, power, storage',
    iconName: 'Laptop',
    colorClass: 'text-blue-500 bg-blue-500/10 dark:bg-blue-500/20',
    keywords: ['display', 'sound', 'volume', 'brightness', 'night light', 'power', 'battery', 'storage', 'about', 'specs', 'cpu', 'ram'],
  },
  {
    id: 'bluetooth',
    title: 'Bluetooth & devices',
    subtitle: 'Bluetooth, printers, mouse, touchpad, phone link',
    iconName: 'Bluetooth',
    colorClass: 'text-sky-500 bg-sky-500/10 dark:bg-sky-500/20',
    keywords: ['bluetooth', 'devices', 'mouse', 'keyboard', 'headphones', 'printers', 'scanners', 'touchpad', 'phone link', 'pair'],
  },
  {
    id: 'network',
    title: 'Network & internet',
    subtitle: 'Wi-Fi, Ethernet, VPN, mobile hotspot, airplane mode',
    iconName: 'Wifi',
    colorClass: 'text-emerald-500 bg-emerald-500/10 dark:bg-emerald-500/20',
    keywords: ['wifi', 'wi-fi', 'internet', 'network', 'ethernet', 'vpn', 'hotspot', 'airplane mode', 'proxy', 'ip address', 'data usage'],
  },
  {
    id: 'personalization',
    title: 'Personalization',
    subtitle: 'Background, colors, themes, lock screen, taskbar',
    iconName: 'Palette',
    colorClass: 'text-pink-500 bg-pink-500/10 dark:bg-pink-500/20',
    keywords: ['personalization', 'wallpaper', 'background', 'theme', 'dark mode', 'light mode', 'accent color', 'taskbar', 'colors', 'lock screen'],
  },
  {
    id: 'apps',
    title: 'Apps',
    subtitle: 'Installed apps, default apps, startup apps',
    iconName: 'Layers',
    colorClass: 'text-violet-500 bg-violet-500/10 dark:bg-violet-500/20',
    keywords: ['apps', 'applications', 'installed apps', 'default apps', 'startup', 'programs', 'uninstall', 'edge', 'notepad', 'calculator'],
  },
  {
    id: 'accounts',
    title: 'Accounts',
    subtitle: 'Your info, sign-in options, email & accounts, backup',
    iconName: 'User',
    colorClass: 'text-indigo-500 bg-indigo-500/10 dark:bg-indigo-500/20',
    keywords: ['accounts', 'user', 'profile', 'admin', 'password', 'pin', 'windows hello', 'fingerprint', 'backup', 'onedrive', 'family'],
  },
  {
    id: 'time-language',
    title: 'Time & language',
    subtitle: 'Date & time, language & region, typing, speech',
    iconName: 'Clock',
    colorClass: 'text-amber-500 bg-amber-500/10 dark:bg-amber-500/20',
    keywords: ['time', 'date', 'clock', 'timezone', 'time zone', 'language', 'region', 'typing', 'speech', 'sync'],
  },
  {
    id: 'gaming',
    title: 'Gaming',
    subtitle: 'Game Bar, captures, game mode',
    iconName: 'Gamepad2',
    colorClass: 'text-lime-500 bg-lime-500/10 dark:bg-lime-500/20',
    keywords: ['gaming', 'game bar', 'xbox', 'captures', 'record', 'game mode', 'graphics', 'fps', 'hdr'],
  },
  {
    id: 'accessibility',
    title: 'Accessibility',
    subtitle: 'Text size, visual effects, mouse pointer, audio, captions',
    iconName: 'Accessibility',
    colorClass: 'text-teal-500 bg-teal-500/10 dark:bg-teal-500/20',
    keywords: ['accessibility', 'text size', 'visual effects', 'contrast', 'mouse pointer', 'magnifier', 'narrator', 'captions', 'sticky keys'],
  },
  {
    id: 'privacy-security',
    title: 'Privacy & security',
    subtitle: 'Windows security, app permissions, location, camera',
    iconName: 'ShieldCheck',
    colorClass: 'text-rose-500 bg-rose-500/10 dark:bg-rose-500/20',
    keywords: ['privacy', 'security', 'windows security', 'virus', 'threat', 'firewall', 'location', 'camera', 'microphone', 'permissions', 'scan'],
  },
  {
    id: 'windows-update',
    title: 'Windows Update',
    subtitle: 'Check for updates, update history, active hours',
    iconName: 'RefreshCw',
    colorClass: 'text-cyan-500 bg-cyan-500/10 dark:bg-cyan-500/20',
    keywords: ['update', 'windows update', 'check for updates', 'patch', 'version', 'restart'],
  },
];

export const PRESET_THEMES = [
  {
    id: 'win11-light',
    name: 'Windows Light',
    wallpaper: 'bloom-blue' as const,
    theme: 'light' as const,
    accentColor: '#0078d4',
    preview: 'bg-gradient-to-tr from-sky-400 via-blue-500 to-indigo-700',
  },
  {
    id: 'win11-dark',
    name: 'Windows Dark',
    wallpaper: 'bloom-dark' as const,
    theme: 'dark' as const,
    accentColor: '#0078d4',
    preview: 'bg-gradient-to-tr from-slate-900 via-indigo-950 to-blue-950',
  },
  {
    id: 'bloom-glow',
    name: 'Windows Glow',
    wallpaper: 'bloom-glow' as const,
    theme: 'dark' as const,
    accentColor: '#8b5cf6',
    preview: 'bg-gradient-to-tr from-violet-900 via-purple-800 to-emerald-700',
  },
  {
    id: 'captured-motion',
    name: 'Motion Flow',
    wallpaper: 'bloom-captured-motion' as const,
    theme: 'dark' as const,
    accentColor: '#f43f5e',
    preview: 'bg-gradient-to-tr from-fuchsia-900 via-pink-800 to-rose-700',
  },
  {
    id: 'sunrise-warmth',
    name: 'Sunrise Dawn',
    wallpaper: 'sunrise' as const,
    theme: 'light' as const,
    accentColor: '#ea580c',
    preview: 'bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-700',
  },
  {
    id: 'aurora-emerald',
    name: 'Northern Aurora',
    wallpaper: 'aurora' as const,
    theme: 'dark' as const,
    accentColor: '#10b981',
    preview: 'bg-gradient-to-tr from-emerald-800 via-teal-700 to-cyan-950',
  },
  {
    id: 'spotlight-nature',
    name: 'Spotlight Vista',
    wallpaper: 'spotlight' as const,
    theme: 'dark' as const,
    accentColor: '#06b6d4',
    preview: 'bg-gradient-to-tr from-sky-700 via-teal-800 to-emerald-900',
  },
  {
    id: 'cyber-minimal',
    name: 'Midnight Carbon',
    wallpaper: 'cyber' as const,
    theme: 'dark' as const,
    accentColor: '#6366f1',
    preview: 'bg-gradient-to-tr from-zinc-950 via-neutral-900 to-slate-900',
  },
];

export const ACCENT_COLOR_PALETTE = [
  { name: 'Windows Blue', value: '#0078d4' },
  { name: 'Cobalt Indigo', value: '#6366f1' },
  { name: 'Emerald Mint', value: '#10b981' },
  { name: 'Amethyst Purple', value: '#8b5cf6' },
  { name: 'Crimson Rose', value: '#f43f5e' },
  { name: 'Amber Glow', value: '#f59e0b' },
  { name: 'Sunset Coral', value: '#ea580c' },
  { name: 'Electric Cyan', value: '#06b6d4' },
  { name: 'Charcoal Slate', value: '#475569' },
];
