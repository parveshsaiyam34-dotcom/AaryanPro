import React, { useState, useRef, useEffect } from 'react';
import { FileText, Save, Plus, Copy, Check, Scissors } from 'lucide-react';
import { AppTheme } from '../../types';

interface NotepadAppProps {
  theme: AppTheme;
  initialFileName?: string;
  initialContent?: string;
  onSave?: (name: string, content: string) => void;
}

export const NotepadApp: React.FC<NotepadAppProps> = ({
  theme,
  initialFileName = 'Untitled.txt',
  initialContent = 'Welcome to Windows 11 Notepad!\n\nYou can take notes here, edit documents from File Explorer, or draft code.\nFeatures:\n- Word count and cursor line/column tracking\n- Standard Windows (CRLF) and UTF-8 encoding support\n- Fast and responsive text editing',
}) => {
  const isDark = theme === 'dark';
  const [fileName, setFileName] = useState(initialFileName);
  const [content, setContent] = useState(initialContent);
  const [isModified, setIsModified] = useState(false);
  const [lineCol, setLineCol] = useState({ line: 1, col: 1 });
  const [showSavedToast, setShowSavedToast] = useState(false);
  const [wordWrap, setWordWrap] = useState(true);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    if (initialContent) {
      setContent(initialContent);
      setFileName(initialFileName);
      setIsModified(false);
    }
  }, [initialContent, initialFileName]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setIsModified(true);
    updateCursorPos(e.target);
  };

  const updateCursorPos = (el: HTMLTextAreaElement) => {
    const textBeforeCursor = el.value.substring(0, el.selectionStart);
    const lines = textBeforeCursor.split('\n');
    const curLine = lines.length;
    const curCol = lines[lines.length - 1].length + 1;
    setLineCol({ line: curLine, col: curCol });
  };

  const handleSave = () => {
    setIsModified(false);
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2000);
  };

  const handleNew = () => {
    setFileName('Untitled.txt');
    setContent('');
    setIsModified(false);
  };

  return (
    <div
      className={`h-full w-full flex flex-col select-none text-xs transition-colors ${
        isDark ? 'bg-[#1e1e1e] text-slate-100' : 'bg-white text-slate-900'
      }`}
    >
      {/* Top Menu Bar */}
      <div
        className={`px-3 py-1.5 border-b flex items-center justify-between shrink-0 ${
          isDark ? 'bg-[#252526] border-[#333333] text-slate-300' : 'bg-slate-100/90 border-slate-200 text-slate-700'
        }`}
      >
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5">
            <FileText className="w-4 h-4 text-blue-500" />
            <span className="font-semibold text-xs">
              {fileName} {isModified ? '•' : ''}
            </span>
          </div>

          <div className="flex items-center space-x-1 text-xs">
            <button
              type="button"
              onClick={handleNew}
              className={`px-2 py-0.5 rounded hover:bg-slate-700/20 cursor-pointer ${
                isDark ? 'hover:bg-[#37373d]' : 'hover:bg-slate-200'
              }`}
            >
              New
            </button>
            <button
              type="button"
              onClick={handleSave}
              className={`px-2 py-0.5 rounded hover:bg-slate-700/20 cursor-pointer flex items-center space-x-1 ${
                isDark ? 'hover:bg-[#37373d]' : 'hover:bg-slate-200'
              }`}
            >
              <Save className="w-3 h-3" />
              <span>Save</span>
            </button>
            <button
              type="button"
              onClick={() => setWordWrap(!wordWrap)}
              className={`px-2 py-0.5 rounded hover:bg-slate-700/20 cursor-pointer ${
                isDark ? 'hover:bg-[#37373d]' : 'hover:bg-slate-200'
              } ${wordWrap ? 'text-blue-500 font-medium' : ''}`}
            >
              Word Wrap
            </button>
          </div>
        </div>

        {showSavedToast && (
          <div className="flex items-center space-x-1 text-emerald-500 text-[11px] font-medium animate-in fade-in">
            <Check className="w-3.5 h-3.5" />
            <span>Saved</span>
          </div>
        )}
      </div>

      {/* Editor Body */}
      <div className="flex-1 relative overflow-hidden select-text">
        <textarea
          ref={textareaRef}
          value={content}
          onChange={handleTextChange}
          onKeyUp={(e) => updateCursorPos(e.currentTarget)}
          onClick={(e) => updateCursorPos(e.currentTarget)}
          className={`w-full h-full p-4 font-mono text-xs sm:text-[13px] leading-relaxed resize-none border-0 focus:outline-hidden ${
            wordWrap ? 'whitespace-pre-wrap' : 'whitespace-pre overflow-x-auto'
          } ${isDark ? 'bg-[#1e1e1e] text-slate-100 placeholder-slate-500' : 'bg-white text-slate-900 placeholder-slate-400'}`}
          placeholder="Type here..."
          spellCheck={false}
        />
      </div>

      {/* Status Bar */}
      <div
        className={`px-4 py-1 border-t text-[11px] flex items-center justify-between shrink-0 select-none ${
          isDark ? 'bg-[#252526] border-[#333333] text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-600'
        }`}
      >
        <div className="flex items-center space-x-4">
          <span>
            Ln {lineCol.line}, Col {lineCol.col}
          </span>
          <span>{content.length} characters</span>
        </div>

        <div className="flex items-center space-x-4">
          <span>100%</span>
          <span>Windows (CRLF)</span>
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  );
};
