import React, { useState, useEffect, useCallback } from 'react';
import { Power, Lock, Moon, RotateCcw, Sparkles, Wifi, BatteryCharging } from 'lucide-react';
import {
  WindowState,
  AppId,
  SystemSettings,
  WallpaperId,
  AppTheme,
} from './types';
import { WallpaperBackground } from './components/desktop/WallpaperBackground';
import { Desktop } from './components/desktop/Desktop';
import { WindowManager } from './components/windows/WindowManager';
import { Taskbar } from './components/taskbar/Taskbar';
import { StartMenu } from './components/taskbar/StartMenu';
import { SearchFlyout } from './components/taskbar/SearchFlyout';
import { QuickSettingsFlyout } from './components/taskbar/QuickSettingsFlyout';
import { CalendarFlyout } from './components/taskbar/CalendarFlyout';

const DEFAULT_WINDOWS: WindowState[] = [
  {
    id: 'win-copilot',
    appId: 'copilot',
    title: 'Copilot',
    isOpen: true,
    isMinimized: false,
    isMaximized: false,
    zIndex: 10,
    x: 180,
    y: 40,
    width: 680,
    height: 540,
    minWidth: 360,
    minHeight: 400,
  },
  {
    id: 'win-explorer',
    appId: 'explorer',
    title: 'File Explorer',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 9,
    x: 100,
    y: 60,
    width: 680,
    height: 480,
    minWidth: 400,
    minHeight: 320,
  },
  {
    id: 'win-settings',
    appId: 'settings',
    title: 'Settings',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 8,
    x: 140,
    y: 70,
    width: 680,
    height: 500,
    minWidth: 450,
    minHeight: 350,
  },
  {
    id: 'win-notepad',
    appId: 'notepad',
    title: 'Notepad',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 7,
    x: 220,
    y: 90,
    width: 560,
    height: 420,
    minWidth: 300,
    minHeight: 250,
  },
  {
    id: 'win-calculator',
    appId: 'calculator',
    title: 'Calculator',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 6,
    x: 260,
    y: 100,
    width: 340,
    height: 480,
    minWidth: 280,
    minHeight: 400,
  },
  {
    id: 'win-browser',
    appId: 'browser',
    title: 'Microsoft Edge',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 5,
    x: 80,
    y: 40,
    width: 760,
    height: 540,
    minWidth: 420,
    minHeight: 350,
  },
];

export default function App() {
  // System Settings State
  const [settings, setSettings] = useState<SystemSettings>(() => {
    let initialTheme: AppTheme = 'dark';
    try {
      const savedTheme = localStorage.getItem('win11_theme');
      if (savedTheme === 'light' || savedTheme === 'dark') {
        initialTheme = savedTheme;
      }
    } catch {
      // ignore
    }

    return {
      theme: initialTheme,
      wallpaper: initialTheme === 'dark' ? 'bloom-dark' : 'bloom-blue',
      accentColor: '#0078d4',
      taskbarAlignment: 'center',
      volume: 80,
      brightness: 100,
      wifiEnabled: true,
      bluetoothEnabled: true,
      nightLight: false,
      transparencyEffects: true,
      showAccentOnTaskbar: true,
      showAccentOnTitleBars: false,
      taskbarSearch: 'box',
      taskbarWidgets: true,
      taskbarCopilot: true,
      taskbarBadges: true,
      autoHideTaskbar: false,
      gameMode: true,
      powerMode: 'balanced',
      textScale: 100,
      timeZone: 'Pacific Standard Time (UTC-08:00)',
      autoTime: true,
    };
  });

  // Windows State
  const [windows, setWindows] = useState<WindowState[]>(DEFAULT_WINDOWS);
  const [activeWindowId, setActiveWindowId] = useState<string | null>('win-copilot');
  const [maxZIndex, setMaxZIndex] = useState(20);

  // Taskbar Flyout States
  const [isStartMenuOpen, setIsStartMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isQuickSettingsOpen, setIsQuickSettingsOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  // Power action notification toast and system state
  const [powerToast, setPowerToast] = useState<string | null>(null);
  const [systemState, setSystemState] = useState<'normal' | 'sleep' | 'restarting' | 'shutting-down' | 'turned-off' | 'lock'>('normal');

  // Live lock screen clock
  const [lockTime, setLockTime] = useState('');
  const [lockDate, setLockDate] = useState('');

  useEffect(() => {
    const updateLockTime = () => {
      const now = new Date();
      setLockTime(now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
      setLockDate(now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' }));
    };
    updateLockTime();
    const interval = setInterval(updateLockTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Sync theme to root class & localStorage
  useEffect(() => {
    try {
      localStorage.setItem('win11_theme', settings.theme);
      if (settings.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch {
      // ignore
    }
  }, [settings.theme]);

  // Close all flyouts when clicking background
  const closeAllFlyouts = useCallback(() => {
    setIsStartMenuOpen(false);
    setIsSearchOpen(false);
    setIsQuickSettingsOpen(false);
    setIsCalendarOpen(false);
  }, []);

  const handleUpdateSettings = (newPartial: Partial<SystemSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...newPartial };
      // Auto-adjust wallpaper if theme changed and user was on default bloom
      if (newPartial.theme && !newPartial.wallpaper) {
        if (newPartial.theme === 'dark' && prev.wallpaper === 'bloom-blue') {
          next.wallpaper = 'bloom-dark';
        } else if (newPartial.theme === 'light' && prev.wallpaper === 'bloom-dark') {
          next.wallpaper = 'bloom-blue';
        }
      }
      return next;
    });
  };

  // Focus Window
  const focusWindow = (id: string) => {
    const nextZ = maxZIndex + 1;
    setMaxZIndex(nextZ);
    setActiveWindowId(id);
    setWindows((prev) =>
      prev.map((w) =>
        w.id === id ? { ...w, isMinimized: false, zIndex: nextZ } : w
      )
    );
    closeAllFlyouts();
  };

  // Open App
  const openApp = (appId: AppId, customData?: any) => {
    closeAllFlyouts();
    const existing = windows.find((w) => w.appId === appId);
    const nextZ = maxZIndex + 1;
    setMaxZIndex(nextZ);

    if (existing) {
      setWindows((prev) =>
        prev.map((w) =>
          w.appId === appId
            ? {
                ...w,
                isOpen: true,
                isMinimized: false,
                zIndex: nextZ,
                customData: customData !== undefined ? customData : w.customData,
              }
            : w
        )
      );
      setActiveWindowId(existing.id);
    }
  };

  // Taskbar Icon Click Behavior
  const handleTaskbarAppClick = (appId: AppId) => {
    closeAllFlyouts();
    const targetWin = windows.find((w) => w.appId === appId);
    if (!targetWin) return;

    if (!targetWin.isOpen) {
      openApp(appId);
    } else if (targetWin.isMinimized) {
      focusWindow(targetWin.id);
    } else if (activeWindowId === targetWin.id) {
      // Toggle minimize if already active
      setWindows((prev) =>
        prev.map((w) => (w.id === targetWin.id ? { ...w, isMinimized: true } : w))
      );
      setActiveWindowId(null);
    } else {
      // Bring to front
      focusWindow(targetWin.id);
    }
  };

  // Close Window
  const closeWindow = (id: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, isOpen: false, isMinimized: false } : w))
    );
    if (activeWindowId === id) {
      setActiveWindowId(null);
    }
  };

  // Minimize Window
  const minimizeWindow = (id: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, isMinimized: true } : w))
    );
    if (activeWindowId === id) {
      setActiveWindowId(null);
    }
  };

  // Maximize / Restore
  const toggleMaximizeWindow = (id: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, isMaximized: !w.isMaximized } : w))
    );
    focusWindow(id);
  };

  // Position update
  const updateWindowPosition = (id: string, x: number, y: number) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, x, y } : w))
    );
  };

  // Size update
  const updateWindowSize = (id: string, width: number, height: number) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, width, height } : w))
    );
  };

  // Show Desktop Peek button
  const handleShowDesktop = () => {
    const hasVisible = windows.some((w) => w.isOpen && !w.isMinimized);
    if (hasVisible) {
      setWindows((prev) => prev.map((w) => ({ ...w, isMinimized: true })));
      setActiveWindowId(null);
    } else {
      setWindows((prev) => prev.map((w) => ({ ...w, isMinimized: false })));
    }
    closeAllFlyouts();
  };

  // Open file in Notepad from FileExplorer
  const handleOpenFileInNotepad = (fileName: string, content: string) => {
    openApp('notepad', { fileName, content });
  };

  // Power Action simulation
  const handlePowerAction = (action: 'restart' | 'shutdown' | 'sleep' | 'lock') => {
    closeAllFlyouts();
    if (action === 'sleep') {
      setSystemState('sleep');
    } else if (action === 'lock') {
      setSystemState('lock');
    } else if (action === 'restart') {
      setSystemState('restarting');
      setTimeout(() => {
        setSystemState('normal');
        setPowerToast('Windows 11 restarted successfully');
        setTimeout(() => setPowerToast(null), 2500);
      }, 2500);
    } else if (action === 'shutdown') {
      setSystemState('shutting-down');
      setTimeout(() => {
        setSystemState('turned-off');
      }, 1800);
    }
  };

  return (
    <div
      onClick={closeAllFlyouts}
      className={`relative w-screen h-screen overflow-hidden select-none font-sans transition-colors ${
        settings.theme === 'dark' ? 'text-slate-100' : 'text-slate-900'
      }`}
    >
      {/* Dynamic Windows 11 Wallpaper */}
      <WallpaperBackground wallpaper={settings.wallpaper} />

      {/* Desktop Canvas with Desktop Icons & Right-Click Context Menu */}
      <Desktop
        settings={settings}
        onOpenApp={openApp}
        onRefreshDesktop={() => {
          setPowerToast('Desktop refreshed');
          setTimeout(() => setPowerToast(null), 1500);
        }}
      />

      {/* Draggable and Resizable Windows Layer */}
      <WindowManager
        windows={windows}
        activeWindowId={activeWindowId}
        settings={settings}
        onFocusWindow={focusWindow}
        onCloseWindow={closeWindow}
        onMinimizeWindow={minimizeWindow}
        onToggleMaximizeWindow={toggleMaximizeWindow}
        onUpdatePosition={updateWindowPosition}
        onUpdateSize={updateWindowSize}
        onUpdateSettings={handleUpdateSettings}
        onOpenFileInNotepad={handleOpenFileInNotepad}
      />

      {/* Flyout: Start Menu */}
      <StartMenu
        isOpen={isStartMenuOpen}
        settings={settings}
        onClose={() => setIsStartMenuOpen(false)}
        onOpenApp={openApp}
        onPowerAction={handlePowerAction}
      />

      {/* Flyout: Search */}
      <SearchFlyout
        isOpen={isSearchOpen}
        settings={settings}
        onClose={() => setIsSearchOpen(false)}
        onOpenApp={openApp}
      />

      {/* Flyout: Quick Settings (Action Center) */}
      <QuickSettingsFlyout
        isOpen={isQuickSettingsOpen}
        settings={settings}
        onClose={() => setIsQuickSettingsOpen(false)}
        onUpdateSettings={handleUpdateSettings}
        onOpenApp={openApp}
      />

      {/* Flyout: Calendar & Notification Drawer */}
      <CalendarFlyout
        isOpen={isCalendarOpen}
        settings={settings}
        onClose={() => setIsCalendarOpen(false)}
      />

      {/* Taskbar */}
      <Taskbar
        windows={windows}
        activeWindowId={activeWindowId}
        settings={settings}
        isStartMenuOpen={isStartMenuOpen}
        isSearchOpen={isSearchOpen}
        isQuickSettingsOpen={isQuickSettingsOpen}
        isCalendarOpen={isCalendarOpen}
        onToggleStartMenu={() => {
          setIsStartMenuOpen(!isStartMenuOpen);
          setIsSearchOpen(false);
          setIsQuickSettingsOpen(false);
          setIsCalendarOpen(false);
        }}
        onToggleSearch={() => {
          setIsSearchOpen(!isSearchOpen);
          setIsStartMenuOpen(false);
          setIsQuickSettingsOpen(false);
          setIsCalendarOpen(false);
        }}
        onToggleQuickSettings={() => {
          setIsQuickSettingsOpen(!isQuickSettingsOpen);
          setIsStartMenuOpen(false);
          setIsSearchOpen(false);
          setIsCalendarOpen(false);
        }}
        onToggleCalendar={() => {
          setIsCalendarOpen(!isCalendarOpen);
          setIsStartMenuOpen(false);
          setIsSearchOpen(false);
          setIsQuickSettingsOpen(false);
        }}
        onOpenApp={openApp}
        onTaskbarAppClick={handleTaskbarAppClick}
        onShowDesktop={handleShowDesktop}
      />

      {/* Notification Toast for system actions */}
      {powerToast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-slate-900/90 text-white border border-white/20 shadow-2xl backdrop-blur-xl text-xs flex items-center space-x-2 animate-in fade-in slide-in-from-top-4">
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
          <span>{powerToast}</span>
        </div>
      )}

      {/* SYSTEM OVERLAYS: Lock Screen */}
      {systemState === 'lock' && (
        <div
          onClick={() => setSystemState('normal')}
          className="fixed inset-0 z-50 flex flex-col justify-between p-8 sm:p-12 text-white select-none animate-in fade-in duration-300"
        >
          {/* Lock Screen Wallpaper Backdrop */}
          <div className="absolute inset-0 -z-10">
            <WallpaperBackground wallpaper={settings.wallpaper} />
            <div className="absolute inset-0 bg-black/35 backdrop-blur-md" />
          </div>

          {/* Top Clock and Date */}
          <div className="flex flex-col items-center mt-8 sm:mt-12 text-center drop-shadow-md">
            <div className="text-6xl sm:text-8xl font-light tracking-tighter">
              {lockTime || '10:42 AM'}
            </div>
            <div className="text-lg sm:text-xl font-normal mt-1 opacity-90">
              {lockDate || 'Thursday, September 3'}
            </div>
          </div>

          {/* User Sign-In Center Container */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex flex-col items-center justify-center p-6 rounded-3xl bg-slate-900/60 backdrop-blur-2xl border border-white/10 shadow-2xl max-w-xs mx-auto text-center"
          >
            <div
              style={{ backgroundColor: settings.accentColor || '#0078d4' }}
              className="w-20 h-20 rounded-full text-white text-3xl font-bold flex items-center justify-center shadow-lg mb-3"
            >
              W
            </div>
            <div className="text-lg font-semibold">Windows User</div>
            <div className="text-xs text-slate-300 mb-4">user@windows.pro</div>

            <button
              type="button"
              onClick={() => setSystemState('normal')}
              style={{ backgroundColor: settings.accentColor || '#0078d4' }}
              className="w-full py-2.5 px-4 rounded-xl text-white font-medium text-xs shadow-md hover:brightness-110 active:scale-98 transition-all cursor-pointer"
            >
              Sign In
            </button>
            <div className="text-[11px] text-slate-400 mt-3">Click or press any key to unlock</div>
          </div>

          {/* Bottom Right System Status Icons */}
          <div className="flex items-center justify-end space-x-4 opacity-80 text-xs">
            <div className="flex items-center space-x-1.5">
              <Wifi className="w-4 h-4" />
              <span>Connected</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <BatteryCharging className="w-4 h-4" />
              <span>100%</span>
            </div>
          </div>
        </div>
      )}

      {/* SYSTEM OVERLAYS: Sleep Mode */}
      {systemState === 'sleep' && (
        <div
          onClick={() => setSystemState('normal')}
          className="fixed inset-0 z-50 bg-black/98 flex flex-col items-center justify-center text-slate-400 select-none cursor-pointer animate-in fade-in duration-500"
        >
          <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_20px_#22d3ee] mb-4" />
          <div className="text-sm font-medium text-slate-300">System in Sleep Mode</div>
          <div className="text-xs text-slate-500 mt-1">Click anywhere to wake up Windows 11</div>
        </div>
      )}

      {/* SYSTEM OVERLAYS: Restarting */}
      {systemState === 'restarting' && (
        <div className="fixed inset-0 z-50 bg-[#004880] flex flex-col items-center justify-center text-white select-none animate-in fade-in duration-300">
          {/* Windows 11 Spinning Circle Animation */}
          <div className="relative w-12 h-12 mb-6">
            <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
          <div className="text-lg font-light tracking-wide">Restarting</div>
          <div className="text-xs text-blue-200/80 mt-2 font-mono">Windows 11 Pro</div>
        </div>
      )}

      {/* SYSTEM OVERLAYS: Shutting Down */}
      {systemState === 'shutting-down' && (
        <div className="fixed inset-0 z-50 bg-[#004880] flex flex-col items-center justify-center text-white select-none animate-in fade-in duration-300">
          <div className="relative w-12 h-12 mb-6">
            <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
          <div className="text-lg font-light tracking-wide">Shutting down</div>
          <div className="text-xs text-blue-200/80 mt-2 font-mono">Windows 11 Pro</div>
        </div>
      )}

      {/* SYSTEM OVERLAYS: Turned Off */}
      {systemState === 'turned-off' && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center text-white select-none">
          <button
            type="button"
            onClick={() => {
              setSystemState('restarting');
              setTimeout(() => setSystemState('normal'), 2000);
            }}
            className="w-16 h-16 rounded-full bg-slate-900 border border-slate-700 hover:border-blue-500 flex items-center justify-center text-blue-400 hover:scale-110 hover:text-white transition-all shadow-2xl cursor-pointer"
            title="Turn on PC"
          >
            <Power className="w-7 h-7" />
          </button>
          <div className="text-sm font-medium text-slate-400 mt-4">PC is turned off</div>
          <div className="text-xs text-slate-600 mt-1">Press power button to start Windows 11 Pro</div>
        </div>
      )}
    </div>
  );
}
