import { WallpaperId } from '../types';

export interface WallpaperOption {
  id: WallpaperId;
  name: string;
  cssClass: string;
  previewGradient: string;
}

export const WALLPAPERS: WallpaperOption[] = [
  {
    id: 'bloom-blue',
    name: 'Windows 11 Bloom (Light)',
    cssClass: 'bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364]',
    previewGradient: 'from-sky-400 via-blue-500 to-indigo-700',
  },
  {
    id: 'bloom-dark',
    name: 'Windows 11 Dark Bloom',
    cssClass: 'bg-[#0a0d14]',
    previewGradient: 'from-slate-900 via-indigo-950 to-blue-950',
  },
  {
    id: 'bloom-glow',
    name: 'Windows 11 Glow',
    cssClass: 'bg-[#080d1a]',
    previewGradient: 'from-violet-900 via-purple-800 to-emerald-700',
  },
  {
    id: 'bloom-captured-motion',
    name: 'Captured Motion',
    cssClass: 'bg-[#18091e]',
    previewGradient: 'from-fuchsia-900 via-pink-800 to-rose-700',
  },
  {
    id: 'bloom-flow',
    name: 'Windows 11 Flow',
    cssClass: 'bg-[#031526]',
    previewGradient: 'from-cyan-700 via-blue-800 to-indigo-900',
  },
  {
    id: 'sunrise',
    name: 'Sunrise Horizon',
    cssClass: 'bg-[#1b101c]',
    previewGradient: 'from-amber-600 via-rose-600 to-indigo-900',
  },
  {
    id: 'aurora',
    name: 'Aurora Borealis',
    cssClass: 'bg-[#021B1A]',
    previewGradient: 'from-emerald-800 via-teal-700 to-cyan-900',
  },
  {
    id: 'sunset',
    name: 'Sunset Twilight',
    cssClass: 'bg-[#1a1423]',
    previewGradient: 'from-indigo-950 via-purple-900 to-amber-700',
  },
  {
    id: 'spotlight',
    name: 'Windows Spotlight',
    cssClass: 'bg-[#0c1e2b]',
    previewGradient: 'from-sky-700 via-teal-800 to-emerald-900',
  },
  {
    id: 'cyber',
    name: 'Minimal Carbon',
    cssClass: 'bg-[#0c0d10]',
    previewGradient: 'from-zinc-900 via-neutral-800 to-slate-950',
  },
];
